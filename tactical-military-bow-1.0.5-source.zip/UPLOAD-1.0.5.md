# 1.0.5 Yayın / Upload

Yalnızca yerel hazırlık; hiçbir dosya yüklenmedi veya yayınlanmadı.
Prepared locally only; nothing uploaded or published.

## CurseForge
- File: tactical-military-bow-forge-1.20.1-1.0.5.jar
- Display name: [TaCZ] Tactical Military Bow 1.0.5 - Forge 1.20.1
- Release type: Release
- Minecraft: 1.20.1; Forge; Java 17; Client and Server
- Required: TaCZ >=1.1.5 <1.3 (1.1.8-hotfix/hotfix2 API checked; 1.2.0 gameplay tested), LesRaisins Tactical Equipements >=0.4.3 <0.5 (tested 0.4.4), Curios >=5.14.1 <6, GeckoLib >=4.8.4 <5.
- Arcana / ItemPhysic Guns: not required.
- Changelog: CHANGELOG-1.0.5.md, Türkçe ve İngilizce aynı alana / both languages in the same field.

## GitHub
- tactical-military-bow-1.0.5-source.zip
- README.md, BUILD.md, CHANGELOG.md, CHANGELOG-1.0.5.md, UPSTREAM.md and license/notice files.
- Commit: Update Tactical Military Bow to 1.0.5
- Optional release tag: v1.0.5
- Do not upload source-staging folders or test backups.

## Upgrade / Güncelleme
Sadağı eski kemer yuvasından envantere alın. Dünyayı yedekleyin, eski yay JAR'ını kaldırın. TaCZ 1.1.5+ veya 1.2.x kullanın; 1.2 sürümüne geçmek zorunlu değildir. İstemci/sunucuyu birlikte 1.0.5'e güncelleyin (protokol 4).

Move the quiver out of the old belt slot, back up the world and remove the old bow JAR. Use TaCZ 1.1.5+ or 1.2.x; upgrading to 1.2 is optional. Update client/server together to 1.0.5 (protocol 4).

TaCZ 1.2 açılışı ve zırhlı zombi testi kullanıcı tarafından onaylandı. Son görsel/tarif değişiklikleri otomatik testlerden geçti; ayrıca oyun içi son kontrol önerilir. Temiz kurulum ve çok oyunculu ayrıca doğrulanmadı.

User approved TaCZ 1.2 startup and armored-zombie testing. Latest visual/recipe changes passed automated checks; final in-game review is recommended. Clean installation and multiplayer were not independently verified.

### TaCZ 1.1.5–1.2 Compatibility

TaCZ 1.1.5–1.1.7: ok tarifleri Mühimmat bölümünde / arrow recipes appear in Ammunition. TaCZ 1.1.8+: Explosives & Projectiles.

TaCZ 1.1.x: LR Tactical 0.4.3 kullanın / use LR Tactical 0.4.3. LR Tactical 0.4.4 requires TaCZ 1.2.

1.1.5 resmi kaynak kodu, 1.1.6–1.2 JAR API bağlantıları kontrol edildi; eski sürümlerde oyun içi test henüz yapılmadı. / Official 1.1.5 source and 1.1.6–1.2 JAR APIs checked; legacy in-game testing remains pending.
