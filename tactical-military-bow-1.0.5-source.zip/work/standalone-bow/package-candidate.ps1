param([switch]$Release)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$version = '1.0.5'
$out = Join-Path $root $(if ($Release) { "outputs/release-$version-final" } else { "outputs/test-$version" })
New-Item -ItemType Directory -Path $out -Force | Out-Null
$jarName = "tactical-military-bow-forge-1.20.1-$version.jar"
Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('build/libs/' + $jarName)) -Destination $out -Force
$stage = Join-Path $out ('source-staging-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$work = Join-Path $stage 'work/standalone-bow'
New-Item -ItemType Directory -Path $work -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'src') -Destination $work -Recurse
Get-ChildItem -LiteralPath $PSScriptRoot -File | Copy-Item -Destination $work
$dependencyHashes = @{}
Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'libs') -File -Filter '*.jar' | ForEach-Object {
    $dependencyHashes[$_.Name] = (Get-FileHash -LiteralPath $_.FullName).Hash
}
$dependencyHashes | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $work 'DEPENDENCY-HASHES.json') -Encoding utf8
$preview = Join-Path $stage 'outputs/arrow-preview'
New-Item -ItemType Directory -Path $preview -Force | Out-Null
Get-ChildItem -LiteralPath (Join-Path $root 'outputs/arrow-preview') -File | Copy-Item -Destination $preview
Copy-Item -LiteralPath (Join-Path $root 'outputs/standalone-bow/upstream-assets.json') -Destination $work
foreach ($name in @('README.md', 'BUILD.md', 'CHANGELOG.md', 'UPSTREAM.md', "UPLOAD-$version.md", "CHANGELOG-$version.md")) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $out -Force
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $stage
}
foreach ($name in @('THIRD-PARTY-NOTICES.md', 'LICENSE-GPL-3.0.txt', 'SOUND-LICENSE.txt')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('src/main/resources/' + $name)) -Destination $out -Force
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('src/main/resources/' + $name)) -Destination $stage
}
$sourceName = "tactical-military-bow-$version-source.zip"
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath (Join-Path $out $sourceName) -Force
$jar = [IO.Compression.ZipFile]::OpenRead((Join-Path $out $jarName))
$source = [IO.Compression.ZipFile]::OpenRead((Join-Path $out $sourceName))
$hashes = @{}
function EntryHash($entry) {
    $stream = $entry.Open()
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [Convert]::ToHexString($sha.ComputeHash($stream)) }
    finally { $stream.Dispose(); $sha.Dispose() }
}
try {
    foreach ($class in @('BowParticleSheets', 'BowParticleSheets$1', 'SparkParticle', 'BloodParticle')) {
        if (!$jar.GetEntry('com/korkuluk/standalonebow/client/' + $class + '.class')) {
            throw "Missing particle class in JAR: $class"
        }
    }
    foreach ($class in @('client/ArrowWheelScreen', 'client/ArrowWheelLayout', 'BowNetwork$SelectArrow',
            'client/BowArmModels', 'client/BowArmModels$Arms', 'client/BowArmBuffers',
            'client/BowAmmoCounts', 'client/BowCounterText', 'client/BowVertexWriter',
            'ArmorBreaker', 'ArmorBreakProfile', 'mixin/ArmorBreakerPlayerMixin', 'client/EmbeddedArrowVisual', 'client/BowAimCant',
            'TaczCompatibility', 'TaczCompatibility$RuntimeVersion', 'mixin/TaczRecipeGroupMixin')) {
        if (!$jar.GetEntry('com/korkuluk/standalonebow/' + $class + '.class')) {
            throw "Missing runtime class in JAR: $class"
        }
    }
    $resourceRoot = Join-Path $PSScriptRoot 'src/main/resources'
    foreach ($file in Get-ChildItem -LiteralPath $resourceRoot -File -Recurse) {
        $relative = [IO.Path]::GetRelativePath($resourceRoot, $file.FullName).Replace('\', '/')
        $entry = $jar.GetEntry($relative)
        if (!$entry) { throw "Missing JAR resource: $relative" }
        $hash = (Get-FileHash -LiteralPath $file.FullName).Hash
        if ((EntryHash $entry) -ne $hash) { throw "JAR resource mismatch: $relative" }
        $sourceEntry = $source.GetEntry('work/standalone-bow/src/main/resources/' + $relative)
        if (!$sourceEntry -or (EntryHash $sourceEntry) -ne $hash) { throw "Source resource mismatch: $relative" }
        $hashes[$relative] = $hash
    }
    foreach ($file in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'src/main/java') -File -Recurse) {
        $relative = [IO.Path]::GetRelativePath($PSScriptRoot, $file.FullName).Replace('\', '/')
        $entry = $source.GetEntry('work/standalone-bow/' + $relative)
        if (!$entry -or (EntryHash $entry) -ne (Get-FileHash -LiteralPath $file.FullName).Hash) { throw "Source Java mismatch: $relative" }
    }
} finally { $jar.Dispose(); $source.Dispose() }
$manifest = [ordered]@{
    version = $version; status = $(if ($Release) { 'release-candidate' } else { 'test' }); publicUpload = $false
    description_en = "Tactical Military Bow $version; prepared for owner publication."
    description_tr = "Tactical Military Bow $version; proje sahibinin paylaşımı için hazırlandı."
    jar = @{file = $jarName; sha256 = (Get-FileHash -LiteralPath (Join-Path $out $jarName)).Hash}
    source = @{file = $sourceName; sha256 = (Get-FileHash -LiteralPath (Join-Path $out $sourceName)).Hash}
    userApprovedTests = @('TaCZ 1.2.0 startup/gameplay reported clean', 'armor breaker armored-zombie test reported clean', '15-degree ADS preferred by user')
    agentVerification = @('Gradle build', 'automated tests', 'EN/TR key and placeholder parity', 'JAR/source resource hashes',
        'TaCZ 1.1.5 official source API and ammo tab review', 'TaCZ 1.1.6-hotfix/1.1.7-hotfix2/1.1.8-hotfix/1.1.8-hotfix2/1.2.0 JAR API signatures')
    currentUpdateUserApproval = @('release preparation requested; owner will publish', 'armor breaker values and recipe specified by user')
    notTested_en = 'Clean installation, multiplayer and legacy TaCZ runtime gameplay were not separately verified. Final recipe-category adaptation requires an in-game check. TaCZ 1.1.5 reviewed from official sources; full binary download was incomplete and not used.'
    notTested_tr = 'Temiz kurulum, çok oyunculu ve eski TaCZ sürümlerinde oyun içi test ayrıca doğrulanmadı. Son kategori uyarlaması oyun içi kontrol gerektirir. TaCZ 1.1.5 resmi kaynaklardan incelendi; tamamlanamayan ikili indirme kullanılmadı.'
    resources = $hashes
}
$manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out 'MANIFEST.json') -Encoding utf8
Write-Output ('Candidate packaged; JAR/source hashes verified for ' + $hashes.Count + ' resources: ' + $out)
