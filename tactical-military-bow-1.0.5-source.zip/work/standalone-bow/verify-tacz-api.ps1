param([Parameter(Mandatory=$true)][string]$Jar)
$ErrorActionPreference = 'Stop'
$Jar = (Resolve-Path -LiteralPath $Jar).Path
function Assert-Signature([string]$Class, [string[]]$Signatures) {
    $output = (& javap -classpath $Jar -private $Class) -join "`n"
    if ($LASTEXITCODE -ne 0) { throw "Cannot inspect $Class" }
    foreach ($signature in $Signatures) {
        if (!$output.Contains($signature)) { throw "Missing API: $Class : $signature" }
    }
}
Assert-Signature 'com.tacz.guns.util.ExplodeUtil' @('public static void createExplosion(net.minecraft.world.entity.Entity, net.minecraft.world.entity.Entity, float, float, boolean, boolean, net.minecraft.world.phys.Vec3);')
Assert-Signature 'com.tacz.guns.client.input.FireSelectKey' @('public static final net.minecraft.client.KeyMapping FIRE_SELECT_KEY;')
Assert-Signature 'com.tacz.guns.client.gui.GunSmithTableScreen' @('private java.util.List<net.minecraft.resources.ResourceLocation> selectedRecipeList;', 'public boolean m_6050_(double, double, double);')
Assert-Signature 'com.tacz.guns.crafting.GunSmithTableSerializer' @('public com.tacz.guns.crafting.GunSmithTableRecipe fromJson(net.minecraft.resources.ResourceLocation, com.google.gson.JsonObject);')
Assert-Signature 'com.tacz.guns.crafting.result.GunSmithTableResult' @('private net.minecraft.world.item.ItemStack result;', 'public net.minecraft.resources.ResourceLocation getGroup();')
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [IO.Compression.ZipFile]::OpenRead($Jar)
try {
    if (!$zip.GetEntry('assets/tacz/textures/crosshair/hit/hit_marker.png')) { throw 'Missing hit marker texture' }
} finally { $zip.Dispose() }
Write-Output 'TaCZ API checks passed: explosion, selection key, smithing mixin, recipe serializer, hit marker. Runtime gameplay still requires testing.'
