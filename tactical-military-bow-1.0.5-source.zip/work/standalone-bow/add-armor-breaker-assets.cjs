const fs = require('fs'), path = require('path'), assert = require('assert');
const root = path.join(__dirname, 'src/main/resources');
const assets = path.join(root, 'assets/tacticalmilitarybow');
function write(file, value) {
    fs.mkdirSync(path.dirname(file), {recursive:true});
    fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n');
}
// Keep animation pivots and the tip location; change only this arrow's cubes and palette UVs.
for (const relative of ['geo/item/piercing_arrow.geo.json', 'geo/item/gun/compound_bow_piercing.geo.json',
        'models/item/piercing_arrow.json', 'models/item/piercing_arrow_in_hand.json', 'models/item/piercing_arrow_gui.json']) {
    const value = JSON.parse(fs.readFileSync(path.join(assets, relative)));
    write(path.join(assets, relative.replaceAll('piercing', 'armor_breaker')),
        JSON.parse(JSON.stringify(value).replaceAll('piercing', 'armor_breaker')));
}
for (const relative of ['textures/item/piercing_arrow_icon.png', 'textures/animated/gun/compound_bow_nocked_piercing.png'])
    fs.copyFileSync(path.join(assets, relative), path.join(assets, relative.replaceAll('piercing', 'armor_breaker')));
write(path.join(root, 'data/tacticalmilitarybow/recipes/armor_breaker_arrow.json'), {
    type:'tacz:gun_smith_table_crafting',
    materials:[['minecraft:stick',10],['minecraft:iron_ingot',10],['minecraft:string',10]]
        .map(([item,count])=>({item:{item},count})),
    result:{type:'custom',group:'tacz:explosives',item:{item:'tacticalmilitarybow:armor_breaker_arrow',count:45}}
});
const arrowPath = path.join(assets,'geo/item/armor_breaker_arrow.geo.json');
const arrow = JSON.parse(fs.readFileSync(arrowPath));
const ag = arrow['minecraft:geometry'][0];
const head = ag.bones.find(b=>b.name==='custom_nocked_arrow_head');
const tip = Math.min(...head.cubes.map(c=>c.origin[2]));
for (const b of ag.bones) for (const c of b.cubes||[]) {
    let swatch = 1;
    if (b===head) {
        const rear=c.origin[2]+c.size[2];
        // Compress the head toward its fixed tip, widen around the shaft axis.
        c.origin[2] = tip + (c.origin[2]-tip)*0.72;
        c.size[2] *= 0.72;
        if(c===head.cubes[head.cubes.length-1]) c.size[2]=rear-c.origin[2];
        for (let axis=0;axis<2;axis++) {
            const center=[0.06855,3.0898][axis];
            c.origin[axis]=center+(c.origin[axis]-center)*1.4;
            c.size[axis]*=1.4;
        }
        if (head.cubes.indexOf(c)<3) swatch=17;
    } else if (b.name==='gold_identification_band') swatch=17;
    else if (b.name.includes('yu') || b.name.includes('light')) swatch=25;
    for (const f of Object.values(c.uv)) { f.uv=[swatch,1]; f.uv_size=[4,4]; }
}
assert.equal(Math.min(...head.cubes.map(c=>c.origin[2])),tip);
write(arrowPath,arrow);
const bowPath=path.join(assets,'geo/item/gun/compound_bow_armor_breaker.geo.json');
const bow=JSON.parse(fs.readFileSync(bowPath));
for(const prefix of ['arrow','reload_arrow']) for(const bone of ag.bones) {
    const name=bone.name.startsWith('custom_nocked_arrow')
        ? bone.name.replace('custom_nocked_arrow','custom_nocked_'+prefix)
        : 'custom_nocked_'+prefix+'_'+bone.name;
    const target=bow['minecraft:geometry'][0].bones.find(b=>b.name===name);
    assert(target,name);
    assert.deepEqual(target.pivot,bone.pivot);
    if(bone.cubes) {
        target.cubes=JSON.parse(JSON.stringify(bone.cubes));
        for(const c of target.cubes) for(const f of Object.values(c.uv)) f.uv[0]+=128;
    }
}
write(bowPath,bow);
require('child_process').execFileSync('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'create-armor-breaker-palette.ps1')],{stdio:'inherit'});
console.log('Armor breaker white tip, dark steel head and dark red tail generated; launch/reload pivots preserved.');
