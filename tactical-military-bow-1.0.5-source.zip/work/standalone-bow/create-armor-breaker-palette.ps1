$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$assets=Join-Path $PSScriptRoot 'src/main/resources/assets/tacticalmilitarybow'
# Native model palette: five flat eight-pixel swatches, no filtering or resampling.
$palette=[Drawing.Bitmap]::new(40,8)
$g=[Drawing.Graphics]::FromImage($palette)
$colors=@('#2B3035','#657078','#ECEFF1','#982228','#43494F')
for($i=0;$i -lt 5;$i++) {
    $brush=[Drawing.SolidBrush]::new([Drawing.ColorTranslator]::FromHtml($colors[$i]))
    $g.FillRectangle($brush,$i*8,0,8,8);$brush.Dispose()
}
$g.Dispose()
$palette.Save((Join-Path $assets 'textures/item/arrow_palette_armor_breaker.png'),[Drawing.Imaging.ImageFormat]::Png)
$base=[Drawing.Bitmap]::FromFile((Join-Path $assets 'textures/animated/gun/compound_bow_nocked_piercing.png'))
$atlas=[Drawing.Bitmap]::new($base.Width,$base.Height)
$g=[Drawing.Graphics]::FromImage($atlas)
$g.DrawImageUnscaled($base,0,0);$g.DrawImageUnscaled($palette,128,0);$g.Dispose();$base.Dispose()
$atlas.Save((Join-Path $assets 'textures/animated/gun/compound_bow_nocked_armor_breaker.png'),[Drawing.Imaging.ImageFormat]::Png)
$atlas.Dispose();$palette.Dispose()
$icon=[Drawing.Bitmap]::new(16,16)
$g=[Drawing.Graphics]::FromImage($icon)
$steel=[Drawing.Pen]::new([Drawing.ColorTranslator]::FromHtml('#657078'),2)
$red=[Drawing.Pen]::new([Drawing.ColorTranslator]::FromHtml('#982228'),2)
$white=[Drawing.SolidBrush]::new([Drawing.ColorTranslator]::FromHtml('#ECEFF1'))
$g.DrawLine($steel,3,12,12,3)
$g.DrawLine($red,2,9,5,12);$g.DrawLine($red,3,13,6,13)
$points=[Drawing.Point[]]@([Drawing.Point]::new(13,1),[Drawing.Point]::new(9,3),[Drawing.Point]::new(12,6))
$g.FillPolygon($white,$points)
$g.Dispose();$steel.Dispose();$red.Dispose();$white.Dispose()
$icon.Save((Join-Path $assets 'textures/item/armor_breaker_arrow_icon.png'),[Drawing.Imaging.ImageFormat]::Png)
$icon.Dispose()
