const fs = require('fs'), path = require('path'), assert = require('assert');
const root = path.join(__dirname, 'src/main/resources/assets/tacticalmilitarybow/lang');
const en = JSON.parse(fs.readFileSync(path.join(root, 'en_us.json'), 'utf8'));
const tr = JSON.parse(fs.readFileSync(path.join(root, 'tr_tr.json'), 'utf8'));
const additions = {
 'item.tacticalmilitarybow.armor_breaker_arrow': ['Armor Breaker Arrow', 'Zırh Kırıcı Ok'],
 'curios.identifier.tactical_quiver': ['Quiver', 'Sadak'],
 'gui.tacticalmilitarybow.arrow_wheel': ['Arrow Selection', 'Ok Seçimi'],
 'gui.tacticalmilitarybow.reloading': ['Reloading', 'Dolduruluyor'],
 'key.tacticalmilitarybow.reload': ['Reload', 'Doldur'],
 'key.tacticalmilitarybow.inspect': ['Inspect', 'İncele'],
 'key.categories.tacticalmilitarybow': ['Tactical Military Bow', 'Taktik Askerî Yay'],
 'settings.tacticalmilitarybow.title': ['Compound Bow Settings', 'Makaralı Yay Ayarları'],
 'settings.tacticalmilitarybow.ammo': ['Ammo HUD', 'Mühimmat HUD'],
 'settings.tacticalmilitarybow.charge': ['Charge Bar', 'Çekiş Çubuğu'],
 'settings.tacticalmilitarybow.hide_charge': ['Hide Charge in ADS', 'Nişanda Çekişi Gizle'],
 'settings.tacticalmilitarybow.crosshair': ['Dynamic Crosshair', 'Dinamik Nişangah'],
 'settings.tacticalmilitarybow.recoil': ['Camera Recoil', 'Kamera Tepmesi'],
 'settings.tacticalmilitarybow.sprint': ['Sprint Animation', 'Koşma Animasyonu'],
 'settings.tacticalmilitarybow.ads': ['ADS Sensitivity', 'Nişan Hassasiyeti'],
 'settings.tacticalmilitarybow.sway': ['Sway Sensitivity', 'Salınım Hassasiyeti'],
 'settings.tacticalmilitarybow.bob': ['Bobbing Intensity', 'Yürüme Salınımı'],
 'commands.tacticalmilitarybow.verify_core': ['Standalone bow core: %s runtime checks passed', 'Bağımsız yay: %s çalışma zamanı kontrolü geçti'],
 'commands.tacticalmilitarybow.verify_quiver': ['Quiver: %s runtime checks passed', 'Sadak: %s çalışma zamanı kontrolü geçti'],
 'tooltip.tacticalmilitarybow.bow.description_1': ['Graphite frame with olive details.', 'Grafit gövde, zeytin yeşili detaylar.'],
 'enchantment.tacticalmilitarybow.infinity.desc': ['Normal arrows no longer need reserve ammo to reload', 'Normal oklar için doldururken yedek mühimmat gerekmez']
};
for (const [key, values] of Object.entries(additions)) { en[key] = values[0]; tr[key] = values[1]; }
Object.assign(tr, {
 'key.tacticalmilitarybow.interact': 'Etkileşim',
 'item.tacticalmilitarybow.explosive_arrow': 'Patlayıcı Ok',
 'item.tacticalmilitarybow.tactical_military_bow': 'Taktik Askerî Yay',
 'itemGroup.tacticalmilitarybow': 'Taktik Askerî Yay',
 'item.tacticalmilitarybow.repair_kit': 'Tamir Kiti',
 'chat.tacticalmilitarybow.rocket_ride': 'Varlıkların üzerinde roket sürmek için eğilmelisin!',
 'chat.tacticalmilitarybow.attachment_broke': 'Bir eklenti kırıldı',
 'chat.tacticalmilitarybow.raid_flare_loaded': 'Baskın işaret fişeği yükledin!',
 'subtitle.tacticalmilitarybow.gun_rustle': 'Silah Hışırtısı',
 'chat.tacticalmilitarybow.flamethrower': 'Blokları ateşe vermek için eğilmelisin!',
 'chat.tacticalmilitarybow.jam': 'Silahın tutukluk yaptı',
 'chat.tacticalmilitarybow.infinity_disabled': 'Bu silaha Sonsuzluk uygulanamaz',
 'chat.tacticalmilitarybow.flashlight_battery_dead': 'El fenerini şarj etmek için art arda sol tıkla!',
 'chat.tacticalmilitarybow.disabled_flashlights': 'Bu sunucuda el fenerleri devre dışı!',
 'info.tacticalmilitarybow.tooltip_item.repair_kit': 'Örste kullanıldığında silahları tamir eder!',
 'info.tacticalmilitarybow.tooltip_item.compound_bow_blueprint': 'Bu plan, baskınlarda Rattlers grubundan düşer!'
});
const enchants = {
 atlantic_shooter: ['Atlantik Atıcısı', 'Suyun altında ateş etmeyi sağlar'],
 over_capacity: ['Ek Kapasite', 'Silahın mühimmat kapasitesini artırır'],
 lightweight: ['Hafiflik', 'Silah ağırlığını azaltarak nişan alma hızını artırır'],
 reclaimed: ['Geri Kazanım', 'Atış sırasında okun tüketilmeme ihtimalini artırır'],
 quick_hands: ['Hızlı Eller', 'Doldurma hızını artırır'],
 fire_starter: ['Ateş Başlatıcı', 'Mermiler çarptıkları blokları ve varlıkları ateşe verir'],
 withered: ['Solgunluk', 'Silahın hasarını artırır'],
 accelerator: ['Hızlandırıcı', 'Merminin hızını ve hasarını artırır'],
 puncturing: ['Delip Geçme', 'Kritik hasar ihtimali sağlar'],
 infinity: ['Sonsuzluk', 'Normal oklar için doldururken yedek mühimmat gerekmez'],
 trigger_finger: ['Seri Atış', 'Atış hızını artırır'],
 collateral: ['Çoklu İsabet', 'Merminin birden çok varlıktan geçmesini sağlar']
};
for (const [name, values] of Object.entries(enchants)) {
 tr['enchantment.tacticalmilitarybow.' + name] = values[0];
 tr['enchantment.tacticalmilitarybow.' + name + '.desc'] = values[1];
 if (!en['enchantment.tacticalmilitarybow.' + name + '.desc']) en['enchantment.tacticalmilitarybow.' + name + '.desc'] = values[0] === 'Sonsuzluk' ? additions['enchantment.tacticalmilitarybow.infinity.desc'][0] : 'Increases weapon effectiveness';
}
const deaths = {
 killed: ['%1$s was taken down by %2$s', '%1$s, %2$s tarafından öldürüldü'],
 eliminated: ['%1$s was eliminated by %2$s', '%1$s, %2$s tarafından etkisiz hâle getirildi'],
 executed: ['%1$s was executed by %2$s', '%1$s, %2$s tarafından vuruldu'],
 annihilated: ['%1$s was annihilated by %2$s', '%1$s, %2$s tarafından yok edildi'],
 decimated: ['%1$s was decimated by %2$s', '%1$s, %2$s tarafından imha edildi']
};
for (const [name, values] of Object.entries(deaths)) for (const suffix of ['', '.player', '.item']) {
 const key = 'death.attack.tacticalmilitarybow.bullet.' + name + suffix;
 en[key] = values[0]; tr[key] = values[1];
}
assert.deepStrictEqual(Object.keys(en).sort(), Object.keys(tr).sort());
for (const key of Object.keys(en)) {
 const placeholders = s => (s.match(/%(?:\d+\$)?[sd]/g) || []).sort();
 assert.deepStrictEqual(placeholders(en[key]), placeholders(tr[key]), key);
}
for (const [lang, values] of [['en_us', en], ['tr_tr', tr]]) fs.writeFileSync(path.join(root, lang + '.json'), JSON.stringify(values, null, 2) + '\n');
console.log('EN/TR parity and placeholders verified: ' + Object.keys(en).length + ' keys per language.');
