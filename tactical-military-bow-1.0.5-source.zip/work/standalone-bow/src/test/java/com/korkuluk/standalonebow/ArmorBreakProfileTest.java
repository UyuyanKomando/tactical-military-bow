package com.korkuluk.standalonebow;

public final class ArmorBreakProfileTest {
    private static int checks;
    private static void check(boolean condition) { if (!condition) throw new AssertionError("Check " + checks); checks++; }
    public static void main(String[] args) {
        String[] materials = {"gold", "chainmail", "iron", "diamond", "netherite"};
        int[] hits = {2, 2, 3, 4, 5};
        for (int i = 0; i < materials.length; i++) {
            check(ArmorBreakProfile.hits(materials[i]) == hits[i]);
            for (int max = 55; max <= 600; max++) {
                int wear = ArmorBreakProfile.wear(max, hits[i]);
                check(wear * (hits[i] - 1) < max);
                check(wear * hits[i] >= max);
            }
        }
        check(ArmorBreakProfile.hits("leather") == 0);
        check(ArmorBreakProfile.hits("modded:steel") == 0);
        check(ArmorBreakProfile.wear(0, 2) == 0);
        check(ArmorBreakProfile.wear(100, 0) == 0);
        check(ArmorBreakProfile.region(0.9, false) == 0);
        check(ArmorBreakProfile.region(0.6, false) == 1);
        check(ArmorBreakProfile.region(0.3, false) == 2);
        check(ArmorBreakProfile.region(0.1, false) == 3);
        check(ArmorBreakProfile.region(0.1, true) == 0);
        check(ArrowProfile.directDamage("armor_breaker", 20) == 2);
        check(ArrowProfile.recoverable("armor_breaker", true, false, false, false));
        check(!ArrowProfile.recoverable("armor_breaker", true, true, false, false));
        check(!ArrowProfile.explodesInLava("armor_breaker"));
        System.out.println("ArmorBreakProfileTest: " + checks + " checks passed");
    }
}
