package com.korkuluk.standalonebow.client;

public final class ArrowWheelLayoutTest {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        check(ArrowWheelLayout.selected(0, 0, 40, 100, 5) == -1, "center cancels selection");
        check(ArrowWheelLayout.selected(0, -39, 40, 100, 5) == -1, "dead zone");
        check(ArrowWheelLayout.selected(0, -101, 40, 100, 5) == -1, "outside ring");
        check(ArrowWheelLayout.selected(Double.NaN, 1, 40, 100, 5) == -1, "invalid pointer");
        check(ArrowWheelLayout.selected(Double.POSITIVE_INFINITY, 1, 40, 100, 5) == -1, "infinite pointer");
        check(ArrowWheelLayout.selected(0, -70, 40, 100, 0) == -1, "empty wheel");
        for (int count : new int[]{5, 6}) for (int sector = 0; sector < count; sector++) {
            for (int offset = -28; offset <= 28; offset++) {
                double angle = -Math.PI / 2 + sector * Math.PI * 2 / count + Math.toRadians(offset);
                for (int r : new int[]{40, 70, 99}) {
                    check(ArrowWheelLayout.selected(Math.cos(angle) * r, Math.sin(angle) * r, 39.99, 100, count) == sector,
                            "clockwise sector " + sector + " at offset " + offset);
                }
            }
        }
        System.out.println("ArrowWheelLayoutTest: " + checks + " checks passed");
    }
}
