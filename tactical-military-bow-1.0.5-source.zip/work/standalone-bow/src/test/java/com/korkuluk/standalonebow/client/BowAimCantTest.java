package com.korkuluk.standalonebow.client;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class BowAimCantTest {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        check(BowAimCant.angle(0) == 0, "idle unchanged");
        check(Math.abs(Math.toDegrees(BowAimCant.angle(1)) + 15) < 0.00001, "fifteen degrees clockwise");
        check(BowAimCant.angle(Float.NaN) == 0, "invalid aim ignored");
        var up = new Vector3f(0, 1, 0).rotateZ(BowAimCant.angle(1));
        check(up.x > 0 && up.y > 0, "bow top leans right");
        for (int i = 0; i <= 100; i++) {
            float angle = BowAimCant.angle(i / 100F);
            var matrix = new Matrix4f().translate(0.2F, -0.1F, -1.4F).rotateXYZ(.13F,.24F,.07F).scale(.8F);
            var original = new Matrix4f(matrix);
            var normal = new Matrix3f().rotationXYZ(.13F,.24F,.07F);
            var originalNormal = new Matrix3f(normal);
            var localCenter = new Vector3f(-.075F,.4140625F,.453125F);
            var anchor = matrix.transformPosition(localCenter, new Vector3f());
            BowAimCant.apply(matrix, normal, anchor.x, anchor.y, angle);
            check(matrix.transformPosition(localCenter, new Vector3f()).distance(anchor) < 0.000001, "sight center fixed");
            var rolledAnchor = matrix.transformPosition(localCenter, new Vector3f());
            BowAimCant.apply(matrix, normal, rolledAnchor.x, rolledAnchor.y, -angle);
            check(matrix.equals(original, 0.000002F), "counter-rolled reticle preserves original orientation and center");
            check(normal.equals(originalNormal, 0.000002F), "reticle lighting normals restored");
            var before = original.transformPosition(new Vector3f(.4F,.2F,-.2F));
            var rolled = new Matrix4f(original);
            BowAimCant.apply(rolled,new Matrix3f(),anchor.x,anchor.y,angle);
            check(Math.abs(rolled.transformPosition(new Vector3f(.4F,.2F,-.2F)).z - before.z) < 0.000001, "depth unchanged");
        }
        System.out.println("BowAimCantTest: " + checks + " cant/reticle-center checks passed");
    }
}
