package com.korkuluk.standalonebow.client;

import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class EmbeddedArrowVisualTest {
    public static void main(String[] args) {
        int checks = 0;
        float tip = (float)com.korkuluk.standalonebow.BowStats.ARROW_TIP_DISTANCE;
        for (int angle = 0; angle < 360; angle++) {
            var original = new Matrix4f().translate(1, 2, 3).rotateY((float)Math.toRadians(angle)).rotateX(0.4F);
            var flight = new Matrix4f(original);
            EmbeddedArrowVisual.apply(flight, false, tip);
            if (!flight.equals(original)) throw new AssertionError("Flight changed");
            var embedded = new Matrix4f(original);
            EmbeddedArrowVisual.apply(embedded, true, tip);
            var anchor = new Vector3f(0, 0, -tip);
            if (original.transformPosition(new Vector3f(anchor)).distance(embedded.transformPosition(new Vector3f(anchor))) > 0.00001F)
                throw new AssertionError("Tip moved");
            for (var axis : new Vector3f[]{new Vector3f(1,0,0),new Vector3f(0,1,0),new Vector3f(0,0,1)})
                if (Math.abs(embedded.transformDirection(axis).length() - 0.75F) > 0.00001F)
                    throw new AssertionError("Wrong length/thickness");
            checks += 5;
        }
        System.out.println("EmbeddedArrowVisualTest: " + checks + " checks passed");
    }
}
