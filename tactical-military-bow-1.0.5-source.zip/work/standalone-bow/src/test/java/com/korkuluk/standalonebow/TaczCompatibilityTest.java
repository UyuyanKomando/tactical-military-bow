package com.korkuluk.standalonebow;

public final class TaczCompatibilityTest {
    public static void main(String[] args) {
        int checks = 0;
        for (String version : new String[]{"1.1.5", "1.1.6", "1.1.6-hotfix", "1.1.7", "1.1.7-hotfix2"}) {
            if (!TaczCompatibility.legacyCategories(version)) throw new AssertionError(version);
            checks++;
        }
        for (String version : new String[]{"1.1.8", "1.1.8-hotfix", "1.1.8-hotfix2", "1.2.0"}) {
            if (TaczCompatibility.legacyCategories(version)) throw new AssertionError(version);
            checks++;
        }
        System.out.println("TaczCompatibilityTest: " + checks + " version/category checks passed");
    }
}
