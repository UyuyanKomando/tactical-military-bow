package com.korkuluk.standalonebow;

import net.minecraftforge.fml.ModList;
import org.apache.maven.artifact.versioning.DefaultArtifactVersion;

public final class TaczCompatibility {
    private TaczCompatibility() {}
    public static boolean legacyCategories(String version) {
        return new DefaultArtifactVersion(version).compareTo(new DefaultArtifactVersion("1.1.8")) < 0;
    }
    public static boolean usesLegacyCategories() { return RuntimeVersion.LEGACY; }
    private static final class RuntimeVersion {
        static final boolean LEGACY = ModList.get().getModContainerById("tacz")
                .map(mod -> legacyCategories(mod.getModInfo().getVersion().toString())).orElse(false);
    }
}
