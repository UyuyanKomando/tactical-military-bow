package com.korkuluk.standalonebow.client;

import org.joml.Matrix4f;

public final class EmbeddedArrowVisual {
    private EmbeddedArrowVisual() {}
    public static void apply(Matrix4f pose, boolean embedded, float tipDistance) {
        if (!embedded) return;
        // Uniform positive scaling leaves normals unchanged and keeps the embedded tip fixed.
        pose.translate(0, 0, -tipDistance).scale(0.75F).translate(0, 0, tipDistance);
    }
}
