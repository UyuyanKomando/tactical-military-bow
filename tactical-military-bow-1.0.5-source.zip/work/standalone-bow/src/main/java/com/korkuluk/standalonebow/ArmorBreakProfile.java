package com.korkuluk.standalonebow;

public final class ArmorBreakProfile {
    private ArmorBreakProfile() {}
    public static int hits(String material) {
        return switch (material) {
            case "gold", "chainmail" -> 2;
            case "iron" -> 3;
            case "diamond" -> 4;
            case "netherite" -> 5;
            default -> 0;
        };
    }
    public static int wear(int maximum, int hits) {
        return maximum <= 0 || hits <= 0 ? 0 : (int)(((long)maximum + hits - 1) / hits);
    }
    public static int region(double height, boolean headshot) {
        return headshot || height >= 0.80 ? 0 : height >= 0.45 ? 1 : height >= 0.15 ? 2 : 3;
    }
}
