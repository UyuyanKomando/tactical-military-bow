package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.BowArrowEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public final class BowArrowRenderer extends GeoEntityRenderer<BowArrowEntity> {
    private final java.util.Map<BowArrowEntity, net.minecraft.world.phys.Vec3> launchTips = new java.util.WeakHashMap<>();
    public BowArrowRenderer(EntityRendererProvider.Context context) {
        super(context, new GeoModel<BowArrowEntity>() {
            @Override public ResourceLocation getModelResource(BowArrowEntity arrow) {
                return new ResourceLocation("tacticalmilitarybow", "geo/item/" + arrow.arrowKind() + "_arrow.geo.json");
            }
            @Override public ResourceLocation getTextureResource(BowArrowEntity arrow) {
                String suffix = arrow.arrowKind().equals("poison") || arrow.arrowKind().equals("flame") || arrow.arrowKind().equals("armor_breaker") ? "_" + arrow.arrowKind() : "";
                return new ResourceLocation("tacticalmilitarybow", "textures/item/arrow_palette" + suffix + ".png");
            }
            @Override public ResourceLocation getAnimationResource(BowArrowEntity arrow) {
                return new ResourceLocation("tacticalmilitarybow", "animations/item/arrows.animation.json");
            }
        });
    }

    @Override protected void applyRotations(BowArrowEntity arrow, PoseStack pose, float age, float yaw, float partial) {
        var velocity = arrow.getDeltaMovement();
        float heading = arrow.isEmbedded() ? arrow.embeddedYaw() : (float)Math.toDegrees(Math.atan2(velocity.x, velocity.z));
        float pitch = arrow.isEmbedded() ? arrow.embeddedPitch() : (float)Math.toDegrees(Math.atan2(velocity.y, velocity.horizontalDistance()));
        // Model tip points along negative Z; rotate it into the flight direction.
        pose.mulPose(Axis.YP.rotationDegrees(180 + heading));
        pose.mulPose(Axis.XP.rotationDegrees(pitch));
        EmbeddedArrowVisual.apply(pose.last().pose(), arrow.isEmbedded(),
                (float)com.korkuluk.standalonebow.BowStats.ARROW_TIP_DISTANCE);
        pose.translate(0.06855 / 16, -3.0898 / 16, 0);
    }
    @Override public void render(BowArrowEntity arrow, float yaw, float partial, PoseStack pose,
            net.minecraft.client.renderer.MultiBufferSource buffers, int light) {
        var mc = net.minecraft.client.Minecraft.getInstance();
        float progress = Math.min(1, (arrow.tickCount + partial) / 2F);
        if (!arrow.isEmbedded() && arrow.getOwner() == mc.player && progress < 1) {
            var tip = launchTips.computeIfAbsent(arrow, unused -> BowLaunchVisual.recentTip());
            if (tip != null) {
                var current = new net.minecraft.world.phys.Vec3(
                        net.minecraft.util.Mth.lerp(partial, arrow.xOld, arrow.getX()),
                        net.minecraft.util.Mth.lerp(partial, arrow.yOld, arrow.getY()),
                        net.minecraft.util.Mth.lerp(partial, arrow.zOld, arrow.getZ()));
                var center = tip.subtract(arrow.getDeltaMovement().normalize().scale(com.korkuluk.standalonebow.BowStats.ARROW_TIP_DISTANCE));
                var offset = center.subtract(current).scale(1 - progress);
                pose.pushPose();
                try {
                    pose.translate(offset.x, offset.y, offset.z);
                    super.render(arrow, yaw, partial, pose, buffers, light);
                } finally { pose.popPose(); }
                return;
            }
        }
        launchTips.remove(arrow);
        super.render(arrow, yaw, partial, pose, buffers, light);
    }
}
