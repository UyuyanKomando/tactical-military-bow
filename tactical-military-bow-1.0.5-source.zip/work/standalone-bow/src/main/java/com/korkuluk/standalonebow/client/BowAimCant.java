package com.korkuluk.standalonebow.client;

import org.joml.Matrix3f;
import org.joml.Matrix4f;

public final class BowAimCant {
    private BowAimCant() {}
    public static float angle(float aim) {
        if (!Float.isFinite(aim)) return 0;
        float t = Math.max(0, Math.min(1, aim));
        return (float)Math.toRadians(-15) * (1 - (1 - t) * (1 - t));
    }
    /** Camera-space clockwise roll around the projected sight center, without changing depth. */
    public static void apply(Matrix4f pose, Matrix3f normal, float x, float y, float angle) {
        pose.translateLocal(-x, -y, 0).rotateLocalZ(angle).translateLocal(x, y, 0);
        normal.rotateLocalZ(angle);
    }
}
