package com.korkuluk.standalonebow;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(StandaloneBow.ID)
public final class StandaloneBow {
    public static final String ID = "tacticalmilitarybow";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ID);
    public static final RegistryObject<SoundEvent> FIRE = sound("item.compound_bow.fire");
    public static final RegistryObject<SoundEvent> PULL = sound("item.compound_bow.pull");
    public static final RegistryObject<SoundEvent> CHARGE = sound("item.compound_bow.charge");
    public static final RegistryObject<SoundEvent> PLACE_ARROW = sound("item.compound_bow.place_arrow");
    public static final RegistryObject<SoundEvent> RELOAD_START = sound("item.combat_rifle.reload_magazine_out");
    public static final RegistryObject<SoundEvent> RELOAD_END = sound("item.combat_rifle.reload_ejector");
    public static final RegistryObject<SoundEvent> ITEM_PISTOL_COCK = sound("item.pistol.cock");
    public static final RegistryObject<SoundEvent> MEDAL_HEADSHOT = sound("ui.medal.headshot");
    public static final RegistryObject<SoundEvent> BULLET_CLOSE = sound("entity.bullet.close");
    public static final RegistryObject<SoundEvent> HIT_MARKER = sound("entity.bullet.hit");
    public static final RegistryObject<CompoundBowItem> BOW = ITEMS.register("tactical_military_bow",
            () -> new CompoundBowItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final RegistryObject<QuiverItem> QUIVER = ITEMS.register("quiver",
            () -> new QuiverItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<TacticalArrowItem> NORMAL_ARROW = ITEMS.register("normal_arrow", () -> new TacticalArrowItem("normal"));
    public static final RegistryObject<TacticalArrowItem> PIERCING_ARROW = ITEMS.register("piercing_arrow", () -> new TacticalArrowItem("piercing"));
    public static final RegistryObject<TacticalArrowItem> EXPLOSIVE_ARROW = ITEMS.register("explosive_arrow", () -> new TacticalArrowItem("explosive"));
    public static final RegistryObject<TacticalArrowItem> POISON_ARROW = ITEMS.register("poison_arrow", () -> new TacticalArrowItem("poison"));
    public static final RegistryObject<TacticalArrowItem> FLAME_ARROW = ITEMS.register("flame_arrow", () -> new TacticalArrowItem("flame"));
    public static final RegistryObject<TacticalArrowItem> ARMOR_BREAKER_ARROW = ITEMS.register("armor_breaker_arrow", () -> new TacticalArrowItem("armor_breaker"));
    public static final DeferredRegister<net.minecraft.world.item.CreativeModeTab> TABS =
            DeferredRegister.create(net.minecraft.core.registries.Registries.CREATIVE_MODE_TAB, ID);
    public static final RegistryObject<net.minecraft.world.item.CreativeModeTab> TACTICAL_TAB = TABS.register("tactical_bow",
            () -> net.minecraft.world.item.CreativeModeTab.builder()
                    .title(net.minecraft.network.chat.Component.translatable("itemGroup.tacticalmilitarybow"))
                    .icon(() -> new net.minecraft.world.item.ItemStack(BOW.get()))
                    .displayItems((parameters, output) -> { output.accept(BOW.get()); output.accept(QUIVER.get());
                        output.accept(NORMAL_ARROW.get()); output.accept(PIERCING_ARROW.get()); output.accept(EXPLOSIVE_ARROW.get());
                        output.accept(POISON_ARROW.get()); output.accept(FLAME_ARROW.get()); output.accept(ARMOR_BREAKER_ARROW.get()); })
                    .build());
    public static final RegistryObject<Item> REPAIR_KIT = ITEMS.register("repair_kit", () -> new Item(new Item.Properties()));
    public static final RegistryObject<EntityType<BowArrowEntity>> ARROW = ENTITIES.register("arrow",
            () -> EntityType.Builder.<BowArrowEntity>of(BowArrowEntity::new, MobCategory.MISC)
                    .sized(0.05F, 0.05F).clientTrackingRange(64).updateInterval(1).build(ID + ":arrow"));
    public static final RegistryObject<EntityType<DynamicHelmet>> DYNAMIC_HELMET = ENTITIES.register("dynamic_helmet",
            () -> EntityType.Builder.<DynamicHelmet>of(DynamicHelmet::new, MobCategory.MISC)
                    .sized(0.5F, 0.5F).clientTrackingRange(64).updateInterval(1).build(ID + ":dynamic_helmet"));

    public StandaloneBow() {
        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        TABS.register(bus);
        ENTITIES.register(bus);
        SOUNDS.register(bus);
        net.minecraftforge.fml.ModLoadingContext.get().registerConfig(net.minecraftforge.fml.config.ModConfig.Type.COMMON, Config.SPEC);
        bus.addListener(StandaloneBow::creative);
        BowNetwork.register();
        MinecraftForge.EVENT_BUS.register(new BowMechanics());
        MinecraftForge.EVENT_BUS.register(new BoundingBoxManager());
        MinecraftForge.EVENT_BUS.addListener(StandaloneBow::remapLegacyBow);
    }
    private static void remapLegacyBow(net.minecraftforge.registries.MissingMappingsEvent event) {
        for (var mapping : event.getMappings(ForgeRegistries.Keys.ITEMS, "standalonebow")) {
            String path = mapping.getKey().getPath();
            var item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(ID, path.equals("compound_bow") ? "tactical_military_bow" : path));
            if (item != null && item != net.minecraft.world.item.Items.AIR) mapping.remap(item);
        }
        for (var mapping : event.getMappings(ForgeRegistries.Keys.ENTITY_TYPES, "standalonebow")) {
            var type = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(ID, mapping.getKey().getPath()));
            if (type != null) mapping.remap(type);
        }
        for (var mapping : event.getMappings(ForgeRegistries.Keys.SOUND_EVENTS, "standalonebow")) {
            var sound = ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(ID, mapping.getKey().getPath()));
            if (sound != null) mapping.remap(sound);
        }
        for (String namespace : new String[]{"standalonebow", ID}) {
            for (var mapping : event.getMappings(ForgeRegistries.Keys.ENCHANTMENTS, namespace)) mapping.ignore();
        }
    }
    private static RegistryObject<SoundEvent> sound(String path) {
        return SOUNDS.register(path, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ID, path)));
    }
    private static void creative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(BOW.get());
            event.accept(REPAIR_KIT.get());
            event.accept(QUIVER.get());
        }
    }
}
