package com.korkuluk.standalonebow.mixin;

import com.korkuluk.standalonebow.BowArrowEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Player.class)
public abstract class ArmorBreakerPlayerMixin {
    // Keep vanilla health mitigation, but replace its all-slot durability wear with impact-slot wear.
    @Inject(method = {"hurtArmor(Lnet/minecraft/world/damagesource/DamageSource;F)V",
            "m_6472_(Lnet/minecraft/world/damagesource/DamageSource;F)V"}, at = @At("HEAD"), cancellable = true, remap = false)
    private void tacticalmilitarybow$localizedWear(DamageSource source, float amount, CallbackInfo callback) {
        if (source.getDirectEntity() instanceof BowArrowEntity arrow && arrow.arrowKind().equals("armor_breaker")) callback.cancel();
    }
}
