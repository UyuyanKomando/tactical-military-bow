package com.korkuluk.standalonebow;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;

public final class ArmorBreaker {
    private ArmorBreaker() {}
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    public static void hit(LivingEntity target, double hitY, boolean headshot) {
        if (target instanceof Player player && player.isCreative()) return;
        double height = (hitY - target.getBoundingBox().minY) / Math.max(0.01, target.getBbHeight());
        var slot = SLOTS[ArmorBreakProfile.region(height, headshot)];
        var stack = target.getItemBySlot(slot);
        if (!(stack.getItem() instanceof ArmorItem armor) || !stack.isDamageableItem()
                || (stack.hasTag() && stack.getTag().getBoolean("Unbreakable"))) return;
        int hits = ArmorBreakProfile.hits(armor.getMaterial().getName());
        if (hits == 0) {
            // Leather and unknown materials retain vanilla durability/enchantment behavior.
            stack.hurtAndBreak(1, target, entity -> entity.broadcastBreakEvent(slot));
            return;
        }
        int damage = stack.getDamageValue() + ArmorBreakProfile.wear(stack.getMaxDamage(), hits);
        if (damage >= stack.getMaxDamage()) {
            stack.shrink(1);
            target.broadcastBreakEvent(slot);
        } else stack.setDamageValue(damage);
    }
}
