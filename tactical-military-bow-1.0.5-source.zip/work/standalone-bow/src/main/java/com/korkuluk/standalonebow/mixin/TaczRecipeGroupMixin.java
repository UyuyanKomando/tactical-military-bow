package com.korkuluk.standalonebow.mixin;

import com.korkuluk.standalonebow.TacticalArrowItem;
import com.korkuluk.standalonebow.TaczCompatibility;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "com.tacz.guns.crafting.result.GunSmithTableResult", remap = false)
public abstract class TaczRecipeGroupMixin {
    @Shadow private ItemStack result;
    private static final ResourceLocation TACTICAL_AMMO = new ResourceLocation("tacz", "ammo");
    private static final ResourceLocation TACTICAL_EXPLOSIVES = new ResourceLocation("tacz", "explosives");

    // TaCZ 1.1.5-1.1.7 tables only list tacz:ammo; leave all other mods' recipes alone.
    @Inject(method = "getGroup", at = @At("RETURN"), cancellable = true, require = 1)
    private void tacticalmilitarybow$legacyAmmoTab(CallbackInfoReturnable<ResourceLocation> callback) {
        if (TaczCompatibility.usesLegacyCategories() && result != null
                && result.getItem() instanceof TacticalArrowItem
                && TACTICAL_EXPLOSIVES.equals(callback.getReturnValue())) callback.setReturnValue(TACTICAL_AMMO);
    }
}
