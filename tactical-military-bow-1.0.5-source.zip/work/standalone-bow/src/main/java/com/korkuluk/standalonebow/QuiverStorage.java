package com.korkuluk.standalonebow;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.ItemStackHandler;
import top.theillusivec4.curios.api.CuriosApi;

public final class QuiverStorage {
    public static final int SLOTS = 9;
    private QuiverStorage() {}
    public static ItemStackHandler contents(ItemStack quiver) {
        var handler = new ItemStackHandler(SLOTS) {
            @Override public boolean isItemValid(int slot, ItemStack stack) {
                return TacticalArrowItem.accepts(stack);
            }
        };
        if (quiver.hasTag()) {
            ListTag list = quiver.getTag().getList("QuiverContents", 10);
            for (int i = 0; i < Math.min(SLOTS, list.size()); i++) {
                CompoundTag saved = list.getCompound(i).copy();
                String id = saved.getString("id");
                if (id.startsWith("standalonebow:")) saved.putString("id", StandaloneBow.ID + id.substring("standalonebow".length()));
                ItemStack stack = ItemStack.of(saved);
                if (stack.getItem() instanceof ArrowItem) {
                    stack.setCount(Math.min(stack.getCount(), stack.getMaxStackSize()));
                    handler.setStackInSlot(i, stack);
                }
            }
        }
        return handler;
    }
    public static void save(ItemStack quiver, ItemStackHandler handler) {
        var list = new ListTag();
        for (int i = 0; i < SLOTS; i++) list.add(handler.getStackInSlot(i).save(new CompoundTag()));
        quiver.getOrCreateTag().put("QuiverContents", list);
    }
    public static int selected(ItemStack quiver) {
        return quiver.hasTag() ? Math.floorMod(quiver.getTag().getInt("QuiverSelected"), SLOTS) : 0;
    }
    public static int ammoSlot(ItemStack quiver, ItemStackHandler handler) {
        for (int i = 0; i < SLOTS; i++) {
            int slot = (selected(quiver) + i) % SLOTS;
            if (!handler.getStackInSlot(slot).isEmpty()) return slot;
        }
        return -1;
    }
    public static ItemStack peek(ItemStack quiver) {
        var handler = contents(quiver);
        int slot = ammoSlot(quiver, handler);
        return slot < 0 ? ItemStack.EMPTY : handler.getStackInSlot(slot).copyWithCount(1);
    }
    public static ItemStack takeOne(ItemStack quiver) {
        var handler = contents(quiver);
        int slot = ammoSlot(quiver, handler);
        if (slot < 0) return ItemStack.EMPTY;
        var result = handler.extractItem(slot, 1, false);
        save(quiver, handler);
        return result;
    }
    public static ItemStack insert(ItemStack quiver, ItemStack input) {
        if (!TacticalArrowItem.accepts(input)) return input;
        var handler = contents(quiver);
        ItemStack remainder = input.copy();
        for (int pass = 0; pass < 2; pass++) for (int i = 0; i < SLOTS && !remainder.isEmpty(); i++) {
            if (handler.getStackInSlot(i).isEmpty() == (pass == 1))
                remainder = handler.insertItem(i, remainder, false);
        }
        save(quiver, handler);
        return remainder;
    }
    public static void cycle(ItemStack quiver) {
        var handler = contents(quiver);
        int selected = selected(quiver);
        for (int i = 1; i <= SLOTS; i++) {
            int slot = (selected + i) % SLOTS;
            if (!handler.getStackInSlot(slot).isEmpty()) {
                quiver.getOrCreateTag().putInt("QuiverSelected", slot);
                return;
            }
        }
    }
    public static int count(ItemStack quiver) {
        var handler = contents(quiver);
        int count = 0;
        for (int i = 0; i < SLOTS; i++) count += handler.getStackInSlot(i).getCount();
        return count;
    }
    public static ItemStack equipped(Player player) {
        return CuriosApi.getCuriosInventory(player).resolve().map(inventory -> {
            var belt = inventory.getStacksHandler(QuiverItem.SLOT);
            if (belt.isPresent()) {
                var stacks = belt.get().getStacks();
                for (int i = 0; i < stacks.getSlots(); i++) {
                    var stack = stacks.getStackInSlot(i);
                    if (stack.getItem() instanceof QuiverItem) return stack;
                }
            }
            return ItemStack.EMPTY;
        }).orElse(ItemStack.EMPTY);
    }
    public static int bowAmmoCount(Player player) {
        var handler = contents(equipped(player));
        int count = 0;
        for (int i = 0; i < SLOTS; i++) if (TacticalArrowItem.accepts(handler.getStackInSlot(i)))
            count += handler.getStackInSlot(i).getCount();
        return count;
    }
    public static ItemStack bowAmmo(Player player, boolean consume) {
        return bowAmmo(player, consume, "");
    }
    public static ItemStack bowAmmo(Player player, boolean consume, String kind) {
        var quiver = equipped(player);
        if (quiver.isEmpty()) return ItemStack.EMPTY;
        var handler = contents(quiver);
        for (int i = 0; i < SLOTS; i++) {
            int slot = (selected(quiver) + i) % SLOTS;
            if (TacticalArrowItem.accepts(handler.getStackInSlot(slot))
                    && (kind.isEmpty() || TacticalArrowItem.kind(handler.getStackInSlot(slot)).equals(kind))) {
                var arrow = handler.extractItem(slot, 1, !consume);
                if (consume) save(quiver, handler);
                return arrow;
            }
        }
        return ItemStack.EMPTY;
    }
}
