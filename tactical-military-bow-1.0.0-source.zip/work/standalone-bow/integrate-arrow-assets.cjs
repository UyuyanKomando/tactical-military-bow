const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.join(__dirname,'src/main/resources');
const assets=path.join(root,'assets/standalonebow');
const candidates=path.resolve(__dirname,'../../outputs/arrow-preview');
function write(p,v){fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n');}
const base=JSON.parse(fs.readFileSync(path.join(assets,'geo/item/gun/compound_bow.geo.json')));
const sourceBones=base['minecraft:geometry'][0].bones;
for(const kind of ['normal','piercing','explosive']){
 const candidate=JSON.parse(fs.readFileSync(path.join(candidates,kind+'_arrow.geo.json')));
 write(path.join(assets,'geo/item/'+kind+'_arrow.geo.json'),candidate);
 write(path.join(assets,'models/item/'+kind+'_arrow_in_hand.json'),{parent:'builtin/entity',display:{ground:{scale:[.5,.5,.5]},firstperson_righthand:{rotation:[0,90,0],translation:[0,0,0],scale:[.6,.6,.6]},thirdperson_righthand:{rotation:[0,90,0],scale:[.6,.6,.6]}}});
 write(path.join(assets,'models/item/'+kind+'_arrow_gui.json'),{parent:'minecraft:item/generated',textures:{layer0:'standalonebow:item/'+kind+'_arrow_icon'},gui_light:'front'});
 write(path.join(assets,'models/item/'+kind+'_arrow.json'),{loader:'forge:separate_transforms',base:{parent:'standalonebow:item/'+kind+'_arrow_in_hand'},perspectives:{gui:{parent:'standalonebow:item/'+kind+'_arrow_gui'}},gui_light:'front'});
 const bow=JSON.parse(JSON.stringify(base));
 bow['minecraft:geometry'][0].bones=sourceBones.filter(b=>!b.name.startsWith('custom_nocked_'));
 const nockedName=(name,prefix)=>name.startsWith('custom_nocked_arrow')?name.replace('custom_nocked_arrow','custom_nocked_'+prefix):'custom_nocked_'+prefix+'_'+name;
 for(const prefix of ['arrow','reload_arrow'])for(const orig of candidate['minecraft:geometry'][0].bones){
  const b=JSON.parse(JSON.stringify(orig));
  b.name=nockedName(orig.name,prefix);
  b.parent=orig.parent?nockedName(orig.parent,prefix):prefix;
  for(const c of b.cubes||[])for(const uv of Object.values(c.uv)){uv.uv=[uv.uv[0]*3.2,uv.uv[1]*16];uv.uv_size=[uv.uv_size[0]*3.2,uv.uv_size[1]*16];}
  bow['minecraft:geometry'][0].bones.push(b);
 }
 const names=new Set(bow['minecraft:geometry'][0].bones.map(b=>b.name));
 assert.equal(names.size,bow['minecraft:geometry'][0].bones.length);
 for(const b of bow['minecraft:geometry'][0].bones)assert(!b.parent||names.has(b.parent));
 write(path.join(assets,'geo/item/gun/compound_bow_'+kind+'.geo.json'),bow);
 const items=[['minecraft:stick',10],['minecraft:iron_ingot',2],...(kind!=='normal'?[['minecraft:gold_ingot',2]]:[]),...(kind==='explosive'?[['minecraft:gunpowder',10]]:[]),['minecraft:string',10]];
 write(path.join(root,'data/standalonebow/recipes/'+kind+'_arrow.json'),{type:'tacz:gun_smith_table_crafting',materials:items.map(([item,count])=>({item:{item},count})),result:{type:'custom',group:'tacz:explosives',item:{item:'standalonebow:'+kind+'_arrow',count:45}}});
}
fs.copyFileSync(path.join(candidates,'arrow_palette.png'),path.join(assets,'textures/item/arrow_palette.png'));
write(path.join(assets,'animations/item/arrows.animation.json'),{format_version:'1.8.0',animations:{idle:{loop:true,bones:{}}}});
for(const lang of ['tr_tr','en_us']){
 const p=path.join(assets,'lang/'+lang+'.json');const v=JSON.parse(fs.readFileSync(p));
 const labels=lang==='tr_tr'?['Normal Ok','Delici Ok','Patlayıcı Ok']:['Normal Arrow','Piercing Arrow','Explosive Arrow'];
 ['normal','piercing','explosive'].forEach((k,i)=>v['item.standalonebow.'+k+'_arrow']=labels[i]);write(p,v);
}
console.log('Three items, held/reload arrow variants and 45-count TaCZ explosives recipes exported.');
