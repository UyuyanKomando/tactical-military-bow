const fs = require('fs');
const path = require('path');
const base = path.join(__dirname, 'src/main/resources/assets/standalonebow');
const gp = path.join(base, 'geo/item/gun/compound_bow.geo.json');
const mp = path.join(base, 'models/special/gun/compound_bow.json');
const geo = JSON.parse(fs.readFileSync(gp));
const baked = JSON.parse(fs.readFileSync(mp));
const g = geo['minecraft:geometry'][0];
const removed = new Set(['round_sight_ring', 'sight_dot', 'tactical_sight_housing', 'sight_reticle', 'sight_fasteners']);
const before = JSON.stringify(g.bones.filter(b => !removed.has(b.name)));
g.bones = g.bones.filter(b => !removed.has(b.name));
baked.elements = baked.elements.filter(e => !removed.has(e.name));
const faces = ['north', 'east', 'south', 'west', 'up', 'down'];
function bone(name) { const b = {name, parent:'bow_body', pivot:[1.2,6.625,7.3995], cubes:[]}; g.bones.push(b); return b; }
const ring = bone('round_sight_ring'), mount = bone('tactical_sight_housing');
const bolts = bone('sight_fasteners'), reticle = bone('sight_reticle');
function box(b,x,y,z,w,h,d,u=31,v=5) {
  b.cubes.push({origin:[x-w/2,y-h/2,z-d/2],size:[w,h,d],uv:Object.fromEntries(faces.map(f=>[f,{uv:[u,v],uv_size:[1,1]}]))});
}
// Horizontal strips preserve the round aperture without unsupported baked rotations.
function annulus(b,cx,cy,z,r,inner,depth,u,v) {
  const n=96, step=2*r/n;
  for(let i=0;i<n;i++) { const y=-r+(i+.5)*step, outer=Math.sqrt(r*r-y*y);
    const hole=Math.abs(y)<inner?Math.sqrt(inner*inner-y*y):0;
    for(const sign of [-1,1]) box(b,cx+sign*(outer+hole)/2,cy+y,z,outer-hole,step+.0005,depth,u,v);
  }
}
annulus(ring,1.2,6.625,7.40,.77,.665,.23,31,5);
annulus(ring,1.2,6.625,7.275,.755,.725,.026,34,0);
// Compact two-point mounting bracket, outside the clear aperture.
box(mount,.40,6.625,7.48,.19,.91,.32);
box(mount,.29,6.625,7.65,.26,.65,.38);
for(const y of [6.30,6.95]) box(mount,.52,y,7.48,.30,.12,.20);
for(const a of [.65,2.5,4.0,5.5]) {
  const x=1.2+.715*Math.cos(a), y=6.625+.715*Math.sin(a);
  annulus(bolts,x,y,7.24,.061,0,.065,34,0);
  box(bolts,x,y,7.20,.055,.014,.014);
}
// The top aiming chevron stays at the previous sight center.
for(let i=0;i<12;i++) { const t=i/11; for(const s of [-1,1]) box(reticle,1.2+s*(.075*(1-t)),6.625+.09*(1-t),7.25,.014,.014,.012,82,5); }
for(const [dy,len] of [[.09,1.10],[-.06,1.10],[-.31,.88],[-.53,.60]]) {
  for(const sign of [-1,1]) box(reticle,1.2+sign*(.11+len/4),6.625+dy,7.25,len/2-.10,.013,.012,82,5);
}
box(reticle,1.2,6.34,7.25,.012,.48,.012,82,5);
const font={ '0':['111','101','101','101','111'], '1':['010','110','010','010','111'], '5':['111','100','111','001','111'], '8':['111','101','111','101','111'], 'M':['101','111','111','101','101'], '-':['000','000','111','000','000'] };
function label(text,x,y) { const p=.015; for(const [i,c] of [...text].entries()) for(let row=0;row<5;row++) for(let col=0;col<3;col++) if(font[c][row][col]==='1') box(reticle,2.4-(x+(i*4+col)*p),y-row*p,7.245,p*.8,p*.8,.012,82,5); }
label('0-50M',.91,6.63); label('80M',1.00,6.39); label('100M',.97,6.16);
const added=g.bones.filter(b=>removed.has(b.name));
for(const b of added) for(const c of b.cubes) {
  const [x,y,z]=c.origin,[w,h,d]=c.size;
  const from=[8.201097-.8*(x+w),.8*y-.207144,.8*z+9.1344];
  const to=[8.201097-.8*x,.8*(y+h)-.207144,.8*(z+d)+9.1344];
  const uv=c.uv.north.uv;
  baked.elements.push({name:b.name,from,to,faces:Object.fromEntries(faces.map(f=>[f,{texture:'#0',uv:[uv[0]/8,uv[1]/8,(uv[0]+1)/8,(uv[1]+1)/8]}]))});
}
if(before!==JSON.stringify(g.bones.filter(b=>!removed.has(b.name)))) throw Error('Non-sight geometry changed');
fs.writeFileSync(gp,JSON.stringify(geo,null,2)+'\n');
fs.writeFileSync(mp,JSON.stringify(baked,null,2)+'\n');
console.log('FPS and TPS sight updated; non-sight geometry unchanged; center preserved at 1.2, 6.625.');
