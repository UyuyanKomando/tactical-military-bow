package com.korkuluk.standalonebow.client;

/** Mirrors AnimatedGunItem.inventoryTick: clear the flag before incrementing DrawnTick. */
public final class BowDrawLock {
    private int drawnTicks;
    private boolean drawing;
    public void equip() { drawnTicks = 0; drawing = false; }
    public void tick(int drawTimer) {
        if (drawnTicks >= drawTimer) drawing = false;
        if (!drawing && drawnTicks < drawTimer) drawing = true;
        if (drawing && drawnTicks < drawTimer) drawnTicks++;
    }
    public boolean drawing() { return drawing; }
}
