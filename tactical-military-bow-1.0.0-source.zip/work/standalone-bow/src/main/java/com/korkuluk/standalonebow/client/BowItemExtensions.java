package com.korkuluk.standalonebow.client;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** Construct from CompoundBowItem.initializeClient on the physical client only. */
public final class BowItemExtensions implements IClientItemExtensions {
    private BlockEntityWithoutLevelRenderer renderer;
    @Override public BlockEntityWithoutLevelRenderer getCustomRenderer() {
        if (renderer == null) renderer = new BowRenderer<>();
        return renderer;
    }
}
