package com.korkuluk.standalonebow;

import java.lang.reflect.Method;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Calls the installed TaCZ implementation rather than bundling its explosion code. */
public final class TaczArrowExplosion {
    public static final float DAMAGE = ArrowProfile.EXPLOSION_DAMAGE;
    public static final float RADIUS = ArrowProfile.EXPLOSION_RADIUS;
    private static final Method EXPLODE = resolve();
    private TaczArrowExplosion() {}
    private static Method resolve() {
        try {
            return Class.forName("com.tacz.guns.util.ExplodeUtil").getMethod("createExplosion",
                    Entity.class, Entity.class, float.class, float.class, boolean.class, boolean.class, Vec3.class);
        } catch (ReflectiveOperationException ex) {
            throw new IllegalStateException("Required TaCZ explosion API is incompatible", ex);
        }
    }
    public static void detonate(BowArrowEntity projectile, Vec3 position) {
        if (projectile.level().isClientSide) return;
        try {
            EXPLODE.invoke(null, projectile.getOwner(), projectile, DAMAGE, RADIUS, true, false, position);
        } catch (ReflectiveOperationException ex) {
            throw new IllegalStateException("TaCZ arrow explosion failed", ex);
        }
    }
}
