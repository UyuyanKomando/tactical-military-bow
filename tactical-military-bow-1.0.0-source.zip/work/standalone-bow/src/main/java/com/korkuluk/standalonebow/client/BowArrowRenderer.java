package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.BowArrowEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public final class BowArrowRenderer extends GeoEntityRenderer<BowArrowEntity> {
    public BowArrowRenderer(EntityRendererProvider.Context context) {
        super(context, new GeoModel<BowArrowEntity>() {
            @Override public ResourceLocation getModelResource(BowArrowEntity arrow) {
                return new ResourceLocation("standalonebow", "geo/item/" + arrow.arrowKind() + "_arrow.geo.json");
            }
            @Override public ResourceLocation getTextureResource(BowArrowEntity arrow) {
                return new ResourceLocation("standalonebow", "textures/item/arrow_palette.png");
            }
            @Override public ResourceLocation getAnimationResource(BowArrowEntity arrow) {
                return new ResourceLocation("standalonebow", "animations/item/arrows.animation.json");
            }
        });
    }

    @Override protected void applyRotations(BowArrowEntity arrow, PoseStack pose, float age, float yaw, float partial) {
        var velocity = arrow.getDeltaMovement();
        float heading = (float)Math.toDegrees(Math.atan2(velocity.x, velocity.z));
        float pitch = (float)Math.toDegrees(Math.atan2(velocity.y, velocity.horizontalDistance()));
        // Model tip points along negative Z; rotate it into the flight direction.
        pose.mulPose(Axis.YP.rotationDegrees(180 - heading));
        pose.mulPose(Axis.XP.rotationDegrees(pitch));
        pose.translate(0.06855 / 16, -3.0898 / 16, 0);
    }
}
