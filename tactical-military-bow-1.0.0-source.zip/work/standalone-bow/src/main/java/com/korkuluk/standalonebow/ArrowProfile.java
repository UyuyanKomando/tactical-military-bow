package com.korkuluk.standalonebow;

public final class ArrowProfile {
    public static final float EXPLOSION_DAMAGE = 50;
    public static final float EXPLOSION_RADIUS = 6;
    public static final int EXPLOSION_TIMEOUT = 600;
    private ArrowProfile() {}
    public static float directDamage(String kind, float baseDamage) {
        return baseDamage * ("piercing".equals(kind) ? 1.75F : 1F);
    }
}
