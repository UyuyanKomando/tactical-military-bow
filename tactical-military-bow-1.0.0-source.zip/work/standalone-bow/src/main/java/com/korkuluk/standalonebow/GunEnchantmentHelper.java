package com.korkuluk.standalonebow;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.RegistryObject;

/** Bow-compatible formulas from installed JEG GunEnchantmentHelper/ReloadTracker. */
public final class GunEnchantmentHelper {
    private GunEnchantmentHelper() {}
    public static int level(ItemStack stack, RegistryObject<Enchantment> enchantment) {
        return stack.getEnchantmentLevel(enchantment.get());
    }
    public static int getReloadInterval(ItemStack stack, int interval) {
        return BowEnchantmentRules.inventoryReloadInterval(interval, level(stack, ModEnchantments.QUICK_HANDS));
    }
    public static float getReloadAnimationSpeed(ItemStack stack) {
        return 1 + 0.2F * level(stack, ModEnchantments.QUICK_HANDS);
    }
    public static int getModifiedDrawTick(ItemStack stack, int ticks) {
        return Config.COMMON.drawAnimation.get() ? Math.max(1, Math.round(ticks * (1 - 0.2F * level(stack, ModEnchantments.QUICK_HANDS)))) : 0;
    }
    public static double getAimDownSightSpeed(ItemStack stack) { return level(stack, ModEnchantments.LIGHTWEIGHT) > 0 ? 1.5 : 1; }
    public static double getProjectileSpeedModifier(ItemStack stack) { return BowEnchantmentRules.speedMultiplier(level(stack, ModEnchantments.ACCELERATOR)); }
    public static float getAcceleratorDamage(ItemStack stack, float damage) { return BowEnchantmentRules.acceleratorDamage(damage, level(stack, ModEnchantments.ACCELERATOR)); }
    public static float getWitheredDamage(ItemStack stack, float damage) { return BowEnchantmentRules.witheredDamage(damage, level(stack, ModEnchantments.WITHERED)); }
    public static float getPuncturingChance(ItemStack stack) { return BowEnchantmentRules.criticalChance(level(stack, ModEnchantments.PUNCTURING)); }
}
