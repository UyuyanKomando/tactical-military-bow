package com.korkuluk.standalonebow;

import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;

public final class QuiverMenu extends ChestMenu {
    private final ItemStack quiver;
    public QuiverMenu(int id, Inventory inventory, ItemStack quiver) {
        super(MenuType.GENERIC_9x1, id, inventory, container(quiver), 1);
        this.quiver = quiver;
        for (int i = 0; i < 9; i++) {
            final int slot = i;
            replace(i, new Slot(getContainer(), i, 8 + i * 18, 18) {
                @Override public boolean mayPlace(ItemStack stack) { return slot < QuiverStorage.SLOTS && TacticalArrowItem.accepts(stack); }
                @Override public boolean mayPickup(Player player) { return slot < QuiverStorage.SLOTS; }
            });
        }
        for (int i = 9; i < slots.size(); i++) {
            Slot old = slots.get(i);
            replace(i, new Slot(old.container, old.getContainerSlot(), old.x, old.y) {
                @Override public boolean mayPickup(Player player) { return getItem() != quiver; }
                @Override public boolean mayPlace(ItemStack stack) { return getItem() != quiver; }
            });
        }
    }
    private void replace(int index, Slot slot) { slot.index = index; slots.set(index, slot); }
    @Override public void clicked(int slot, int button, ClickType type, Player player) {
        if (slot >= 0 && slot < slots.size() && slots.get(slot).getItem() == quiver) return;
        if (type == ClickType.SWAP && button >= 0 && button < player.getInventory().getContainerSize()
                && player.getInventory().getItem(button) == quiver) return;
        super.clicked(slot, button, type, player);
    }
    private static SimpleContainer container(ItemStack quiver) {
        var handler = QuiverStorage.contents(quiver);
        var container = new SimpleContainer(9);
        for (int i = 0; i < QuiverStorage.SLOTS; i++) container.setItem(i, handler.getStackInSlot(i));
        container.addListener(changed -> {
            for (int i = 0; i < QuiverStorage.SLOTS; i++) handler.setStackInSlot(i, changed.getItem(i));
            QuiverStorage.save(quiver, handler);
        });
        return container;
    }
    @Override public boolean stillValid(Player player) {
        return player.isAlive() && (player.getMainHandItem() == quiver || player.getOffhandItem() == quiver || QuiverStorage.equipped(player) == quiver);
    }
}
