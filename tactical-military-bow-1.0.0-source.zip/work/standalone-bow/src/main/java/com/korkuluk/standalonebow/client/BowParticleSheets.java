package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;

/** Direct textures avoid introducing common-side particle registries for client-only effects. */
final class BowParticleSheets {
    static final ParticleRenderType SPARK = sheet("spark");
    static final ParticleRenderType BLOOD = sheet("blood");
    private static ParticleRenderType sheet(String name) {
        return new ParticleRenderType() {
            public void begin(BufferBuilder buffer, TextureManager textures) {
                RenderSystem.depthMask(true);
                RenderSystem.disableBlend();
                RenderSystem.setShaderTexture(0, name.equals("spark")
                        ? new ResourceLocation("minecraft", "textures/particle/glow.png")
                        : new ResourceLocation("standalonebow", "textures/particle/blood.png"));
                buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
            }
            public void end(Tesselator tessellator) { tessellator.end(); }
        };
    }
    private BowParticleSheets() {}
}
