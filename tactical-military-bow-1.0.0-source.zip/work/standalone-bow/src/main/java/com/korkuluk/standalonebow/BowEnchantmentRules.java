package com.korkuluk.standalonebow;

/** Pure installed-JEG enchantment formulas used by the live helper. */
public final class BowEnchantmentRules {
    private BowEnchantmentRules() {}
    public static int inventoryReloadInterval(int base, int quickHands) {
        int interval = Math.max(1, base - 3 * quickHands);
        if (quickHands == 1) return Math.max(1, Math.round(interval * 0.75F));
        if (quickHands >= 2) return Math.max(1, Math.round(interval * 0.5F));
        return interval;
    }
    public static double speedMultiplier(int accelerator) { return 1 + 0.5 * accelerator; }
    public static float acceleratorDamage(float damage, int accelerator) { return damage + damage * (0.1F * accelerator); }
    public static float witheredDamage(float damage, int withered) { return damage * (float)Math.pow(1.15, withered); }
    public static float criticalChance(int puncturing) { return puncturing * 0.05F; }
    public static boolean consumeLoadedArrow(int reclaimed, int randomRoll) {
        return reclaimed == 0 || randomRoll != 0;
    }
}
