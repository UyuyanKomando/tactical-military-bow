package com.korkuluk.standalonebow;

import net.minecraftforge.common.ForgeConfigSpec;

/** Bow-relevant original common configuration names and installed Tester baseline defaults. */
public final class Config {
    public static final Common COMMON;
    public static final ForgeConfigSpec SPEC;
    static { var pair = new ForgeConfigSpec.Builder().configure(Common::new); COMMON = pair.getLeft(); SPEC = pair.getRight(); }
    public static final class Common {
        public final ForgeConfigSpec.BooleanValue gunDurability, gunJamming, underwaterFiring, gunAdvantage,
                enableHeadShots, mobsDropHelmets, playersDropHelmets, ignoreLeaves, enableKnockback, improvedHitboxes,
                setFireToBlocks, enableGlassBreaking, enableWoodBreaking, fragileBlockDrops, drawAnimation;
        public final ForgeConfigSpec.DoubleValue growBoundingBoxAmount, criticalDamageMultiplier, fragileBlockBreakChance, woodBlockBreakChance;
        public final ForgeConfigSpec.IntValue playerGunfireVolume;
        Common(ForgeConfigSpec.Builder builder) {
            builder.push("gameplay");
            gunDurability = builder.define("gunDurability", true); gunJamming = builder.define("gunJamming", true);
            underwaterFiring = builder.define("underwaterFiring", false); gunAdvantage = builder.define("gunAdvantage", true);
            enableHeadShots = builder.define("enableHeadShots", true); mobsDropHelmets = builder.define("mobsDropHelmets", true);
            playersDropHelmets = builder.define("playersDropHelmets", true); ignoreLeaves = builder.define("ignoreLeaves", true);
            enableKnockback = builder.define("enableKnockback", true); improvedHitboxes = builder.define("improvedHitboxes", false);
            drawAnimation = builder.define("drawAnimation", true);
            growBoundingBoxAmount = builder.defineInRange("growBoundingBoxAmount", 0.3, 0, 1);
            criticalDamageMultiplier = builder.defineInRange("criticalDamageMultiplier", 1.5, 1, Double.MAX_VALUE);
            builder.push("griefing");
            setFireToBlocks = builder.define("setFireToBlocks", true); enableGlassBreaking = builder.define("enableGlassBreaking", true);
            enableWoodBreaking = builder.define("enableWoodBreaking", true); fragileBlockDrops = builder.define("fragileBlockDrops", true);
            fragileBlockBreakChance = builder.defineInRange("fragileBlockBreakChance", 1.0, 0, 1);
            woodBlockBreakChance = builder.defineInRange("woodBlockBreakChance", 0.1, 0, 1);
            builder.pop(2); builder.push("world");
            playerGunfireVolume = builder.defineInRange("playerGunfireVolume", 8, 1, 10); builder.pop();
        }
    }
    private Config() {}
}
