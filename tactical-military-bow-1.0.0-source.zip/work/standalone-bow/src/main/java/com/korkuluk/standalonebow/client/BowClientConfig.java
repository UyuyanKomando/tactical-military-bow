package com.korkuluk.standalonebow.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** Loaded by automatic client subscriber registration during mod construction, before config loading. */
@Mod.EventBusSubscriber(modid = "standalonebow", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class BowClientConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue SHOW_AMMO, SHOW_TIMERS, AIM_HIDES_TIMERS,
            DYNAMIC_CROSSHAIR, CAMERA_RECOIL, SPRINT_ANIMATION, ENABLE_BLOOD;
    public static final ForgeConfigSpec.DoubleValue ADS_SENSITIVITY, SWAY_SENSITIVITY, BOBBING_INTENSITY;
    public static final ForgeConfigSpec.IntValue AMMO_X_OFFSET, AMMO_Y_OFFSET;
    static {
        var builder = new ForgeConfigSpec.Builder();
        builder.push("display");
        SHOW_AMMO = builder.define("showAmmoGUI", true);
        SHOW_TIMERS = builder.define("showTimersGUI", true);
        AIM_HIDES_TIMERS = builder.define("aimingHidesTimers", true);
        DYNAMIC_CROSSHAIR = builder.define("dynamicCrosshair", true);
        CAMERA_RECOIL = builder.define("enableCameraRecoil", true);
        SPRINT_ANIMATION = builder.define("sprintingAnimation", true);
        ENABLE_BLOOD = builder.define("enableBlood", false);
        SWAY_SENSITIVITY = builder.defineInRange("swaySensitivity", 0.3, 0, 1);
        BOBBING_INTENSITY = builder.defineInRange("bobbingIntensity", 1.0, 0, 2);
        AMMO_X_OFFSET = builder.defineInRange("displayAmmoGUIXOffset", 0, -10000, 10000);
        AMMO_Y_OFFSET = builder.defineInRange("displayAmmoGUIYOffset", 0, -10000, 10000);
        builder.pop().push("controls");
        ADS_SENSITIVITY = builder.defineInRange("aimDownSightSensitivity", 0.75, 0, 1);
        builder.pop();
        SPEC = builder.build();
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, SPEC, "standalonebow-client.toml");
    }
    private BowClientConfig() {}
}
