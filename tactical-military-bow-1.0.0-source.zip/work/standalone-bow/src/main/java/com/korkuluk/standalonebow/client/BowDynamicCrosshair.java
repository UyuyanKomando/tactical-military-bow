package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;

/**
 * Author: NineZero
 */
public class BowDynamicCrosshair
{
    private static final ResourceLocation DYNAMIC_CROSSHAIR_H = new ResourceLocation("standalonebow", "textures/crosshair/dynamic_horizontal.png");
    private static final ResourceLocation DYNAMIC_CROSSHAIR_V = new ResourceLocation("standalonebow", "textures/crosshair/dynamic_vertical.png");
    private static final ResourceLocation DOT_CROSSHAIR = new ResourceLocation("standalonebow", "textures/crosshair/dot.png");

    private long lastFire = -1;
    private int spreadCount, sprintTransition;
    private float scale;
    private float prevScale;
    private float fireBloom;
    private float prevFireBloom;

    public BowDynamicCrosshair()
    {

    }

    public void tick()
    {
        var mc = Minecraft.getInstance();
        boolean sprinting = mc.player != null && mc.player.isSprinting() && !BowClient.aiming()
                && !BowClient.charging() && !BowClient.drawing();
        sprintTransition = sprinting ? Math.min(5, sprintTransition + 1) : Math.max(0, sprintTransition - 1);
        this.prevScale = this.scale;
        this.scale *= 0.5F;
        this.prevFireBloom = this.fireBloom;
        if (this.fireBloom > 0)
        {
        	float i = 300F/50;
        	this.fireBloom -= Math.min(3F/(Math.max(i,1)), this.fireBloom);
        }
    }

    public void onGunFired()
    {
        long now = System.currentTimeMillis();
        if (lastFire >= 0) spreadCount = now - lastFire < 300
                ? Math.min(10, spreadCount + (BowClient.aiming() ? 1 : 2)) : 0;
        lastFire = now;
        this.prevScale = 0.0F;
        this.scale = 0.6F;
        this.fireBloom = 3.0F;
    }

    public void render(Minecraft mc, PoseStack stack, int windowWidth, int windowHeight, float partialTicks)
    {
        float alpha = 1.0F;// - (float) AimingHandler.get().getNormalisedAdsProgress();
        float size1 = 7F;
        float size2 = 1F;
        float spread = 0F;
    	float scaleMultiplier = 2.0F;
    	boolean renderDot = false;
        float aiming = BowClient.aim(partialTicks);
        float nextSpread = lastFire < 0 ? 0 : (spreadCount + 1F + aiming) / 10F;
        float modifier = (nextSpread + 0.1F) * Math.min(Mth.lerp(partialTicks, prevFireBloom, fireBloom), 1F);
        modifier = (float)Mth.lerp(sprintTransition / 5F * 0.5, modifier, 1.0F);
        // The bow has zero base/min spread. Preserve AT_MIN_SPREAD's original predicate.
        renderDot = nextSpread * modifier <= 0;

        float baseScale = 1F + (Mth.lerp(partialTicks, this.prevScale, this.scale)*scaleMultiplier);
        float scale = (float) (baseScale + (spread*(2F*1.0)));
        float scaleSize = (scale/6F)+1.15F;
        float crosshairBaseTightness = (float) (0.8-(1.0/2));
        float finalSpreadTranslate = (float) ( (Mth.lerp(0.95,scaleSize-1,Math.log(scaleSize)))*(2.8F) );
        //float rawSpreadTranslation = (scaleSize-1)*(3.0F);
        //float finalSpreadTranslate = (float) (Mth.lerp(0.0,rawSpreadTranslation,Math.log(rawSpreadTranslation+1)-1));
        
        double windowCenteredX = Math.round((windowWidth) / 2F)-0.5;
        double windowCenteredY = Math.round((windowHeight) / 2F)-0.5;

        boolean blend = true;
        RenderSystem.enableBlend();
        if (blend)
            RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.ONE_MINUS_DST_COLOR, GlStateManager.DestFactor.ONE_MINUS_SRC_COLOR, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        BufferBuilder buffer = Tesselator.getInstance().getBuilder();

        // Left
        stack.pushPose();
        {
        	Matrix4f matrix = stack.last().pose();
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.setShaderTexture(0, DYNAMIC_CROSSHAIR_H);

            stack.translate(windowCenteredX, windowCenteredY, 0);
            stack.scale(scaleSize, 1, 1);
            stack.translate((-size1 / 2F) - (finalSpreadTranslate) + crosshairBaseTightness -0.0F, -size2 / 2F, 0);

            float sizeX = size1;
            float sizeY = size2;
            buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
            buffer.vertex(matrix, 0, sizeY, 0).uv(0, 1F/9F).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, sizeX, sizeY, 0).uv(1, 1F/9F).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, sizeX, 0, 0).uv(1, 0F/9F).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, 0, 0, 0).uv(0, 0F/9F).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            BufferUploader.drawWithShader(buffer.end());
        }
        stack.popPose();

        // Right
        stack.pushPose();
        {
        	Matrix4f matrix = stack.last().pose();
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.setShaderTexture(0, DYNAMIC_CROSSHAIR_H);

            stack.translate(windowCenteredX, windowCenteredY, 0);
            stack.scale(scaleSize, 1, 1);
            stack.translate((-size1 / 2F) + (finalSpreadTranslate) - crosshairBaseTightness, -size2 / 2F, 0);

            float sizeX = size1;
            float sizeY = size2;
            buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
            buffer.vertex(matrix, 0, sizeY, 0).uv(0, 9F/9F).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, sizeX, sizeY, 0).uv(1, 9F/9F).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, sizeX, 0, 0).uv(1, 8F/9F).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, 0, 0, 0).uv(0, 8F/9F).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            BufferUploader.drawWithShader(buffer.end());
        }
        stack.popPose();

        // Top
        stack.pushPose();
        {
        	Matrix4f matrix = stack.last().pose();
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.setShaderTexture(0, DYNAMIC_CROSSHAIR_V);

            stack.translate(windowCenteredX, windowCenteredY, 0);
            stack.scale(1, scaleSize, 1);
            stack.translate(-size2 / 2F, (-size1 / 2F) - (finalSpreadTranslate) + crosshairBaseTightness, 0);

            float sizeX = size2;
            float sizeY = size1;
            buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
            buffer.vertex(matrix, 0, sizeY, 0).uv(0F/9F, 1).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, sizeX, sizeY, 0).uv(1F/9F, 1).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, sizeX, 0, 0).uv(1F/9F, 0).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, 0, 0, 0).uv(0F/9F, 0).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            BufferUploader.drawWithShader(buffer.end());
        }
        stack.popPose();

        // Bottom
        stack.pushPose();
        {
        	Matrix4f matrix = stack.last().pose();
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.setShaderTexture(0, DYNAMIC_CROSSHAIR_V);

            stack.translate(windowCenteredX, windowCenteredY, 0);
            stack.scale(1, scaleSize, 1);
            stack.translate(-size2 / 2F -0.0F, (-size1 / 2F) + (finalSpreadTranslate) - crosshairBaseTightness, 0);

            float sizeX = size2;
            float sizeY = size1;
            buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
            buffer.vertex(matrix, 0, sizeY, 0).uv(8F/9F, 1).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, sizeX, sizeY, 0).uv(9F/9F, 1).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, sizeX, 0, 0).uv(9F/9F, 0).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, 0, 0, 0).uv(8F/9F, 0).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            BufferUploader.drawWithShader(buffer.end());
        }
        stack.popPose();

        // Center Dot (will be configurable)
        if (renderDot)
        {
        stack.pushPose();
        {
        	int dotSize = 9;
            RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.setShaderTexture(0, DOT_CROSSHAIR);
            Matrix4f matrix = stack.last().pose();
            stack.translate(windowCenteredX, windowCenteredY, 0);
            stack.translate(-dotSize / 2F, -dotSize / 2F, 0);
            buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
            buffer.vertex(matrix, 0, dotSize, 0).uv(0, 1).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, dotSize, dotSize, 0).uv(1, 1).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, dotSize, 0, 0).uv(1, 0).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            buffer.vertex(matrix, 0, 0, 0).uv(0, 0).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
            BufferUploader.drawWithShader(buffer.end());
        }
        stack.popPose();
        }

        if (blend)
        RenderSystem.defaultBlendFunc();

        RenderSystem.disableBlend();
    }
}

