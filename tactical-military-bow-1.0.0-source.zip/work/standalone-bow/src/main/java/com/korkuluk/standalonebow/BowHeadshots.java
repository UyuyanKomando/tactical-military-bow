package com.korkuluk.standalonebow;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Vanilla entity head geometry from JEG BoundingBoxManager and its MrCrayfish headshot helpers. */
public final class BowHeadshots {
    private BowHeadshots() {}
    public static AABB box(LivingEntity entity) {
        if (entity instanceof Player player) {
            AABB box = new AABB(-0.25, 0, -0.25, 0.25, 0.5, 0.25);
            if (player.isSwimming()) box = box.move(0, 0.1875, 0)
                    .move(Vec3.directionFromRotation(player.getXRot(), player.yBodyRot).normalize().scale(0.8));
            else box = box.move(0, player.isShiftKeyDown() ? 1.25 : 1.5, 0);
            double scale = 30.0 / 32;
            return new AABB(box.minX * scale, box.minY * scale, box.minZ * scale,
                    box.maxX * scale, box.maxY * scale, box.maxZ * scale);
        }
        var id = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        if (!id.getNamespace().equals("minecraft")) return null;
        return switch (id.getPath()) {
            case "zombie", "zombified_piglin", "husk", "piglin" -> child(entity, 10, 24);
            case "skeleton", "stray", "drowned" -> basic(10, 10, 24);
            case "creeper" -> basic(10, 10, 18);
            case "spider" -> rotated(entity, 10, 10, 5, 7, false, false);
            case "villager", "zombie_villager", "vindicator" -> entity.isBaby() ? null : basic(10, 9, 23);
            case "evoker", "pillager", "illusioner", "wandering_trader", "witch" -> basic(10, 9, 23);
            case "sheep" -> rotated(entity, 7.5, 8, 15, 9.5, false, false);
            case "chicken" -> rotated(entity, 4, 6, 9, 5, false, true);
            case "cow", "mooshroom" -> rotated(entity, 7.5, 8, 16, 10.5, false, true);
            case "pig" -> rotated(entity, 10, 10, 8, 10, false, true);
            case "horse", "skeleton_horse" -> rotated(entity, 10, 10, 26, 16, false, false);
            case "donkey" -> rotated(entity, 7.5, 8, 20, 13, false, false);
            case "mule" -> rotated(entity, 7.5, 8, 21, 14, false, false);
            case "llama", "trader_llama" -> rotated(entity, 10, 10, 26, 10, false, false);
            case "polar_bear" -> rotated(entity, 9, 9, 12, 20, false, false);
            case "snow_golem" -> basic(10, 10, 20.5);
            case "turtle" -> rotated(entity, 6, 5, 1, 10, false, false);
            case "iron_golem" -> rotated(entity, 10, 10, 33, 3.5, false, false);
            case "phantom" -> rotated(entity, 6, 3, 1.5, 6.5, true, false);
            case "hoglin", "zoglin" -> rotated(entity, 14, 16, 7, 19, false, false);
            case "wither_skeleton" -> basic(10, 10, 28);
            default -> null;
        };
    }
    private static AABB basic(double width, double height, double y) {
        return new AABB(-width / 32, y / 16, -width / 32, width / 32, (y + height) / 16, width / 32);
    }
    private static AABB child(LivingEntity entity, double width, double y) {
        AABB box = basic(width, width, y);
        return !entity.isBaby() ? box : new AABB(box.minX * 0.75, box.minY * 0.5, box.minZ * 0.75,
                box.maxX * 0.75, box.maxY * 0.565, box.maxZ * 0.75);
    }
    private static AABB rotated(LivingEntity entity, double width, double height, double y, double z,
                                boolean pitch, boolean excludeBaby) {
        if (excludeBaby && entity.isBaby()) return null;
        return basic(width, height, y).move(Vec3.directionFromRotation(pitch ? entity.getXRot() : 0,
                entity.yBodyRot).normalize().scale(z / 16));
    }
}
