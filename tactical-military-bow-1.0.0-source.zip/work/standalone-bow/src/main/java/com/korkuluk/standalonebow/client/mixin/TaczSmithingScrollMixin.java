package com.korkuluk.standalonebow.client.mixin;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "com.tacz.guns.client.gui.GunSmithTableScreen", remap = false)
public abstract class TaczSmithingScrollMixin {
    @Shadow private List<ResourceLocation> selectedRecipeList;

    // TaCZ 1.1.8 leaves this null when filtering removes every recipe.
    @Inject(method = {"mouseScrolled(DDD)Z", "m_6050_(DDD)Z"}, at = @At("HEAD"), cancellable = true, require = 1)
    private void standalonebow$skipEmptyRecipeScroll(double mouseX, double mouseY, double delta,
            CallbackInfoReturnable<Boolean> callback) {
        if (selectedRecipeList == null || selectedRecipeList.isEmpty()) {
            callback.setReturnValue(false);
        }
    }
}
