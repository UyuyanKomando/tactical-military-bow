package com.korkuluk.standalonebow;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class QuiverStorageCheck {
    private static int checks;
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
        checks++;
    }
    public static int verify() {
        checks = 0;
        ItemStack quiver = new ItemStack(Items.PAPER);
        check(QuiverStorage.count(quiver) == 0, "empty quiver");
        check(QuiverStorage.takeOne(quiver).isEmpty(), "empty extraction");
        check(QuiverStorage.insert(quiver, new ItemStack(Items.ARROW, 3)).getCount() == 3, "vanilla arrow rejected");
        var input = new ItemStack(StandaloneBow.NORMAL_ARROW.get(), 64);
        check(QuiverStorage.insert(quiver, input).isEmpty(), "insert first stack");
        check(input.getCount() == 64, "caller stack unchanged");
        for (int i = 1; i < 7; i++) check(QuiverStorage.insert(quiver, new ItemStack(StandaloneBow.NORMAL_ARROW.get(), 64)).isEmpty(), "fill slot " + i);
        check(QuiverStorage.count(quiver) == 448, "capacity");
        check(QuiverStorage.insert(quiver, new ItemStack(StandaloneBow.NORMAL_ARROW.get(), 12)).getCount() == 12, "full remainder");
        check(QuiverStorage.insert(quiver, new ItemStack(Items.DIAMOND, 3)).getCount() == 3, "nonarrow rejected");
        check(QuiverStorage.takeOne(quiver).getCount() == 1, "take one");
        check(QuiverStorage.count(quiver) == 447, "persisted consumption");
        var restored = ItemStack.of(quiver.save(new net.minecraft.nbt.CompoundTag()));
        check(QuiverStorage.count(restored) == 447, "NBT round trip");
        var handler = QuiverStorage.contents(quiver);
        handler.setStackInSlot(0, ItemStack.EMPTY);
        handler.setStackInSlot(1, new ItemStack(StandaloneBow.PIERCING_ARROW.get(), 5));
        QuiverStorage.save(quiver, handler);
        check(QuiverStorage.peek(quiver).is(StandaloneBow.PIERCING_ARROW.get()), "skip empty selected slot");
        QuiverStorage.cycle(quiver);
        check(QuiverStorage.selected(quiver) == 1, "cycle selected type");
        quiver.getOrCreateTag().putInt("QuiverSelected", -1);
        check(QuiverStorage.selected(quiver) == 6, "normalize selection");
        var snapshot = QuiverStorage.peek(quiver);
        snapshot.setCount(0);
        check(!QuiverStorage.peek(quiver).isEmpty(), "peek cannot mutate storage");
        return checks;
    }
}
