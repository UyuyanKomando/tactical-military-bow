package com.korkuluk.standalonebow;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.type.capability.ICurioItem;

public final class QuiverItem extends Item implements ICurioItem {
    public QuiverItem(Properties properties) { super(properties); }
    @Override public boolean canEquip(SlotContext context, ItemStack stack) { return context.identifier().equals("belt"); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        var stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            if (player.isShiftKeyDown()) {
                QuiverStorage.cycle(stack);
                player.displayClientMessage(QuiverStorage.peek(stack).getHoverName(), true);
            } else player.openMenu(new SimpleMenuProvider((id, inventory, owner) -> new QuiverMenu(id, inventory, stack), stack.getHoverName()));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
    @Override public boolean overrideOtherStackedOnMe(ItemStack quiver, ItemStack cursor, Slot slot,
            ClickAction action, Player player, SlotAccess access) {
        if (action != ClickAction.SECONDARY || !slot.allowModification(player)) return false;
        if (cursor.isEmpty()) {
            var handler = QuiverStorage.contents(quiver);
            int selected = QuiverStorage.ammoSlot(quiver, handler);
            if (selected >= 0) {
                if (access.set(handler.getStackInSlot(selected).copy())) {
                    handler.setStackInSlot(selected, ItemStack.EMPTY);
                    QuiverStorage.save(quiver, handler);
                }
            }
        } else {
            if (!(cursor.getItem() instanceof ArrowItem)) return false;
            access.set(QuiverStorage.insert(quiver, cursor));
        }
        slot.setChanged();
        return true;
    }
    @Override public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.standalonebow.quiver_count", QuiverStorage.count(stack), QuiverStorage.SLOTS * 64));
        var arrow = QuiverStorage.peek(stack);
        if (!arrow.isEmpty()) tooltip.add(arrow.getHoverName());
    }
}
