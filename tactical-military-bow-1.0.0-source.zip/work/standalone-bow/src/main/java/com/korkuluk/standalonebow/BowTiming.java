package com.korkuluk.standalonebow;

/** Pure server timing transitions, shared by live mechanics and executable boundary tests. */
public final class BowTiming {
    public enum Phase { IDLE, CHARGING, RELOADING }
    private Phase phase = Phase.IDLE;
    private long started;
    private long nextShot;
    private int reloadInterval = BowStats.RELOAD_INTERVAL;
    public Phase phase() { return phase; }
    public boolean ready(long now) { return now >= nextShot; }
    public boolean press(long now) {
        if (phase != Phase.IDLE || !ready(now)) return false;
        phase = Phase.CHARGING; started = now; return true;
    }
    public boolean reload(long now) {
        return reload(now, BowStats.RELOAD_INTERVAL);
    }
    public boolean reload(long now, int interval) {
        if (phase != Phase.IDLE) return false;
        phase = Phase.RELOADING; started = now; reloadInterval = Math.max(1, interval); return true;
    }
    public float charge(long now) {
        return phase == Phase.CHARGING ? BowStats.progress((int)Math.min(BowStats.MAX_CHARGE,
                Math.max(0, now - started))) : 0;
    }
    /** Zero means no shot. Every release ends the current draw, including a short tap. */
    public float release(long now) {
        if (phase != Phase.CHARGING) return 0;
        float charge = charge(now);
        boolean accepted = now - started >= BowStats.MIN_RELEASE_CHARGE && ready(now);
        phase = Phase.IDLE;
        if (!accepted) return 0;
        nextShot = now + BowStats.SHOT_INTERVAL;
        return charge;
    }
    /** True exactly once when a pending reload completes. */
    public boolean tick(long now) {
        if (phase != Phase.RELOADING || now - started <= reloadInterval) return false;
        phase = Phase.IDLE; return true;
    }
    public void cancel() { phase = Phase.IDLE; }
}
