package com.korkuluk.standalonebow;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Opt-in in-process checks for the authorized Tester world. No blocks/entities/inventory are changed. */
@Mod.EventBusSubscriber(modid = StandaloneBow.ID)
public final class CoreRuntimeChecks {
    private CoreRuntimeChecks() {}
    @SubscribeEvent public static void commands(RegisterCommandsEvent event) {
        event.getDispatcher().register(LiteralArgumentBuilder.<CommandSourceStack>literal("standalonebow")
                .requires(source -> source.hasPermission(2)).then(LiteralArgumentBuilder.<CommandSourceStack>literal("verify_core")
                        .executes(context -> {
                            int checks = verify(context.getSource().getServer().getLevel(Level.OVERWORLD));
                            context.getSource().sendSuccess(() -> Component.translatable("commands.standalonebow.verify_core", checks), false);
                            return checks;
                        })).then(LiteralArgumentBuilder.<CommandSourceStack>literal("verify_quiver")
                        .executes(context -> {
                            int checks = QuiverStorageCheck.verify();
                            context.getSource().sendSuccess(() -> Component.translatable("commands.standalonebow.verify_quiver", checks), false);
                            return checks;
                        })));
    }
    public static int verify(ServerLevel level) {
        int checks = 0;
        ItemStack bow = new ItemStack(StandaloneBow.BOW.get());
        check(bow.getMaxDamage() == 0 && !bow.isDamageableItem(), "bow has no durability"); checks++;
        check(StandaloneBow.BOW.get().getEnchantmentValue() == 5, "enchantability"); checks++;
        check(ModEnchantments.ACCELERATOR.get().getMaxLevel() == 2, "accelerator registry"); checks++;
        check(ModEnchantments.WITHERED.get().getMaxLevel() == 10, "withered registry"); checks++;
        check(ModEnchantments.INFINITY.get().isCurse() && ModEnchantments.INFINITY.get().isTreasureOnly()
                && !ModEnchantments.INFINITY.get().isDiscoverable(), "original infinity acquisition rules"); checks++;
        check(!ModEnchantments.ACCELERATOR.get().isCompatibleWith(ModEnchantments.PUNCTURING.get()), "projectile enchantment exclusion"); checks++;
        check(ModEnchantments.WITHERED.get().isCompatibleWith(ModEnchantments.INFINITY.get()), "boss enchantment compatibility"); checks++;
        check(ModEnchantments.ACCELERATOR.get().canEnchant(bow) && !ModEnchantments.ACCELERATOR.get().canEnchant(new ItemStack(Items.BOW)), "standalone-only category"); checks++;
        check(StandaloneBow.BOW.get().canApplyAtEnchantingTable(bow, Enchantments.FLAMING_ARROWS), "vanilla flame support"); checks++;
        bow.enchant(ModEnchantments.QUICK_HANDS.get(), 2);
        check(GunEnchantmentHelper.getReloadInterval(bow, 16) == 5, "live quick hands interval"); checks++;
        bow.enchant(ModEnchantments.ACCELERATOR.get(), 2);
        bow.enchant(ModEnchantments.WITHERED.get(), 1);
        bow.enchant(Enchantments.FLAMING_ARROWS, 1);
        var owner = FakePlayerFactory.getMinecraft(level);
        BowArrowEntity arrow = new BowArrowEntity(StandaloneBow.ARROW.get(), level);
        arrow.prepare(owner, bow, 0.35F);
        check(Math.abs(arrow.getDeltaMovement().length() - 16) < 0.00001, "live accelerator speed"); checks++;
        check(Math.abs(arrow.getShotDamage() - 4.83F) < 0.00001, "live damage formula ordering"); checks++;
        check(arrow.isFlamingShot() && !arrow.isFullyChargedShot(), "projectile flags"); checks++;
        var source = ModDamageTypes.projectile(arrow, owner);
        check(source.getDirectEntity() == arrow && source.getEntity() == owner, "direct and kill-credit attribution"); checks++;
        check(!source.is(DamageTypeTags.IS_PROJECTILE), "original bullet is not vanilla projectile-tagged"); checks++;
        check(Math.abs(source.getFoodExhaustion() - 0.05F) < 0.00001, "original bullet exhaustion"); checks++;
        check(source.getMsgId().startsWith("standalonebow.bullet."), "bullet death-message namespace"); checks++;
        ItemStack kit = new ItemStack(StandaloneBow.REPAIR_KIT.get());
        check(!StandaloneBow.BOW.get().isValidRepairItem(bow, kit)
                && !StandaloneBow.BOW.get().isValidRepairItem(bow, new ItemStack(Items.IRON_INGOT)), "original repair material gate"); checks++;
        ItemStack damaged = bow.copy();
        damaged.setDamageValue(100);
        damaged.getOrCreateTag().putInt("AmmoCount", 1);
        var anvil = new net.minecraft.world.inventory.AnvilMenu(0, owner.getInventory(), net.minecraft.world.inventory.ContainerLevelAccess.NULL);
        anvil.getSlot(0).set(damaged);
        anvil.getSlot(1).set(kit);
        anvil.slotsChanged(anvil.getSlot(0).container);
        ItemStack repaired = anvil.getSlot(2).getItem();
        check(repaired.isEmpty(), "indestructible bow rejects repair kit"); checks++;
        return checks;
    }
    private static void check(boolean valid, String description) {
        if (!valid) throw new IllegalStateException("Standalone bow runtime check failed: " + description);
    }
}
