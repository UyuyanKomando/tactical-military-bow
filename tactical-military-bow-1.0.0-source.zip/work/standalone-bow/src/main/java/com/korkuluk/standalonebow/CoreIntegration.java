package com.korkuluk.standalonebow;

/**
 * Core/client/master handoff. No JEG or Framework runtime dependency.
 *
 * Bootstrap: StandaloneBow registers BOW, ARROW, DYNAMIC_HELMET, SoundEvents, the independent
 * COMMON Config.SPEC, networking and original-name bow-compatible ModEnchantments:
 * QuickHands, Lightweight, Collateral, Reclaimed, Accelerator, Puncturing, AtlanticShooter,
 * Infinity, Withered. Original levels/costs/treasure/curse/category/compatibility rules retained.
 * TriggerFinger, OverCapacity and FireStarter are bow-rejected and not registered.
 *
 * CLIENT INTEGRATION REQUIRED
 * Install BowNetwork.clientStateReceiver/clientEntityImpactReceiver/clientBlockImpactReceiver
 * during physical-client setup. Callbacks run on the client main thread.
 * EntityImpact.hitType: 0=NORMAL, 1=HEADSHOT, 2=CRITICAL. bloodOnly=true is tracking-client blood;
 * false is shooter hitmarker/sound. BlockImpact has x/y/z/BlockPos/face for holes/debris/sounds.
 * Register ARROW and DYNAMIC_HELMET renderers; DynamicHelmet.getStoredStackData() is the
 * synchronized actual helmet stack. It flies then becomes an ItemEntity on the server.
 * Arrow exposes isFlamingShot/isFullyChargedShot/getShotDamage and Forge additional spawn data.
 * Use GunEnchantmentHelper.getReloadAnimationSpeed/getAimDownSightSpeed for client effects.
 * Before reload send Input(RELOAD_FIRST_PERSON) or Input(RELOAD_THIRD_PERSON) for sound exclusion.
 * Original pull/charge keyframes remain client-local. Do not duplicate FIRE: server sends
 * shooter volume 0.5 and remote configured volume minus 0.5 (installed configured volume=8).
 * Underwater halves remote volume/lowers pitch/adds bubble sound. ReloadStart at tick four,
 * reloadLoad twice at completion reproduces original inventory-fed ReloadTracker.
 *
 * INPUT/STATE API
 * BowNetwork.CHANNEL.sendToServer(new Input(Action)): PRESS, RELEASE, RELOAD, CANCEL,
 * AIM_START, AIM_STOP. Perspective actions append without changing initial enum ordinals.
 * CANCEL never shoots. Send on item changes/screens/disconnect/lost focus.
 * Server accepts only main-hand bows and uses latest vanilla-synchronized yaw/pitch.
 * State has entityId, aiming/charging/reloading/charge/ammo/shotSequence. Keep TPS per-entity
 * cache; initialize first sequence without replaying shots. Self/tracking/StartTracking and
 * idle ammo changes synchronize. Client hasArrow must honor the stack's IgnoreAmmo flag.
 * Animated server NBT includes IsDrawing/DrawnTick/IsAiming/IsRunning; equip draw=10 ticks,
 * reduced by QuickHands; a release during equip drawing is rejected as original JEG does.
 *
 * INSTALLED JEG 0.14.5 FIDELITY PASS
 * Base draw20, min release7, rate10, capacity1, regular minecraft:arrow only. Tipped/spectral
 * arrows were not original Gun.isAmmo matches and are deliberately not accepted.
 * Initial reload completes at tick17; QuickHands I at11, II at6 (both original reductions).
 * Successful shot consumes loaded ammo then immediately inventory-feeds replacement.
 * Reclaimed preserves loaded ammo on original zero roll; JEG Infinity supplies virtual arrows.
 * Creative/IgnoreAmmo bypass shot consumption; Infinity still requires loaded AmmoCount.
 * Speed8/Accelerator12 or16, gravity -0.04, life1000. Damage order:
 * (10+AdditionalDamage), Accelerator, Withered, charge, Puncturing critical, heavy, headshot2.5.
 * Fully charged crit particles do not imply vanilla randomized critical-arrow damage.
 * BulletDamageSource uses original exhaustion0.05/nonplayer scaling/untagged bullet flags,
 * direct projectile and causing shooter attribution, with original death-message suffixes.
 * Collateral hits every intercepted entity; ordinary arrows hit nearest. Player shots reset
 * target invulnerableTime. Passenger/PlayerOwned/friendly-PvP guards apply.
 * Original vanilla head boxes and optional20-tick ping history, mob helmet chance/wear/blindness/
 * flight/drop/Binding Curse are ported. Player turtle-helmet death prevention is VERY_HEAVY-only
 * and never applies to this HEAVY compound bow. Heavy/very_heavy tags contain original vanilla types.
 * Block effects: fragile/wood chances/drops, ice-water, game events, neighbors/scheduled tick,
 * target redstone/stats/advancement, bells and original post-movement flame forward trace.
 * Crit/flame/ash/bubble/damage particles, flyby sounds and entity/block impact packets are present.
 * Installed0.14.5 removed the clone's random wear-jam preShoot branch; no invented2.5% jam roll.
 * Existing IsJammed clears after cooldown as installed GunItem does. Broken bows reject at
 * maxDamage-1; durability is charged before ammo consumption, respecting gunDurability.
 *
 * MASTER RESOURCE REQUIREMENTS
 * Master integrating pistol.cock/ui.medal.headshot/entity.bullet.close/entity.bullet.hit.
 * Verify combat-rifle reloadStart/reloadEnd, impact sounds/particles and enchantment/death text.
 * Named holder resource: data/standalonebow/damage_type/bullet.json:
 * {"exhaustion":0.05,"message_id":"standalonebow.bullet","scaling":"when_caused_by_living_non_player"}.
 * Do NOT tag as minecraft:is_projectile (installed JEG has no bullet damage tags).
 * Master supplied the named bullet resource and translations; normal gameplay uses its registry
 * holder. The direct-holder fallback only applies if that required resource is missing.
 *
 * VERIFICATION/GAPS
 * Gradle check passed, including BowTimingTest26 checks, BowEnchantmentRulesTest22 checks and
 * client BowDrawLockCheck; compileJava passed on Gradle8.8/official Forge47.4.10.
 * No jar packaged/installed by this pass.
 * Opt-in /standalonebow verify_core in approved Tester runs20 non-destructive runtime checks,
 * including real AnvilMenu repair output and ammo/enchantment preservation.
 * The core agent has not executed this command; no standalone server/EULA action was taken.
 * Still requires Tester collision/target/bell/helmet/shield/armor/ammo/multiplayer verification,
 * new client impact receivers and helmet renderer. No full exact runtime-fidelity claim.
 * Differences: SimpleChannel replaces Framework; elapsed server ticks replace client
 * ChargeProgress and original silent wall-clock ShootTracker (changes lag behavior).
 * Repair kit item and original anvil material eligibility are implemented. Vanilla anvil repairs
 * 32/128 durability per kit and preserves ammo/enchantments. Master supplied exact original
 * repair_kit model/texture/translations (21 verified original assets). No recipe is registered:
 * the original recipe requires eight jeg:scrap, which this bow-only port does not register.
 * JEG scrap recycling/loot acquisition is not transplanted or silently replaced with vanilla iron.
 * The kit is available through creative combat tab and /give standalonebow:repair_kit.
 * Dynamic Gun JSON/NBT overrides, modifier/debug/attachment and external JEG mob/effect hooks
 * are not ported. Ordinary compound bow stacks contain no GunId/Gun/Custom overrides;
 * installed base JSON stats are already reproduced. Overrides matter for custom data packs,
 * command-edited weapons and debugging, not unmodified default bow inventory use. A custom
 * data pack changing compound_bow.json still changes original JEG but not this static port.
 * Base bow has no attachment slots or potion effect.
 * DynamicHelmet persistence reads synchronized stack, correcting original stale-stack bug.
 */
public final class CoreIntegration {
    private CoreIntegration() {}
}
