package com.korkuluk.standalonebow;

import java.util.Map;
import java.util.WeakHashMap;
import java.util.LinkedList;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** Original optional 20-tick player hitbox history. Disabled by the installed default configuration. */
public final class BoundingBoxManager {
    private static final Map<ServerPlayer, LinkedList<AABB>> BOXES = new WeakHashMap<>();
    public static AABB getBoundingBox(ServerPlayer target, ServerPlayer shooter) {
        var boxes = BOXES.get(target);
        int ping = (int)Math.floor(shooter.latency / 1000.0 * 20 + 0.5);
        return boxes == null || boxes.isEmpty() ? target.getBoundingBox() : boxes.get(Mth.clamp(ping, 0, boxes.size() - 1));
    }
    @SubscribeEvent public void tick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        if (!Config.COMMON.improvedHitboxes.get() || player.isSpectator()) { BOXES.remove(player); return; }
        var boxes = BOXES.computeIfAbsent(player, ignored -> new LinkedList<>());
        boxes.addFirst(player.getBoundingBox()); if (boxes.size() > 20) boxes.removeLast();
    }
    @SubscribeEvent public void logout(PlayerEvent.PlayerLoggedOutEvent event) { BOXES.remove(event.getEntity()); }
    @SubscribeEvent public void stop(ServerStoppedEvent event) { BOXES.clear(); }
}
