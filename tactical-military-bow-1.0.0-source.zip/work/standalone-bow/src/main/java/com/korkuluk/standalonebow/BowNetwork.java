package com.korkuluk.standalonebow;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraft.server.level.ServerPlayer;
import java.util.function.Consumer;
import net.minecraftforge.network.simple.SimpleChannel;

public final class BowNetwork {
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(StandaloneBow.ID, "main"), () -> "1", "1"::equals, "1"::equals);
    public enum Action { PRESS, RELEASE, RELOAD, CANCEL, AIM_START, AIM_STOP, RELOAD_FIRST_PERSON, RELOAD_THIRD_PERSON, CYCLE_ARROW }
    /** Install on the physical client during setup; invoked on its main thread. */
    public static Consumer<State> clientStateReceiver = state -> {};
    public static Consumer<EntityImpact> clientEntityImpactReceiver = impact -> {};
    public static Consumer<BlockImpact> clientBlockImpactReceiver = impact -> {};
    public record EntityImpact(double x, double y, double z, int hitType, boolean player, boolean bloodOnly) {
        static void encode(EntityImpact p, FriendlyByteBuf b) {
            b.writeDouble(p.x); b.writeDouble(p.y); b.writeDouble(p.z); b.writeVarInt(p.hitType);
            b.writeBoolean(p.player); b.writeBoolean(p.bloodOnly);
        }
        static EntityImpact decode(FriendlyByteBuf b) { return new EntityImpact(b.readDouble(), b.readDouble(), b.readDouble(), b.readVarInt(), b.readBoolean(), b.readBoolean()); }
        static void handle(EntityImpact p, Supplier<NetworkEvent.Context> s) {
            var c = s.get(); c.enqueueWork(() -> clientEntityImpactReceiver.accept(p)); c.setPacketHandled(true);
        }
    }
    public record BlockImpact(double x, double y, double z, net.minecraft.core.BlockPos pos, net.minecraft.core.Direction face) {
        static void encode(BlockImpact p, FriendlyByteBuf b) { b.writeDouble(p.x); b.writeDouble(p.y); b.writeDouble(p.z); b.writeBlockPos(p.pos); b.writeEnum(p.face); }
        static BlockImpact decode(FriendlyByteBuf b) { return new BlockImpact(b.readDouble(), b.readDouble(), b.readDouble(), b.readBlockPos(), b.readEnum(net.minecraft.core.Direction.class)); }
        static void handle(BlockImpact p, Supplier<NetworkEvent.Context> s) {
            var c = s.get(); c.enqueueWork(() -> clientBlockImpactReceiver.accept(p)); c.setPacketHandled(true);
        }
    }
    public record State(int entityId, boolean aiming, boolean charging, boolean reloading,
                        float charge, int ammo, int shotSequence) {
        static void encode(State state, FriendlyByteBuf buf) {
            buf.writeVarInt(state.entityId); buf.writeBoolean(state.aiming); buf.writeBoolean(state.charging);
            buf.writeBoolean(state.reloading); buf.writeFloat(state.charge); buf.writeVarInt(state.ammo);
            buf.writeVarInt(state.shotSequence);
        }
        static State decode(FriendlyByteBuf buf) {
            return new State(buf.readVarInt(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean(),
                    buf.readFloat(), buf.readVarInt(), buf.readVarInt());
        }
        static void handle(State state, Supplier<NetworkEvent.Context> supplier) {
            var context = supplier.get();
            context.enqueueWork(() -> clientStateReceiver.accept(state));
            context.setPacketHandled(true);
        }
    }
    public static void sync(ServerPlayer player, State state) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player), state);
    }
    public record Input(Action action) {
        public static void encode(Input packet, FriendlyByteBuf buffer) { buffer.writeEnum(packet.action); }
        public static Input decode(FriendlyByteBuf buffer) { return new Input(buffer.readEnum(Action.class)); }
        public static void handle(Input packet, Supplier<NetworkEvent.Context> supplier) {
            var context = supplier.get();
            context.enqueueWork(() -> {
                var player = context.getSender();
                if (player == null) return;
                switch (packet.action) {
                    case PRESS -> BowMechanics.press(player);
                    case RELEASE -> BowMechanics.release(player);
                    case RELOAD -> BowMechanics.reload(player, true);
                    case CANCEL -> BowMechanics.cancel(player);
                    case AIM_START -> BowMechanics.aim(player, true);
                    case AIM_STOP -> BowMechanics.aim(player, false);
                    case CYCLE_ARROW -> ArrowSelection.cycle(player);
                    case RELOAD_FIRST_PERSON, RELOAD_THIRD_PERSON -> {
                        if (player.getMainHandItem().getItem() instanceof CompoundBowItem)
                            player.getMainHandItem().getOrCreateTag().putBoolean("IsFirstPersonReload", packet.action == Action.RELOAD_FIRST_PERSON);
                    }
                }
            });
            context.setPacketHandled(true);
        }
    }
    public static void register() {
        CHANNEL.messageBuilder(Input.class, 0, NetworkDirection.PLAY_TO_SERVER)
                .encoder(Input::encode).decoder(Input::decode).consumerNetworkThread(Input::handle).add();
        CHANNEL.messageBuilder(State.class, 1, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(State::encode).decoder(State::decode).consumerNetworkThread(State::handle).add();
        CHANNEL.messageBuilder(EntityImpact.class, 2, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(EntityImpact::encode).decoder(EntityImpact::decode).consumerNetworkThread(EntityImpact::handle).add();
        CHANNEL.messageBuilder(BlockImpact.class, 3, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(BlockImpact::encode).decoder(BlockImpact::decode).consumerNetworkThread(BlockImpact::handle).add();
    }
    private BowNetwork() {}
}
