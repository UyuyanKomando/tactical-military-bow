package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.ForgeRegistries;
import com.korkuluk.standalonebow.DynamicHelmet;

import java.util.Optional;

public class BowHelmetRenderer extends EntityRenderer<DynamicHelmet> {

    private final HumanoidModel<?> defaultModel;

    public BowHelmetRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.defaultModel = new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR));
    }

    @Override
    public void render(DynamicHelmet entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int light) {
        ItemStack stack = entity.getStoredStackData();
        Item item = stack.getItem();

        poseStack.pushPose();
        poseStack.translate(0, 0, 0);
        poseStack.popPose();

        poseStack.pushPose();
        float rotation = (entity.tickCount + partialTick) * 20f;
        poseStack.mulPose(Axis.YP.rotationDegrees((float) (45 + rotation * 0.5)));
        poseStack.mulPose(Axis.XP.rotationDegrees((float) (rotation * 1.5)));
        poseStack.mulPose(Axis.ZP.rotationDegrees(180));

        if (!(item instanceof ArmorItem)) {
            Minecraft mc = Minecraft.getInstance();
            ItemRenderer itemRenderer = mc.getItemRenderer();

            poseStack.pushPose();

             poseStack.scale(0.65F, 0.65F, 0.65F);
             itemRenderer.renderStatic(
                    stack,
                    ItemDisplayContext.HEAD,
                    light,
                    OverlayTexture.NO_OVERLAY,
                    poseStack,
                    buffer,
                    entity.level(),
                    entity.getId()
            );

            poseStack.popPose();
        }
        else if (item instanceof ArmorItem armorItem && armorItem.getEquipmentSlot() == EquipmentSlot.HEAD) {
            poseStack.scale(1.5F, 1.5F, 1.5F);
            ModelPart model = Minecraft.getInstance().getEntityModels().bakeLayer(ModelLayers.PLAYER_INNER_ARMOR);
            defaultModel.getHead().setPos(0, -10F, 0);

            defaultModel.head.visible = true;
            defaultModel.hat.visible = true;

            defaultModel.body.visible = false;
            defaultModel.leftArm.visible = false;
            defaultModel.rightArm.visible = false;
            defaultModel.leftLeg.visible = false;
            defaultModel.rightLeg.visible = false;

            ResourceLocation texture = getArmorTexture(armorItem);

            if (armorItem.getMaterial() == ArmorMaterials.LEATHER) {
                int color = 0xA06540;
                CompoundTag display = stack.getTagElement("display");
                if (display != null && display.contains("color", 99)) {
                    color = display.getInt("color");
                }

                float r = (color >> 16 & 255) / 255.0F;
                float g = (color >> 8 & 255) / 255.0F;
                float b = (color & 255) / 255.0F;

                defaultModel.renderToBuffer(
                        poseStack,
                        buffer.getBuffer(RenderType.armorCutoutNoCull(texture)),
                        light,
                        OverlayTexture.NO_OVERLAY,
                        r, g, b, 1.0F
                );

                // Optionally render overlay (gray stitching)
                ResourceLocation overlay = new ResourceLocation("minecraft", "textures/models/armor/leather_layer_1_overlay.png");
                defaultModel.renderToBuffer(
                        poseStack,
                        buffer.getBuffer(RenderType.armorCutoutNoCull(overlay)),
                        light,
                        OverlayTexture.NO_OVERLAY,
                        1.0F, 1.0F, 1.0F, 1.0F
                );
            } else {
                defaultModel.renderToBuffer(
                        poseStack,
                        buffer.getBuffer(RenderType.armorCutoutNoCull(texture)),
                        light,
                        OverlayTexture.NO_OVERLAY,
                        1.0F, 1.0F, 1.0F, 1.0F
                );
            }
        }
        poseStack.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(DynamicHelmet entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }

    private ResourceLocation getArmorTexture(ArmorItem armorItem) {
        String materialName = armorItem.getMaterial().getName();
        String layer = "1";

        String texturePath;
        String namespace;

        if (materialName.contains(":")) {
            String[] parts = materialName.split(":");
            namespace = parts[0];
            texturePath = parts[1];
        } else {
            ResourceLocation itemKey = ForgeRegistries.ITEMS.getKey(armorItem);
            namespace = (itemKey != null) ? itemKey.getNamespace() : "minecraft";
            texturePath = materialName;
        }

        ResourceLocation texture = new ResourceLocation(
                namespace,
                "textures/models/armor/" + texturePath + "_layer_" + layer + ".png"
        );

        Minecraft client = Minecraft.getInstance();
        Optional<Resource> resource = client.getResourceManager().getResource(texture);

        if (resource.isPresent()) {
            return texture;
        } else {
            return new ResourceLocation("minecraft", "textures/models/armor/iron_layer_" + layer + ".png");
        }
    }
}



