package com.korkuluk.standalonebow.client;

/** Pure original default recoil envelope for boundary verification without launching Minecraft. */
public final class BowRecoilMath {
    private BowRecoilMath() {}
    public static double adsReduction(float ads) { return 1 - 0.2F * ads; }
    public static double normal(float cooldown) {
        if (cooldown >= 0.8) {
            float amount = (1 - cooldown) / 0.2F;
            return 1 - (--amount) * amount * amount * amount;
        }
        float amount = cooldown / 0.8F;
        return amount < 0.5 ? 2 * amount * amount : -1 + (4 - 2 * amount) * amount;
    }
}
