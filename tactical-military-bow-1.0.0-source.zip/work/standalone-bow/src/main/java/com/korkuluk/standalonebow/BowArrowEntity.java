package com.korkuluk.standalonebow;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.entity.IEntityAdditionalSpawnData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.tags.TagKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import java.util.ArrayList;
import java.util.List;
import net.minecraftforge.network.PacketDistributor;

/** Fixed-speed projectile; vanilla arrow drag and speed-derived damage do not match JEG. */
public class BowArrowEntity extends Projectile implements IEntityAdditionalSpawnData, software.bernie.geckolib.animatable.GeoEntity {
    private final software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache animationCache =
            software.bernie.geckolib.util.GeckoLibUtil.createInstanceCache(this);
    @Override public software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache getAnimatableInstanceCache() { return animationCache; }
    @Override public void registerControllers(software.bernie.geckolib.core.animation.AnimatableManager.ControllerRegistrar controllers) {}
    private float damage;
    private boolean flaming;
    private boolean charged;
    private int age;
    private boolean collateral;
    private float criticalChance;
    private String arrowKind = "normal";
    private boolean detonated;
    private boolean preciseClientMotion;
    public String arrowKind() { return arrowKind; }
    private static final TagKey<EntityType<?>> HEAVY = TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation(StandaloneBow.ID, "heavy"));
    private static final TagKey<EntityType<?>> VERY_HEAVY = TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation(StandaloneBow.ID, "very_heavy"));
    public float getShotDamage() { return damage; }
    public boolean isFlamingShot() { return flaming; }
    public boolean isFullyChargedShot() { return charged; }
    public BowArrowEntity(EntityType<? extends BowArrowEntity> type, Level level) { super(type, level); }
    public void prepare(ServerPlayer player, ItemStack weapon, float charge) {
        setOwner(player);
        setPos((player.xOld + player.getX()) / 2, (player.yOld + player.getY()) / 2 + player.getEyeHeight(),
                (player.zOld + player.getZ()) / 2);
        setDeltaMovement(player.getLookAngle().scale(BowStats.SPEED * GunEnchantmentHelper.getProjectileSpeedModifier(weapon)));
        damage = CompoundBowItem.fullChargeDamage(weapon) * charge;
        arrowKind = TacticalArrowItem.loadedKind(weapon);
        damage = ArrowProfile.directDamage(arrowKind, damage);
        criticalChance = GunEnchantmentHelper.getPuncturingChance(weapon);
        collateral = GunEnchantmentHelper.level(weapon, ModEnchantments.COLLATERAL) > 0;
        flaming = weapon.getEnchantmentLevel(Enchantments.FLAMING_ARROWS) > 0;
        charged = charge == 1F;
    }
    @Override protected void defineSynchedData() {}
    @Override public void lerpMotion(double x, double y, double z) {
        // Vanilla velocity packets clamp each component to 3.9; this projectile travels faster.
        if (!preciseClientMotion) super.lerpMotion(x, y, z);
    }
    @Override public void tick() {
        super.tick();
        ++age;
        Vec3 start = position();
        Vec3 end = start.add(getDeltaMovement());
        if (!level().isClientSide) {
            HitResult block = clip(start, end);
            Vec3 limit = block.getType() == HitResult.Type.MISS ? end : block.getLocation();
            List<Hit> hits = hits(start, limit);
            if ((!collateral || arrowKind.equals("explosive")) && hits.size() > 1) {
                Hit nearest = hits.stream().min(java.util.Comparator.comparingDouble(hit -> start.distanceToSqr(hit.position))).orElseThrow();
                hits = List.of(nearest);
            }
            if (!hits.isEmpty()) {
                for (Hit hit : hits) hitEntity(hit);
            } else if (block instanceof BlockHitResult hit && block.getType() != HitResult.Type.MISS) {
                if (arrowKind.equals("explosive")) detonate(hit.getLocation());
                else BlockImpactHandler.onHit(this, hit);
            }
            if (detonated) return;
            if (level() instanceof ServerLevel server && age > 1) {
                if (charged) server.sendParticles(ParticleTypes.CRIT, start.x, start.y, start.z, 1, 0, 0, 0, 0);
                if (flaming) {
                    server.sendParticles(ParticleTypes.LAVA, start.x, start.y, start.z, 3, 0, 0, 0, 0);
                    server.sendParticles(ParticleTypes.ASH, start.x, start.y, start.z, 1, 0, 0, 0, 0);
                    server.sendParticles(ParticleTypes.WHITE_ASH, start.x, start.y, start.z, 1, 0, 0, 0, 0);
                }
                if (isUnderWater()) server.sendParticles(ParticleTypes.BUBBLE, start.x, start.y, start.z, 2, 0.1, 0.1, 0.1, 0);
            }
        }
        setPos(end.x, end.y, end.z);
        setDeltaMovement(getDeltaMovement().add(0, BowStats.GRAVITY, 0));
        Vec3 motion = getDeltaMovement();
        setYRot((float)Math.toDegrees(Math.atan2(motion.x, motion.z)));
        setXRot((float)Math.toDegrees(Math.atan2(motion.y, motion.horizontalDistance())));
        // Original ArrowProjectileEntity performs a second forward block trace AFTER base movement.
        if (!level().isClientSide && flaming && Config.COMMON.setFireToBlocks.get()) {
            HitResult forward = clip(position(), position().add(getDeltaMovement()));
            if (forward instanceof BlockHitResult hit && forward.getType() != HitResult.Type.MISS)
                BlockImpactHandler.ignite(this, hit);
        }
        if (arrowKind.equals("explosive") && age >= ArrowProfile.EXPLOSION_TIMEOUT) detonate(position());
        if (age >= BowStats.PROJECTILE_LIFE) discard();
    }
    private void detonate(Vec3 position) {
        if (detonated || level().isClientSide) return;
        detonated = true;
        TaczArrowExplosion.detonate(this, position);
        discard();
    }
    private HitResult clip(Vec3 start, Vec3 end) {
        return level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this) {
            @Override public VoxelShape getBlockShape(BlockState state, BlockGetter getter, BlockPos pos) {
                return Config.COMMON.ignoreLeaves.get() && state.getBlock() instanceof LeavesBlock ? Shapes.empty() : super.getBlockShape(state, getter, pos);
            }
        });
    }
    private record Hit(Entity entity, Vec3 position, boolean headshot) {}
    private List<Hit> hits(Vec3 start, Vec3 end) {
        List<Hit> hits = new ArrayList<>();
        for (Entity entity : level().getEntities(this, getBoundingBox().expandTowards(getDeltaMovement()).inflate(1),
                candidate -> candidate != getOwner() && candidate.isAlive() && candidate.isPickable() && !candidate.isSpectator())) {
            AABB body = entity.getBoundingBox();
            if (Config.COMMON.improvedHitboxes.get() && entity instanceof ServerPlayer target && getOwner() instanceof ServerPlayer shooter)
                body = BoundingBoxManager.getBoundingBox(target, shooter);
            body = body.expandTowards(0, entity instanceof net.minecraft.world.entity.player.Player
                    && !entity.isCrouching() ? 0.0625 : 0, 0);
            Vec3 hit = body.clip(start, end).orElse(null);
            if (hit == null) {
                double growth = Config.COMMON.growBoundingBoxAmount.get();
                Vec3 grown = body.inflate(growth, 0, growth).clip(start, end).orElse(null);
                if (grown != null && clip(start, grown).getType() == HitResult.Type.MISS) hit = grown;
            }
            boolean headshot = false;
            if (Config.COMMON.enableHeadShots.get() && entity instanceof LivingEntity living) {
                AABB head = BowHeadshots.box(living);
                if (head != null) {
                    head = head.move(body.getCenter().x, body.minY, body.getCenter().z);
                    Vec3 headHit = head.clip(start, end).orElse(null);
                    double growth = Config.COMMON.growBoundingBoxAmount.get();
                    if (headHit == null) headHit = head.inflate(growth, 0, growth).clip(start, end).orElse(null);
                    if (headHit != null && (hit == null || headHit.distanceTo(hit) < 0.5)) {
                        hit = headHit; headshot = true;
                        ItemStack helmet = living.getItemBySlot(EquipmentSlot.HEAD);
                        if (!helmet.isEmpty()) helmetHit(living, helmet);
                    }
                }
            }
            if (hit != null) hits.add(new Hit(entity, hit, headshot));
        }
        if (!collateral) {
            for (Entity entity : level().getEntities(this, getBoundingBox().expandTowards(getDeltaMovement()).inflate(3),
                    candidate -> candidate != getOwner() && candidate instanceof Player && candidate.isPickable()))
                level().playSound(getOwner() instanceof Player player ? player : null, this,
                        StandaloneBow.BULLET_CLOSE.get(), net.minecraft.sounds.SoundSource.PLAYERS, 0.7F, 0F);
        }
        return hits;
    }
    private boolean ignoreEntity(Entity entity) {
        return (entity instanceof LivingEntity living && living.isDeadOrDying()) || entity.getTags().contains("PlayerOwned")
                || (getOwner() != null && (entity.hasPassenger(getOwner()) || entity.hasIndirectPassenger(getOwner())))
                || (entity instanceof Player target && getOwner() instanceof Player shooter && !shooter.canHarmPlayer(target));
    }
    private void hitEntity(Hit hit) {
        Entity entity = hit.entity;
        if (ignoreEntity(entity)) return;
        boolean critical = random.nextFloat() < criticalChance;
        float amount = damage * (critical ? Config.COMMON.criticalDamageMultiplier.get().floatValue() : 1);
        if (Config.COMMON.gunAdvantage.get()) {
            if (entity.getType().is(HEAVY)) amount *= 1.25F;
            else if (entity.getType().is(VERY_HEAVY)) amount *= 0.5F;
        }
        if (hit.headshot) amount *= BowStats.HEADSHOT_MULTIPLIER;
        // The turtle-helmet life-saving branch is VERY_HEAVY-weapon-only; this HEAVY bow never enters it.
        var source = entity instanceof EnderMan && getOwner() instanceof LivingEntity owner
                ? damageSources().mobProjectile(this, owner) : ModDamageTypes.projectile(this, getOwner());
        boolean damaged = entity.hurt(source, amount);
        if (!Config.COMMON.enableKnockback.get()) entity.setDeltaMovement(0, 0, 0);
        if (flaming) entity.setSecondsOnFire(5);
        if (damaged && entity instanceof LivingEntity && level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.DAMAGE_INDICATOR, entity.getX(), entity.getY(), entity.getZ(), (int)amount / 2,
                    entity.getBbWidth() / 2, entity.getBbHeight() / 2, entity.getBbWidth() / 2, 0.1);
            if (getOwner() instanceof ServerPlayer shooter)
                BowNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> shooter), new BowNetwork.EntityImpact(hit.position.x,
                        hit.position.y, hit.position.z, (hit.headshot ? 1 : 0) | (critical ? 2 : 0)
                                | (!entity.isAlive() ? 4 : 0), entity instanceof Player, false));
            BowNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> entity), new BowNetwork.EntityImpact(hit.position.x,
                    hit.position.y, hit.position.z, 0, entity instanceof Player, true));
        }
        if (getOwner() instanceof Player) entity.invulnerableTime = 0;
        if (arrowKind.equals("explosive")) detonate(hit.position);
        else if (!collateral) discard();
    }
    private void helmetHit(LivingEntity entity, ItemStack helmet) {
        if (entity instanceof Player || !Config.COMMON.mobsDropHelmets.get()) return;
        if (entity.getTags().contains("EliteGunner") && random.nextBoolean()) return;
        if (entity.getType().is(VERY_HEAVY) || random.nextFloat() >= 0.4F) return;
        if (random.nextBoolean()) {
            removeHelmet(entity, helmet);
            entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
        }
        if (helmet.getMaxDamage() - helmet.getDamageValue() <= 1) {
            helmet.hurtAndBreak(1, entity, living -> living.broadcastBreakEvent(EquipmentSlot.HEAD));
            entity.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
        } else helmet.setDamageValue(helmet.getMaxDamage() - 1);
    }
    private void removeHelmet(LivingEntity entity, ItemStack helmet) {
        if (ignoreEntity(entity) || helmet.getEnchantmentLevel(Enchantments.BINDING_CURSE) > 0) return;
        entity.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
        if (helmet.isEmpty()) return;
        level().playSound(null, entity.getOnPos(), StandaloneBow.MEDAL_HEADSHOT.get(), net.minecraft.sounds.SoundSource.PLAYERS, 1, 1);
        DynamicHelmet flying = new DynamicHelmet(level(), entity.getX(), entity.getEyeY() - 0.5, entity.getZ(), helmet);
        flying.setXRot(entity.getXRot()); flying.setYRot(entity.getYRot());
        flying.setDeltaMovement((random.nextDouble() - 0.5) * 0.3, 0.5 + random.nextDouble() * 0.2, (random.nextDouble() - 0.5) * 0.3);
        level().addFreshEntity(flying);
    }
    @Override public void writeSpawnData(FriendlyByteBuf buffer) {
        buffer.writeFloat(damage); buffer.writeBoolean(flaming); buffer.writeBoolean(charged); buffer.writeVarInt(age);
        buffer.writeUtf(arrowKind);
        Vec3 motion = getDeltaMovement();
        buffer.writeDouble(motion.x); buffer.writeDouble(motion.y); buffer.writeDouble(motion.z);
    }
    @Override public void readSpawnData(FriendlyByteBuf buffer) {
        damage = buffer.readFloat(); flaming = buffer.readBoolean(); charged = buffer.readBoolean(); age = buffer.readVarInt();
        // Spawn data restores the full vector before client-side ballistic simulation begins.
        arrowKind = buffer.readUtf();
        setDeltaMovement(buffer.readDouble(), buffer.readDouble(), buffer.readDouble());
        preciseClientMotion = true;
    }
    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("Damage", damage); tag.putBoolean("Flaming", flaming);
        tag.putBoolean("Charged", charged); tag.putInt("Age", age);
        tag.putBoolean("Collateral", collateral); tag.putFloat("CriticalChance", criticalChance);
        tag.putString("ArrowType", arrowKind); tag.putBoolean("Detonated", detonated);
    }
    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        damage = tag.getFloat("Damage"); flaming = tag.getBoolean("Flaming");
        charged = tag.getBoolean("Charged"); age = tag.getInt("Age");
        collateral = tag.getBoolean("Collateral"); criticalChance = tag.getFloat("CriticalChance");
        String kind = tag.getString("ArrowType");
        arrowKind = kind.equals("piercing") || kind.equals("explosive") ? kind : "normal";
        detonated = tag.getBoolean("Detonated");
    }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
