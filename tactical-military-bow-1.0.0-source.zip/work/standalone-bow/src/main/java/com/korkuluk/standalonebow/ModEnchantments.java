package com.korkuluk.standalonebow;

import com.korkuluk.standalonebow.enchantment.*;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Only enchantments accepted by original AnimatedBowItem are registered. */
public final class ModEnchantments {
    public static final DeferredRegister<Enchantment> REGISTER = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, StandaloneBow.ID);
    public static final RegistryObject<Enchantment> QUICK_HANDS = REGISTER.register("quick_hands", QuickHandsEnchantment::new);
    public static final RegistryObject<Enchantment> LIGHTWEIGHT = REGISTER.register("lightweight", LightweightEnchantment::new);
    public static final RegistryObject<Enchantment> COLLATERAL = REGISTER.register("collateral", CollateralEnchantment::new);
    public static final RegistryObject<Enchantment> RECLAIMED = REGISTER.register("reclaimed", ReclaimedEnchantment::new);
    public static final RegistryObject<Enchantment> ACCELERATOR = REGISTER.register("accelerator", AcceleratorEnchantment::new);
    public static final RegistryObject<Enchantment> PUNCTURING = REGISTER.register("puncturing", PuncturingEnchantment::new);
    public static final RegistryObject<Enchantment> ATLANTIC_SHOOTER = REGISTER.register("atlantic_shooter", AtlanticShooterEnchantment::new);
    public static final RegistryObject<Enchantment> INFINITY = REGISTER.register("infinity", InfinityEnchantment::new);
    public static final RegistryObject<Enchantment> WITHERED = REGISTER.register("withered", WitheredEnchantment::new);
    private ModEnchantments() {}
}
