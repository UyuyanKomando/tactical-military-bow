package com.korkuluk.standalonebow;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/** Original DynamicHelmet flight/drop behavior, with synchronized stack also used after NBT reload. */
public class DynamicHelmet extends Entity {
    private static final EntityDataAccessor<ItemStack> STORED_STACK = SynchedEntityData.defineId(DynamicHelmet.class, EntityDataSerializers.ITEM_STACK);
    public DynamicHelmet(EntityType<?> type, Level level) { super(type, level); }
    public DynamicHelmet(Level level, double x, double y, double z, ItemStack stack) {
        this(StandaloneBow.DYNAMIC_HELMET.get(), level); setPos(x, y, z); setStoredStackData(stack.copy());
    }
    public void setStoredStackData(ItemStack stack) { entityData.set(STORED_STACK, stack.copy()); }
    public ItemStack getStoredStackData() { return entityData.get(STORED_STACK); }
    public ItemStack getStoredStack() { return getStoredStackData(); }
    @Override protected void defineSynchedData() { entityData.define(STORED_STACK, ItemStack.EMPTY); }
    @Override protected void readAdditionalSaveData(CompoundTag tag) { setStoredStackData(ItemStack.of(tag.getCompound("HatStack"))); }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { tag.put("HatStack", getStoredStack().save(new CompoundTag())); }
    @Override public void tick() {
        super.tick();
        if (!isNoGravity()) setDeltaMovement(getDeltaMovement().add(0, -0.04, 0));
        move(MoverType.SELF, getDeltaMovement());
        if (onGround() && !level().isClientSide) {
            level().addFreshEntity(new ItemEntity(level(), getX(), getY(), getZ(), getStoredStack().copy())); discard();
        }
    }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
