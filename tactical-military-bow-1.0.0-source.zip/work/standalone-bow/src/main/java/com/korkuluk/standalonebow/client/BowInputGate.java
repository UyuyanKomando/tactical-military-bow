package com.korkuluk.standalonebow.client;

public final class BowInputGate {
    private BowInputGate() {}
    public static boolean inGame(boolean windowActive, boolean mouseGrabbed, boolean screenAbsent, boolean overlayAbsent) {
        return windowActive && mouseGrabbed && screenAbsent && overlayAbsent;
    }
    public static boolean cancelRelease(boolean bowActive, boolean inGame, boolean drawing) {
        return !bowActive || !inGame || drawing;
    }
}
