package com.korkuluk.standalonebow.client;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Client boundary implemented by the core mod; never send packets from rendering. */
public interface BowClientBridge {
    boolean isBow(ItemStack stack);
    boolean hasArrow(Player player, ItemStack stack);
    boolean isCharging(Player player, ItemStack stack);
    boolean isAiming(Player player);
    void setAiming(boolean aiming);
    void setCharging(boolean charging);
    default float animationSpeed(ItemStack stack) { return 1; }
    default int drawTimer(ItemStack stack) { return 10; }
    default double aimSpeed(ItemStack stack) { return 1; }
    default boolean drawAnimationEnabled() { return true; }
    default int ammo(Player player, ItemStack stack) { return stack.getTag() == null ? 0 : stack.getTag().getInt("AmmoCount"); }
    default boolean isReloading(Player player, ItemStack stack) { return false; }
    default void reload() {}
    default void cancelCharge() { setCharging(false); }
}
