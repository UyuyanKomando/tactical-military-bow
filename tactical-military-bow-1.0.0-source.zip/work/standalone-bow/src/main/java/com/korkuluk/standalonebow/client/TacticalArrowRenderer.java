package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.TacticalArrowItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public final class TacticalArrowRenderer extends GeoItemRenderer<TacticalArrowItem> {
    public TacticalArrowRenderer() {
        super(new GeoModel<>() {
            @Override public ResourceLocation getModelResource(TacticalArrowItem item) {
                return new ResourceLocation("standalonebow", "geo/item/" + item.kind() + "_arrow.geo.json");
            }
            @Override public ResourceLocation getTextureResource(TacticalArrowItem item) {
                return new ResourceLocation("standalonebow", "textures/item/arrow_palette.png");
            }
            @Override public ResourceLocation getAnimationResource(TacticalArrowItem item) {
                return new ResourceLocation("standalonebow", "animations/item/arrows.animation.json");
            }
        });
    }
}
