package com.korkuluk.standalonebow;

public final class ArrowProfileTest {
    private static int checks;
    private static void equal(float actual, float expected) {
        if (Math.abs(actual - expected) > 0.0001F) throw new AssertionError(actual + " != " + expected);
        checks++;
    }
    public static void main(String[] args) {
        equal(ArrowProfile.directDamage("normal", 20), 20);
        equal(ArrowProfile.directDamage("piercing", 20), 35);
        equal(ArrowProfile.directDamage("explosive", 20), 20);
        equal(ArrowProfile.directDamage("piercing", 10), 17.5F);
        equal(ArrowProfile.directDamage("piercing", 20) * 1.5F, 52.5F);
        equal(ArrowProfile.directDamage("normal", 0), 0);
        equal(ArrowProfile.EXPLOSION_DAMAGE, 50);
        equal(ArrowProfile.EXPLOSION_RADIUS, 6);
        equal(ArrowProfile.EXPLOSION_TIMEOUT, 600);
        System.out.println("ArrowProfileTest: " + checks + " checks passed");
    }
}
