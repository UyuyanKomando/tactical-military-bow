package com.korkuluk.standalonebow.client;

/** Executable boundary checks; no game client or test framework required. */
public final class BowDrawLockCheck {
    public static void main(String[] args) {
        BowDrawLock lock = new BowDrawLock();
        lock.equip();
        for (int tick = 1; tick <= 10; tick++) {
            lock.tick(10);
            require(lock.drawing(), "default lock cleared on tick " + tick);
        }
        lock.tick(10);
        require(!lock.drawing(), "default lock did not clear on tick 11");
        lock.equip();
        for (int tick = 1; tick <= 8; tick++) {
            lock.tick(8);
            require(lock.drawing(), "Quick Hands I lock cleared early");
        }
        lock.tick(8);
        require(!lock.drawing(), "Quick Hands I lock did not clear");
        lock.equip();
        lock.tick(0);
        require(!lock.drawing(), "disabled draw animation still locks input");
        lock.equip();
        lock.tick(10);
        require(lock.drawing(), "re-equipping did not reset draw lock");
        float[] cooldowns = {1, 0.9F, 0.8F, 0.6F, 0.4F, 0.2F, 0};
        double[] expected = {0, 0.9375, 1, 0.875, 0.5, 0.125, 0};
        for (int sample = 0; sample < cooldowns.length; sample++)
            close(BowRecoilMath.normal(cooldowns[sample]), expected[sample], "recoil sample " + cooldowns[sample]);
        close(BowRecoilMath.adsReduction(0), 1, "hip recoil");
        close(BowRecoilMath.adsReduction(1), 0.8, "ADS recoil");
        require(BowInputGate.inGame(true, true, true, true), "focused gameplay blocked");
        require(!BowInputGate.inGame(false, true, true, true), "focus loss allowed input");
        require(!BowInputGate.inGame(true, false, true, true), "released mouse allowed input");
        require(!BowInputGate.inGame(true, true, false, true), "pause screen allowed input");
        require(!BowInputGate.inGame(true, true, true, false), "overlay allowed input");
        require(BowInputGate.cancelRelease(true, false, false), "focus loss released a shot");
        require(BowInputGate.cancelRelease(false, true, false), "unequip released a shot");
        require(BowInputGate.cancelRelease(true, true, true), "draw lock released a shot");
        require(!BowInputGate.cancelRelease(true, true, false), "valid release was canceled");
        for (int sample = 0; sample <= 1000; sample++) {
            double value = BowRecoilMath.normal(sample / 1000F);
            require(value >= -0.000001 && value <= 1.000001, "recoil envelope out of range");
        }
        System.out.println("Draw lock checks passed: ticks 1-10 locked, tick 11 clear; accelerated/disabled/re-equip boundaries.");
        System.out.println("Recoil checks passed: quartic rise, quadratic return, 20% ADS reduction and envelope bounds.");
        System.out.println("Input checks passed: focus/mouse/pause/overlay guards and CANCEL versus RELEASE boundaries.");
    }
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private static void close(double actual, double expected, String message) {
        require(Math.abs(actual - expected) < 0.000001, message + ": " + actual + " != " + expected);
    }
}
