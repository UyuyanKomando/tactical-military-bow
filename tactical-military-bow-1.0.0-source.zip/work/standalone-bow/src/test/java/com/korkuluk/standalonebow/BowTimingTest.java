package com.korkuluk.standalonebow;

/** Run with plain javac/java; no Minecraft launch or external test dependency required. */
public final class BowTimingTest {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        check(BowStats.DAMAGE == 20, "base damage is twenty");
        check(BowStats.DAMAGE * BowStats.HEADSHOT_MULTIPLIER == 30, "headshot deals 150 percent damage");
        BowTiming timing = new BowTiming();
        check(timing.release(0) == 0, "release without press");
        check(timing.press(100), "begin draw");
        check(!timing.press(103), "duplicate press must not reset start");
        check(timing.release(106) == 0, "six ticks must not fire");
        check(timing.phase() == BowTiming.Phase.IDLE, "short release clears draw");
        check(timing.press(200), "begin minimum draw");
        check(Math.abs(timing.release(207) - 0.35F) < 0.00001F, "seven ticks fires at 35 percent");
        check(timing.release(208) == 0, "duplicate release must not fire");
        check(!timing.press(216), "cooldown rejects tick nine after shot");
        check(timing.press(217), "cooldown permits tick ten after shot");
        check(timing.charge(236) < 1, "nineteen ticks below full draw");
        check(timing.charge(237) == 1, "twenty ticks full draw");
        check(timing.charge(10000) == 1, "long draw stays capped");
        check(timing.release(10000) == 1, "full release retains capped charge");
        check(timing.reload(10001), "reload may begin during cooldown");
        check(!timing.press(10002), "drawing cannot interrupt active reload");
        check(!timing.tick(10017), "reload incomplete at sixteen elapsed ticks");
        check(timing.tick(10018), "reload completes at seventeen elapsed ticks");
        check(!timing.tick(10019), "reload completes only once");
        check(timing.reload(10100), "begin cancellable reload");
        timing.cancel();
        check(!timing.tick(10117), "cancelled reload must not load");
        check(timing.press(10200), "begin cancellable draw");
        timing.cancel();
        check(timing.release(10220) == 0, "cancelled draw must not shoot");
        check(timing.reload(10300), "second reload");
        check(!timing.reload(10310), "duplicate reload cannot reset timer");
        check(timing.tick(10317), "duplicate packet does not delay reload");
        System.out.println("BowTimingTest: " + checks + " checks passed");
    }
}
