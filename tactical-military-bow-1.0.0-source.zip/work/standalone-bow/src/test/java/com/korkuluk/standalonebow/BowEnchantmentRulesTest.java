package com.korkuluk.standalonebow;

public final class BowEnchantmentRulesTest {
    private static int checks;
    private static void check(boolean valid, String message) { checks++; if (!valid) throw new AssertionError(message); }
    private static void near(float actual, float expected, String message) { check(Math.abs(actual - expected) < 0.00001F, message); }
    public static void main(String[] args) {
        check(BowEnchantmentRules.inventoryReloadInterval(16, 0) == 16, "unenhanced reload interval");
        check(BowEnchantmentRules.inventoryReloadInterval(16, 1) == 10, "quick hands one applies both original reductions");
        check(BowEnchantmentRules.inventoryReloadInterval(16, 2) == 5, "quick hands two applies both original reductions");
        check(BowEnchantmentRules.inventoryReloadInterval(1, 2) == 1, "reload minimum one tick");
        BowTiming timing = new BowTiming();
        check(timing.reload(100, BowEnchantmentRules.inventoryReloadInterval(16, 1)), "begin enchanted reload");
        check(!timing.tick(110), "quick hands one not complete at interval");
        check(timing.tick(111), "quick hands one completes strictly after interval");
        check(timing.reload(200, BowEnchantmentRules.inventoryReloadInterval(16, 2)), "begin quick hands two reload");
        check(!timing.tick(205) && timing.tick(206), "quick hands two completes on tick six");
        check(BowEnchantmentRules.speedMultiplier(0) * 8 == 8, "base speed");
        check(BowEnchantmentRules.speedMultiplier(1) * 8 == 12, "accelerator one speed");
        check(BowEnchantmentRules.speedMultiplier(2) * 8 == 16, "accelerator two speed");
        near(BowEnchantmentRules.acceleratorDamage(10, 1), 11, "accelerator one damage");
        near(BowEnchantmentRules.acceleratorDamage(10, 2), 12, "accelerator two damage");
        near(BowEnchantmentRules.witheredDamage(10, 1), 11.5F, "withered one damage");
        near(BowEnchantmentRules.witheredDamage(10, 2), 13.225F, "withered exponential damage");
        near(BowEnchantmentRules.witheredDamage(BowEnchantmentRules.acceleratorDamage(10, 2), 1) * 0.35F,
                4.83F, "accelerator then withered then charge order");
        near(BowEnchantmentRules.criticalChance(4), 0.2F, "puncturing four chance");
        check(BowEnchantmentRules.consumeLoadedArrow(0, 0), "unenchanted always consumes");
        check(!BowEnchantmentRules.consumeLoadedArrow(1, 0), "reclaimed preserves on roll zero");
        check(BowEnchantmentRules.consumeLoadedArrow(1, 1), "reclaimed consumes other rolls");
        check(!BowEnchantmentRules.consumeLoadedArrow(2, 0), "reclaimed two preserves on roll zero");
        System.out.println("BowEnchantmentRulesTest: " + checks + " checks passed");
    }
}
