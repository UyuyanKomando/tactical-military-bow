$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$base = Join-Path $PSScriptRoot 'src/main/resources/assets/standalonebow/textures'
foreach ($relative in @('animated/gun/compound_bow.png','item/compound_bow.png')) {
    $file = Join-Path $base $relative
    $source = [Drawing.Bitmap]::new($file)
    $result = [Drawing.Bitmap]::new($source.Width,$source.Height)
    $scale = $source.Width / 128.0
    for ($y=0; $y -lt $source.Height; $y++) {
        for ($x=0; $x -lt $source.Width; $x++) {
            $c = $source.GetPixel($x,$y)
            $u = $x / $scale; $v = $y / $scale
            $r = [double]$c.R; $g = [double]$c.G; $b = [double]$c.B
            # Reticle sample, scope hardware and neutral metal retain their colors.
            $protected = ($u -ge 31 -and $u -lt 36 -and $v -lt 9) -or ($u -ge 82 -and $u -lt 83 -and $v -ge 5 -and $v -lt 6)
            $accent = $r -gt 35 -and $r -gt $g * 1.45 -and $r -gt $b * 1.35
            $riser = $u -ge 17 -and $u -lt 30 -and $v -lt 18 -and ([Math]::Max($r,[Math]::Max($g,$b))) -lt 100
            if ($c.A -gt 0 -and !$protected -and ($accent -or $riser)) {
                $shade = if($accent){[Math]::Min(1.35,[Math]::Max(.45,$r / 105.0))}else{[Math]::Min(1.1,[Math]::Max(.45,(.2126*$r+.7152*$g+.0722*$b)/40.0))}
                $r = 75*$shade; $g = 83*$shade; $b = 43*$shade
            } elseif ($c.A -gt 0 -and !$protected -and [Math]::Max($r,[Math]::Max($g,$b)) -lt 90) {
                $l = .2126*$r+.7152*$g+.0722*$b
                $r = $l*.94; $g = $l; $b = $l*1.06
            }
            $result.SetPixel($x,$y,[Drawing.Color]::FromArgb($c.A,[int][Math]::Min(255,$r),[int][Math]::Min(255,$g),[int][Math]::Min(255,$b)))
        }
    }
    $source.Dispose()
    $result.Save($file,[Drawing.Imaging.ImageFormat]::Png)
    $result.Dispose()
    Write-Output "Palette updated: $relative"
}
