const fs = require('fs'), path = require('path'), assert = require('assert');
const root = path.join(__dirname, 'src/main/resources/assets/standalonebow/lang');
const en = JSON.parse(fs.readFileSync(path.join(root, 'en_us.json'), 'utf8'));
const tr = JSON.parse(fs.readFileSync(path.join(root, 'tr_tr.json'), 'utf8'));
const additions = {
 'gui.standalonebow.reloading': ['Reloading', 'Dolduruluyor'],
 'key.standalonebow.reload': ['Reload', 'Doldur'],
 'key.standalonebow.inspect': ['Inspect', 'İncele'],
 'key.categories.standalonebow': ['Tactical Military Bow', 'Taktik Askerî Yay'],
 'settings.standalonebow.title': ['Compound Bow Settings', 'Makaralı Yay Ayarları'],
 'settings.standalonebow.ammo': ['Ammo HUD', 'Mühimmat HUD'],
 'settings.standalonebow.charge': ['Charge Bar', 'Çekiş Çubuğu'],
 'settings.standalonebow.hide_charge': ['Hide Charge in ADS', 'Nişanda Çekişi Gizle'],
 'settings.standalonebow.crosshair': ['Dynamic Crosshair', 'Dinamik Nişangah'],
 'settings.standalonebow.recoil': ['Camera Recoil', 'Kamera Tepmesi'],
 'settings.standalonebow.sprint': ['Sprint Animation', 'Koşma Animasyonu'],
 'settings.standalonebow.ads': ['ADS Sensitivity', 'Nişan Hassasiyeti'],
 'settings.standalonebow.sway': ['Sway Sensitivity', 'Salınım Hassasiyeti'],
 'settings.standalonebow.bob': ['Bobbing Intensity', 'Yürüme Salınımı'],
 'commands.standalonebow.verify_core': ['Standalone bow core: %s runtime checks passed', 'Bağımsız yay: %s çalışma zamanı kontrolü geçti'],
 'commands.standalonebow.verify_quiver': ['Quiver: %s runtime checks passed', 'Sadak: %s çalışma zamanı kontrolü geçti'],
 'tooltip.standalonebow.bow.description_1': ['Graphite frame with olive details.', 'Grafit gövde, zeytin yeşili detaylar.'],
 'enchantment.standalonebow.infinity.desc': ['Normal arrows no longer need reserve ammo to reload', 'Normal oklar için doldururken yedek mühimmat gerekmez']
};
for (const [key, values] of Object.entries(additions)) { en[key] = values[0]; tr[key] = values[1]; }
Object.assign(tr, {
 'key.standalonebow.interact': 'Etkileşim',
 'item.standalonebow.explosive_arrow': 'Patlayıcı Ok',
 'item.standalonebow.tactical_military_bow': 'Taktik Askerî Yay',
 'itemGroup.standalonebow': 'Taktik Askerî Yay',
 'item.standalonebow.repair_kit': 'Tamir Kiti',
 'chat.standalonebow.rocket_ride': 'Varlıkların üzerinde roket sürmek için eğilmelisin!',
 'chat.standalonebow.attachment_broke': 'Bir eklenti kırıldı',
 'chat.standalonebow.raid_flare_loaded': 'Baskın işaret fişeği yükledin!',
 'subtitle.standalonebow.gun_rustle': 'Silah Hışırtısı',
 'chat.standalonebow.flamethrower': 'Blokları ateşe vermek için eğilmelisin!',
 'chat.standalonebow.jam': 'Silahın tutukluk yaptı',
 'chat.standalonebow.infinity_disabled': 'Bu silaha Sonsuzluk uygulanamaz',
 'chat.standalonebow.flashlight_battery_dead': 'El fenerini şarj etmek için art arda sol tıkla!',
 'chat.standalonebow.disabled_flashlights': 'Bu sunucuda el fenerleri devre dışı!',
 'info.standalonebow.tooltip_item.repair_kit': 'Örste kullanıldığında silahları tamir eder!',
 'info.standalonebow.tooltip_item.compound_bow_blueprint': 'Bu plan, baskınlarda Rattlers grubundan düşer!'
});
const enchants = {
 atlantic_shooter: ['Atlantik Atıcısı', 'Suyun altında ateş etmeyi sağlar'],
 over_capacity: ['Ek Kapasite', 'Silahın mühimmat kapasitesini artırır'],
 lightweight: ['Hafiflik', 'Silah ağırlığını azaltarak nişan alma hızını artırır'],
 reclaimed: ['Geri Kazanım', 'Atış sırasında okun tüketilmeme ihtimalini artırır'],
 quick_hands: ['Hızlı Eller', 'Doldurma hızını artırır'],
 fire_starter: ['Ateş Başlatıcı', 'Mermiler çarptıkları blokları ve varlıkları ateşe verir'],
 withered: ['Solgunluk', 'Silahın hasarını artırır'],
 accelerator: ['Hızlandırıcı', 'Merminin hızını ve hasarını artırır'],
 puncturing: ['Delip Geçme', 'Kritik hasar ihtimali sağlar'],
 infinity: ['Sonsuzluk', 'Normal oklar için doldururken yedek mühimmat gerekmez'],
 trigger_finger: ['Seri Atış', 'Atış hızını artırır'],
 collateral: ['Çoklu İsabet', 'Merminin birden çok varlıktan geçmesini sağlar']
};
for (const [name, values] of Object.entries(enchants)) {
 tr['enchantment.standalonebow.' + name] = values[0];
 tr['enchantment.standalonebow.' + name + '.desc'] = values[1];
 if (!en['enchantment.standalonebow.' + name + '.desc']) en['enchantment.standalonebow.' + name + '.desc'] = values[0] === 'Sonsuzluk' ? additions['enchantment.standalonebow.infinity.desc'][0] : 'Increases weapon effectiveness';
}
const deaths = {
 killed: ['%1$s was taken down by %2$s', '%1$s, %2$s tarafından öldürüldü'],
 eliminated: ['%1$s was eliminated by %2$s', '%1$s, %2$s tarafından etkisiz hâle getirildi'],
 executed: ['%1$s was executed by %2$s', '%1$s, %2$s tarafından vuruldu'],
 annihilated: ['%1$s was annihilated by %2$s', '%1$s, %2$s tarafından yok edildi'],
 decimated: ['%1$s was decimated by %2$s', '%1$s, %2$s tarafından imha edildi']
};
for (const [name, values] of Object.entries(deaths)) for (const suffix of ['', '.player', '.item']) {
 const key = 'death.attack.standalonebow.bullet.' + name + suffix;
 en[key] = values[0]; tr[key] = values[1];
}
assert.deepStrictEqual(Object.keys(en).sort(), Object.keys(tr).sort());
for (const key of Object.keys(en)) {
 const placeholders = s => (s.match(/%(?:\d+\$)?[sd]/g) || []).sort();
 assert.deepStrictEqual(placeholders(en[key]), placeholders(tr[key]), key);
}
for (const [lang, values] of [['en_us', en], ['tr_tr', tr]]) fs.writeFileSync(path.join(root, lang + '.json'), JSON.stringify(values, null, 2) + '\n');
console.log('EN/TR parity and placeholders verified: ' + Object.keys(en).length + ' keys per language.');
