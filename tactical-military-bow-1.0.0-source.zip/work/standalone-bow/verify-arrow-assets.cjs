const fs = require('fs');
const path = require('path');
const assert = require('assert');
const resources = path.join(__dirname, 'src/main/resources');
const assets = path.join(resources, 'assets/standalonebow');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const base = read(path.join(assets, 'geo/item/gun/compound_bow.geo.json'))['minecraft:geometry'][0];
let checks = 0;
for (const kind of ['normal', 'piercing', 'explosive']) {
    const recipe = read(path.join(resources, 'data/standalonebow/recipes', kind + '_arrow.json'));
    assert.equal(recipe.type, 'tacz:gun_smith_table_crafting');
    assert.deepStrictEqual(recipe.result, {type: 'custom', group: 'tacz:explosives', item: {item: 'standalonebow:' + kind + '_arrow', count: 45}});
    const expected = {'minecraft:stick': 10, 'minecraft:iron_ingot': 2, 'minecraft:string': 10};
    if (kind !== 'normal') expected['minecraft:gold_ingot'] = 2;
    if (kind === 'explosive') expected['minecraft:gunpowder'] = 10;
    assert.deepStrictEqual(Object.fromEntries(recipe.materials.map(m => [m.item.item, m.count])), expected);
    const bow = read(path.join(assets, 'geo/item/gun/compound_bow_' + kind + '.geo.json'))['minecraft:geometry'][0];
    assert.deepStrictEqual(bow.bones.filter(b => !b.name.startsWith('custom_nocked_')), base.bones.filter(b => !b.name.startsWith('custom_nocked_')));
    const arrow = read(path.join(assets, 'geo/item/' + kind + '_arrow.geo.json'))['minecraft:geometry'][0];
    for (const geo of [bow, arrow]) {
        const names = new Set(geo.bones.map(b => b.name));
        assert.equal(names.size, geo.bones.length);
        for (const bone of geo.bones) {
            assert(!bone.parent || names.has(bone.parent), bone.name);
            for (const cube of bone.cubes || []) {
                assert(cube.size.every(n => Number.isFinite(n) && n >= 0));
                for (const face of Object.values(cube.uv)) assert([...face.uv, ...face.uv_size].every(Number.isFinite));
            }
        }
    }
    for (const lang of ['en_us', 'tr_tr']) assert(read(path.join(assets, 'lang/' + lang + '.json'))['item.standalonebow.' + kind + '_arrow']);
    assert(fs.existsSync(path.join(assets, 'models/item/' + kind + '_arrow.json')));
    checks += 8;
}
assert(fs.existsSync(path.join(assets, 'textures/item/arrow_palette.png')));
console.log('Arrow asset validation: ' + checks + ' groups passed; recipes, models, hierarchy, UVs, translations and unchanged bow body.');
