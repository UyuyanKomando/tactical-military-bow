const fs=require('fs'),path=require('path'),assert=require('assert');
const source=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../../work/standalone-bow/src/main/resources/assets/standalonebow/geo/item/gun/compound_bow.geo.json')));
const bones=source['minecraft:geometry'][0].bones.filter(b=>b.name.startsWith('custom_nocked_arrow'));
const clone=x=>JSON.parse(JSON.stringify(x));
const colors={shaft:[43,48,53],metal:[139,150,158],gold:[166,132,53],red:[152,34,40],vane:[67,73,79]};
function box(name,z,length,width,color){return {name,parent:'custom_nocked_arrow_root',pivot:[.06855,3.0898,z],cubes:[{origin:[.06855-width/2,3.0898-width/2,z],size:[width,width,length],previewColor:color}]};}
const variants=[];
for(const type of ['normal','piercing','explosive']){
 let bs=clone(bones);
 bs[0].parent=undefined;
 for(const b of bs)for(const c of b.cubes||[])c.previewColor=b.name.includes('yu')?colors.vane:b.name.includes('head')||b.name.includes('bone12')?colors.metal:b.name.includes('light')?colors.metal:colors.shaft;
 if(type==='piercing'){
   bs=bs.filter(b=>!b.name.includes('bone12'));
   const head=bs.find(b=>b.name==='custom_nocked_arrow_head');
   head.cubes=[];
   for(let i=0;i<12;i++) {const w=.06+i*.031;head.cubes.push({origin:[.06855-w/2,3.0898-w/2,-13.2675+i*.10],size:[w,w,.105],previewColor:i<3?colors.metal:colors.shaft});}
   head.cubes.push({origin:[-.1242185789,2.8970314211,-12.0939610356],size:[.3855371579,.3855371579,3.3132099504],pivot:[.06855,3.0898,-11.464451145],rotation:[0,0,45],previewColor:colors.shaft});
   bs.push(box('gold_identification_band',-11.80,.24,.48,colors.gold));
 }
 if(type==='explosive'){
   bs=bs.filter(b=>!b.name.includes('bone12'));
   const head=bs.find(b=>b.name==='custom_nocked_arrow_head');
   head.cubes=head.cubes.filter(c=>c.size[2]>3);
   bs.push(box('compact_payload',-12.35,1.1,.65,colors.shaft));
   bs.push(box('payload_front_cap',-12.45,.16,.68,colors.metal));
   bs.push(box('red_identification_band',-11.75,.22,.67,colors.red));
   for(let i=0;i<7;i++){const w=.06+i*.07;bs.push(box('tip_'+i,-13.2675+i*.12,.125,w,colors.metal));}
 }
 const preserved=bs.filter(b=>!b.name.includes('head')&&!b.name.includes('bone12')&&b.name.startsWith('custom_nocked_arrow'));
 for(const b of preserved){const original=bones.find(o=>o.name===b.name);assert.deepStrictEqual(b.cubes?.map(c=>[c.origin,c.size,c.rotation]),original.cubes?.map(c=>[c.origin,c.size,c.rotation]));}
 const model={type,bones:bs};fs.writeFileSync(path.join(__dirname,type+'.json'),JSON.stringify(model,null,2));variants.push(model);
}
fs.writeFileSync(path.join(__dirname,'variants.json'),JSON.stringify(variants));
console.log('Three preview-only variants; original shaft and tail geometry verified unchanged.');
