Add-Type -AssemblyName System.Drawing
$colors=@(@(43,48,53),@(139,150,158),@(166,132,53),@(152,34,40),@(67,73,79))
$bitmap=[Drawing.Bitmap]::new(40,8)
for($i=0;$i -lt 5;$i++){for($x=0;$x -lt 8;$x++){for($y=0;$y -lt 8;$y++){
 $c=$colors[$i];$bitmap.SetPixel($i*8+$x,$y,[Drawing.Color]::FromArgb($c[0],$c[1],$c[2]))
}}}
$bitmap.Save((Join-Path $PSScriptRoot 'arrow_palette.png'),[Drawing.Imaging.ImageFormat]::Png)
$bitmap.Dispose()
