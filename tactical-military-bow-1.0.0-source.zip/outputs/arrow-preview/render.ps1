$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$models=Get-Content (Join-Path $PSScriptRoot 'variants.json') -Raw | ConvertFrom-Json
$bmp=[Drawing.Bitmap]::new(1600,1050)
$g=[Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode=[Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.Clear([Drawing.Color]::FromArgb(232,236,239))
$font=[Drawing.Font]::new('Segoe UI',22,[Drawing.FontStyle]::Bold)
$small=[Drawing.Font]::new('Segoe UI',12)
$brush=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(40,46,52))
$g.DrawString('OK VARYANTLARI - 3D MODEL ONIZLEMESI',$font,$brush,45,25)
$g.DrawString('Ayni mevcut saft ve kuyruk; yalnizca uc ve ayirt edici bantlar farkli.',$small,$brush,48,70)
function Rotate($v,$pivot,$rot){
 if(!$rot){return ,$v}
 $v=@(($v[0]-$pivot[0]),($v[1]-$pivot[1]),($v[2]-$pivot[2]))
 foreach($axis in 0,1,2){$a=$rot[$axis]*[Math]::PI/180;if($axis -lt 2){$a=-$a};$s=[Math]::Sin($a);$c=[Math]::Cos($a)
 if($axis -eq 0){$y=$v[1]*$c-$v[2]*$s;$z=$v[1]*$s+$v[2]*$c;$v[1]=$y;$v[2]=$z}
 if($axis -eq 1){$x=$v[0]*$c+$v[2]*$s;$z=-$v[0]*$s+$v[2]*$c;$v[0]=$x;$v[2]=$z}
 if($axis -eq 2){$x=$v[0]*$c-$v[1]*$s;$y=$v[0]*$s+$v[1]*$c;$v[0]=$x;$v[1]=$y}
 }
 return ,@(($v[0]+$pivot[0]),($v[1]+$pivot[1]),($v[2]+$pivot[2]))
}
function DrawModel($model,$ox,$oy,$scale,$headOnly){
 $map=@{};foreach($b in $model.bones){$map[$b.name]=$b}
 $polys=[Collections.Generic.List[object]]::new()
 foreach($b in $model.bones){foreach($cube in $b.cubes){
 if($headOnly -and $cube.origin[2] -gt -8.7){continue}
 $pts=@()
 foreach($corner in @(@(0,0,0),@(1,0,0),@(1,1,0),@(0,1,0),@(0,0,1),@(1,0,1),@(1,1,1),@(0,1,1))){
 $v=@();for($i=0;$i -lt 3;$i++){$v+=($cube.origin[$i]+$cube.size[$i]*$corner[$i])}
 $v=Rotate $v $cube.pivot $cube.rotation
 $cur=$b;while($cur){$v=Rotate $v $cur.pivot $cur.rotation;$cur=if($cur.parent){$map[$cur.parent]}else{$null}}
 $pts+=,@(($ox+($v[2]+13.2675)*$scale),($oy-(($v[1]-3.0898)*.87+($v[0]-.06855)*.5)*$scale),($v[0]*.87-$v[1]*.5))
 }
 $f=0;foreach($ids in @(@(0,1,2,3),@(4,5,6,7),@(0,4,7,3),@(1,5,6,2),@(3,2,6,7),@(0,1,5,4))){
 $poly=[Drawing.PointF[]]@($ids|ForEach-Object{[Drawing.PointF]::new($pts[$_][0],$pts[$_][1])})
 $depth=($ids|ForEach-Object{$pts[$_][2]}|Measure-Object -Average).Average
 $factor=@(.83,1.0,.72,.9,1.12,.65)[$f];$f++
 $col=@($cube.previewColor|ForEach-Object{[int][Math]::Min(255,$_*$factor)})
 $polys.Add(@{p=$poly;d=$depth;c=$col})
 }
 }}
 foreach($p in ($polys|Sort-Object d)){$br=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb($p.c[0],$p.c[1],$p.c[2]));$g.FillPolygon($br,$p.p);$br.Dispose()}
}
$labels=@('1. NORMAL OK','2. DELICI OK','3. PATLAYICI OK')
for($i=0;$i -lt 3;$i++){
 $y=145+$i*295
 $g.DrawString($labels[$i],$font,$brush,48,$y)
 DrawModel $models[$i] 100 ($y+95) 53 $false
 $g.SetClip([Drawing.Rectangle]::new(80,($y+135),530,145))
 DrawModel $models[$i] 102 ($y+205) 120 $true
 $g.ResetClip()
 $g.DrawString('Uc detayi',$small,$brush,650,($y+195))
}
$out=Join-Path $PSScriptRoot 'three-arrow-models.png'
$bmp.Save($out,[Drawing.Imaging.ImageFormat]::Png)
$g.Dispose();$bmp.Dispose();$font.Dispose();$small.Dispose();$brush.Dispose()
Write-Output $out
