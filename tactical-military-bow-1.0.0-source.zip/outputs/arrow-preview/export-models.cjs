const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert');
const variants=JSON.parse(fs.readFileSync(path.join(__dirname,'variants.json')));
const colors=[[43,48,53],[139,150,158],[166,132,53],[152,34,40],[67,73,79]];
const faces=['north','east','south','west','up','down'];
for(const variant of variants){
 const bones=JSON.parse(JSON.stringify(variant.bones));
 for(const b of bones)for(const c of b.cubes||[]){
  const tile=colors.findIndex(rgb=>rgb.every((n,i)=>n===c.previewColor[i]));assert(tile>=0);
  c.uv=Object.fromEntries(faces.map(f=>[f,{uv:[tile*8+1,1],uv_size:[4,4]}]));delete c.previewColor;
 }
 const geo={format_version:'1.12.0','minecraft:geometry':[{description:{identifier:'geometry.standalonebow_'+variant.type+'_arrow',texture_width:40,texture_height:8,visible_bounds_width:4,visible_bounds_height:4,visible_bounds_offset:[0,0,0]},bones}]};
 fs.writeFileSync(path.join(__dirname,variant.type+'_arrow.geo.json'),JSON.stringify(geo,null,2)+'\n');
 const ids=new Map(bones.map(b=>[b.name,crypto.randomUUID()]));
 const elements=[];const groups=new Map();
 for(const b of bones){const group={name:b.name,origin:b.pivot||[0,0,0],rotation:(b.rotation||[0,0,0]).map((n,i)=>i<2?-n:n),uuid:ids.get(b.name),children:[]};groups.set(b.name,group);
  for(const c of b.cubes||[]){const uuid=crypto.randomUUID();elements.push({name:b.name,type:'cube',uuid,from:c.origin,to:c.origin.map((n,i)=>n+c.size[i]),origin:c.pivot||[0,0,0],rotation:(c.rotation||[0,0,0]).map((n,i)=>i<2?-n:n),faces:Object.fromEntries(faces.map(f=>[f,{uv:[...c.uv[f].uv,c.uv[f].uv[0]+4,c.uv[f].uv[1]+4],texture:0}]))});group.children.push(uuid);}
 }
 const outliner=[];for(const b of bones){if(b.parent&&groups.has(b.parent))groups.get(b.parent).children.push(groups.get(b.name));else outliner.push(groups.get(b.name));}
 const texture=fs.readFileSync(path.join(__dirname,'arrow_palette.png')).toString('base64');
 const bb={meta:{format_version:'4.10',model_format:'bedrock',box_uv:false},name:variant.type+'_arrow',resolution:{width:40,height:8},elements,outliner,textures:[{name:'arrow_palette.png',uuid:crypto.randomUUID(),id:'0',mode:'bitmap',width:40,height:8,source:'data:image/png;base64,'+texture}],animations:[]};
 fs.writeFileSync(path.join(__dirname,variant.type+'_arrow.bbmodel'),JSON.stringify(bb,null,2)+'\n');
 const names=new Set(bones.map(b=>b.name));for(const b of bones)assert(!b.parent||names.has(b.parent));
 console.log(`${variant.type}: ${bones.length} bones, ${elements.length} cubes; hierarchy validated.`);
}
