# Ok Model Kaynakları / Arrow Model Sources

## Türkçe

Üç ok modeli moda entegre edilmiştir. Bu klasör düzenlenebilir girdileri içerir.
Özgün yüklü okun şaft/kuyruk geometrisi korunur; delici ve patlayıcı modellerin
uçları ve ayırt edici bantları değiştirilmiştir. Modeller tamamen yeni çizilmiş
eserler değildir; kaynak/lisans incelemesi üçüncü taraf bildirimlerine bağlıdır.

`.geo.json` ve `.bbmodel` dosyaları düzenlenebilir; paylaşılan palet PNG'si
Blockbench dosyalarına da gömülüdür. `three-arrow-models.png` çevrimdışı model
önizlemesidir, oyun ekran görüntüsü değildir. `.bbmodel` dışa aktarımları
Blockbench içinde açılarak ayrıca test edilmedi; kemik bağlantıları doğrulandı.
Üretim, hasar ve patlama davranışları modun README.md dosyasında açıklanır.

## English

All three arrow models are integrated into the mod. This directory contains
editable generation inputs. The existing nocked-arrow shaft/tail are retained;
piercing and explosive heads and identifying bands are modified. These are not
wholly newly authored assets; provenance/licensing remains subject to the
third-party notices.

- normal_arrow.geo.json / normal_arrow.bbmodel
- piercing_arrow.geo.json / piercing_arrow.bbmodel
- explosive_arrow.geo.json / explosive_arrow.bbmodel
- arrow_palette.png: shared material palette, embedded in each Blockbench file
- three-arrow-models.png: offline geometry preview, not a Minecraft screenshot

The editable Blockbench files are generated exports, not verified by opening
Blockbench. Bedrock files have validated bone parents and material coordinates.
Geometry derives from the current nocked arrow. Existing asset provenance and
license notices still apply; these are not wholly newly authored models.

Item registration, recipes, projectile behavior and runtime model selection are
implemented in the mod source, not in these standalone input files. See the
mod README.md for the approved crafting, damage and explosion behavior.
