const fs = require('fs');
const path = require('path');
const assert = require('assert');
const resources = path.join(__dirname, 'src/main/resources');
const assets = path.join(resources, 'assets/tacticalmilitarybow');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const base = read(path.join(assets, 'geo/item/gun/compound_bow.geo.json'))['minecraft:geometry'][0];
assert(base.bones.find(b => b.name === 'sight_fasteners').cubes.length <= 100,
    'Sight screw geometry exceeds the render budget');
assert(base.bones.find(b => b.name === 'round_sight_ring').cubes.length <= 288,
    'Sight ring geometry exceeds the render budget');
let checks = 0;
for (const kind of ['normal', 'piercing', 'explosive', 'poison', 'flame']) {
    const recipe = read(path.join(resources, 'data/tacticalmilitarybow/recipes', kind + '_arrow.json'));
    assert.equal(recipe.type, 'tacz:gun_smith_table_crafting');
    assert.deepStrictEqual(recipe.result, {type: 'custom', group: 'tacz:explosives', item: {item: 'tacticalmilitarybow:' + kind + '_arrow', count: 45}});
    const expected = {'minecraft:stick': 10, 'minecraft:iron_ingot': 2, 'minecraft:string': 10};
    if (kind !== 'normal') expected['minecraft:gold_ingot'] = 2;
    if (kind === 'explosive') expected['minecraft:gunpowder'] = 10;
    if (kind === 'poison') { expected['minecraft:spider_eye'] = 1; expected['minecraft:redstone'] = 1; }
    if (kind === 'flame') { expected['minecraft:flint'] = 1; expected['minecraft:redstone'] = 1; }
    assert.deepStrictEqual(Object.fromEntries(recipe.materials.map(m => [m.item.item, m.count])), expected);
    const bow = read(path.join(assets, 'geo/item/gun/compound_bow_' + kind + '.geo.json'))['minecraft:geometry'][0];
    assert.deepStrictEqual(bow.bones.filter(b => !b.name.startsWith('custom_nocked_')), base.bones.filter(b => !b.name.startsWith('custom_nocked_')));
    const arrow = read(path.join(assets, 'geo/item/' + kind + '_arrow.geo.json'))['minecraft:geometry'][0];
    if (kind === 'poison' || kind === 'flame') {
        assert.equal(arrow.description.texture_width, 48);
        assert.equal(bow.description.texture_width, 176);
        assert.equal(arrow.bones.filter(b => b.name.startsWith('colored_band_')).length, 3);
        for (const bone of arrow.bones.filter(b => b.name.includes('head') || b.name.includes('bone12') || b.name.startsWith('colored_band_')))
            for (const cube of bone.cubes || []) for (const face of Object.values(cube.uv)) assert.equal(face.uv[0], 41);
        assert(fs.existsSync(path.join(assets, 'textures/item/arrow_palette_' + kind + '.png')));
        assert(fs.existsSync(path.join(assets, 'textures/animated/gun/compound_bow_' + kind + '.png')));
        for (const prefix of ['arrow', 'reload_arrow']) for (const original of arrow.bones) {
            const name = original.name.startsWith('custom_nocked_arrow')
                ? original.name.replace('custom_nocked_arrow', 'custom_nocked_' + prefix)
                : 'custom_nocked_' + prefix + '_' + original.name;
            const mapped = bow.bones.find(b => b.name === name);
            assert(mapped, name);
            (original.cubes || []).forEach((cube, i) => {
                assert.deepStrictEqual(mapped.cubes[i].origin, cube.origin);
                assert.deepStrictEqual(mapped.cubes[i].size, cube.size);
                for (const [side, face] of Object.entries(cube.uv)) {
                    const actual = mapped.cubes[i].uv[side];
                    assert.equal(actual.uv[0], 128 + face.uv[0]);
                    assert.equal(actual.uv[1], face.uv[1]);
                    assert.deepStrictEqual(actual.uv_size, face.uv_size);
                }
            });
        }
    }
    assert.equal(bow.description.texture_width, 128 + arrow.description.texture_width);
    assert(fs.existsSync(path.join(assets, 'textures/animated/gun/compound_bow_nocked_' + kind + '.png')));
    for (const geo of [bow, arrow]) {
        const names = new Set(geo.bones.map(b => b.name));
        assert.equal(names.size, geo.bones.length);
        for (const bone of geo.bones) {
            assert(!bone.parent || names.has(bone.parent), bone.name);
            for (const cube of bone.cubes || []) {
                assert(cube.size.every(n => Number.isFinite(n) && n >= 0));
                for (const face of Object.values(cube.uv)) assert([...face.uv, ...face.uv_size].every(Number.isFinite));
            }
        }
    }
    for (const lang of ['en_us', 'tr_tr']) assert(read(path.join(assets, 'lang/' + lang + '.json'))['item.tacticalmilitarybow.' + kind + '_arrow']);
    assert(fs.existsSync(path.join(assets, 'models/item/' + kind + '_arrow.json')));
    assert(fs.existsSync(path.join(assets, 'textures/item/' + kind + '_arrow_icon.png')));
    checks += 8;
}
assert(fs.existsSync(path.join(assets, 'textures/item/arrow_palette.png')));
console.log('Arrow asset validation: ' + checks + ' groups passed; recipes, models, hierarchy, UVs, translations and unchanged bow body.');
