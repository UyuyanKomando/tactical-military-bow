const fs = require('fs');
const path = require('path');
const assert = require('assert');
const dir = path.join(__dirname, 'src/main/resources/assets/tacticalmilitarybow/models/special/gun');
const original = JSON.parse(fs.readFileSync(path.join(dir, 'compound_bow.json')));
const model = structuredClone(original);
// Subpixel screws and reticle lines are unnecessary in the 16/24-pixel GUI icon.
model.elements = model.elements.filter(e => !['sight_fasteners', 'sight_reticle', 'round_sight_ring'].includes(e.name));
const strips = original.elements.filter(e => e.name === 'round_sight_ring');
const bands = strips.length / 6;
assert(Number.isInteger(bands) && bands >= 24 && bands % 24 === 0);
const groupSize = bands / 24;
for (let ring = 0; ring < 3; ring++) for (let band = 0; band < bands; band += groupSize) {
    for (let side = 0; side < 2; side++) {
        const group = Array.from({length: groupSize}, (_, i) => strips[ring * bands * 2 + (band + i) * 2 + side]);
        const element = structuredClone(group[0]);
        element.from = [0, 1, 2].map(axis => Math.min(...group.map(e => e.from[axis])));
        element.to = [0, 1, 2].map(axis => Math.max(...group.map(e => e.to[axis])));
        model.elements.push(element);
    }
}
assert(model.elements.length <= 256 && model.elements.length < original.elements.length);
assert.deepStrictEqual(model.elements.filter(e => e.name !== 'round_sight_ring'),
    original.elements.filter(e => !['sight_fasteners', 'sight_reticle', 'round_sight_ring'].includes(e.name)));
fs.writeFileSync(path.join(dir, 'compound_bow_gui.json'), JSON.stringify(model, null, 2) + '\n');
console.log(`GUI-only bow model: ${original.elements.length} -> ${model.elements.length} elements; held/back/ground models unchanged.`);
