const fs = require('fs');
const path = require('path');
const base = path.join(__dirname, 'src/main/resources/assets/tacticalmilitarybow');
const gp = path.join(base, 'geo/item/gun/compound_bow.geo.json');
const mp = path.join(base, 'models/special/gun/compound_bow.json');
const geo = JSON.parse(fs.readFileSync(gp));
const baked = JSON.parse(fs.readFileSync(mp));
const g = geo['minecraft:geometry'][0];
const removed = new Set(['round_sight_ring', 'sight_dot', 'tactical_sight_housing', 'sight_reticle', 'sight_fasteners']);
const before = JSON.stringify(g.bones.filter(b => !removed.has(b.name)));
g.bones = g.bones.filter(b => !removed.has(b.name));
baked.elements = baked.elements.filter(e => !removed.has(e.name));
const faces = ['north', 'east', 'south', 'west', 'up', 'down'];
function bone(name) { const b = {name, parent:'bow_body', pivot:[1.2,6.625,7.3995], cubes:[]}; g.bones.push(b); return b; }
const ring = bone('round_sight_ring'), mount = bone('tactical_sight_housing');
const bolts = bone('sight_fasteners'), reticle = bone('sight_reticle');
function box(b,x,y,z,w,h,d,u=31,v=5) {
  b.cubes.push({origin:[x-w/2,y-h/2,z-d/2],size:[w,h,d],uv:Object.fromEntries(faces.map(f=>[f,{uv:[u,v],uv_size:[1,1]}]))});
}
// Horizontal strips preserve the round aperture without unsupported baked rotations.
function annulus(b,cx,cy,z,r,inner,depth,u,v) {
  // Tiny solid screw heads need far fewer strips than the large sight aperture.
  const n=inner===0?12:48, step=2*r/n;
  for(let i=0;i<n;i++) { const y=-r+(i+.5)*step, outer=Math.sqrt(r*r-y*y);
    const hole=Math.abs(y)<inner?Math.sqrt(inner*inner-y*y):0;
    if(inner===0) box(b,cx,cy+y,z,outer*2,step+.0005,depth,u,v);
    else for(const sign of [-1,1]) box(b,cx+sign*(outer+hole)/2,cy+y,z,outer-hole,step+.0005,depth,u,v);
  }
}
// Black armored housing surrounds the unchanged clear aperture and aiming center.
annulus(ring,1.2,6.625,7.43,.865,.665,.31,31,5);
annulus(ring,1.2,6.625,7.255,.87,.84,.035,44,1);
annulus(ring,1.2,6.625,7.25,.705,.665,.038,44,1);
// Right-side adjustment tower, mounting plate and ribbed adjustment wheel.
box(mount,.30,6.66,7.48,.28,1.17,.35,44,1);
box(mount,.28,6.66,7.275,.20,1.04,.07,31,5);
box(mount,.15,6.79,7.235,.095,.72,.055,103,2);
for(const y of [6.38,7.02]) box(mount,.48,y,7.45,.31,.12,.25,31,5);
box(mount,.13,6.25,7.49,.33,.27,.48,44,1);
for(let i=0;i<7;i++) box(mount,.13,6.145+i*.035,7.49,.35,.012,.50,6,4);
for(const a of [.68,2.48,3.95,5.48]) {
  const x=1.2+.775*Math.cos(a), y=6.625+.775*Math.sin(a);
  annulus(bolts,x,y,7.615,.072,0,.055,44,1);
  annulus(bolts,x,y,7.653,.045,0,.018,103,2);
  box(bolts,x,y,7.672,.052,.012,.012,44,1);
}
// Reference ladder: continuous center post and uninterrupted range bars; no chevron.
for(const [dy,len] of [[0,1.10],[-.18,1.10],[-.43,.85],[-.64,.40]]) {
  box(reticle,1.2,6.625+dy,7.25,len,.013,.012,82,5);
  for(const sign of [-1,1]) box(reticle,1.2+sign*(len/2-.055),6.625+dy,7.25,.11,.028,.012,82,5);
}
box(reticle,1.2,6.625-.32,7.25,.013,.653,.012,82,5);
const font={ '0':['111','101','101','101','111'], '1':['010','110','010','010','111'], '5':['111','100','111','001','111'], '8':['111','101','111','101','111'], 'M':['101','111','111','101','101'], '-':['000','000','111','000','000'] };
function label(text,x,y) { const p=.015; for(const [i,c] of [...text].entries()) for(let row=0;row<5;row++) for(let col=0;col<3;col++) if(font[c][row][col]==='1') box(reticle,2.4-(x+(i*4+col)*p),y-row*p,7.245,p*.8,p*.8,.012,82,5); }
label('0-50M',.82,6.56); label('80M',1.00,6.285); label('100M',.90,6.09);
const added=g.bones.filter(b=>removed.has(b.name));
for(const b of added) for(const c of b.cubes) {
  const [x,y,z]=c.origin,[w,h,d]=c.size;
  const from=[8.201097-.8*(x+w),.8*y-.207144,.8*z+9.1344];
  const to=[8.201097-.8*x,.8*(y+h)-.207144,.8*(z+d)+9.1344];
  if (b.name === 'sight_reticle') for (const face of Object.values(c.uv)) face.uv = [127,127];
  const uv=c.uv.north.uv;
  baked.elements.push({name:b.name,from,to,faces:Object.fromEntries(faces.map(f=>[f,{texture:'#0',uv:[uv[0]/8,uv[1]/8,(uv[0]+1)/8,(uv[1]+1)/8]}]))});
}
if(before!==JSON.stringify(g.bones.filter(b=>!removed.has(b.name)))) throw Error('Non-sight geometry changed');
fs.writeFileSync(gp,JSON.stringify(geo,null,2)+'\n');
fs.writeFileSync(mp,JSON.stringify(baked,null,2)+'\n');
console.log('FPS and TPS sight updated; non-sight geometry unchanged; center preserved at 1.2, 6.625.');
require('./create-lightweight-gui-model.cjs');
