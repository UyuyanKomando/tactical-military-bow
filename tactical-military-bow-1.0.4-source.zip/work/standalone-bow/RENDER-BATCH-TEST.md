# Historical Hand Batch Test Plan

This records the intermediate candidate test plan. The owner subsequently approved the optimized build in-game; see CHANGELOG-1.0.4.md and the release MANIFEST for current status. This historical plan does not mean that a later release was uploaded by the assistant.

The two hands use separate fixed opaque/translucent buffers. Each layer is flushed once after the item render, rather than once per hand. All vertex positions, skin textures, lighting values and animation transforms are unchanged. The bow still uses its original buffer source, isolated from skin rendering.

Automated checks cover compilation and the existing gameplay, arm geometry, HUD and launch projection tests. A standalone buffer lifecycle test could not execute without the Forge client bootstrap. Shader/GPU behavior and performance are NOT verified by these headless checks.

In-game acceptance checks, using the same scene and shader settings:

- Idle, full draw, release, reload and aiming show both hands and skin overlays.
- Opaque geometry occludes skin correctly; translucent sleeves have no flashing or missing faces.
- Repeat shots while moving and looking in different directions; arrows remain attached to their intended animated positions.
- Test normal and slim skins with Fresh Moves enabled and disabled.
- Compare frame time/FPS against the previous performance-v3 package. A reduction in batching is not a measured FPS improvement.
- Do not publish this candidate until visual behavior and performance are confirmed.
