package com.korkuluk.standalonebow.client;

/** Reuse HUD number strings until their value actually changes. */
public final class BowCounterText {
    private final int digits;
    private int previous;
    private String text;
    public BowCounterText(int digits) { this.digits = digits; }
    public String get(int value) {
        if (text != null && value == previous) return text;
        previous = value;
        String raw = Integer.toString(value);
        String zeros = "0".repeat(Math.max(0, digits - raw.length()));
        text = value < 0 ? "-" + zeros + raw.substring(1) : zeros + raw;
        return text;
    }
}
