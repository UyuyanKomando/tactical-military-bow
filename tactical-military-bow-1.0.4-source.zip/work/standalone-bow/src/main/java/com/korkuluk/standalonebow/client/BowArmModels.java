package com.korkuluk.standalonebow.client;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;

/** Private first-person skin geometry, independent of the mutable player renderer model. */
public final class BowArmModels {
    public record Arms(ModelPart leftArm, ModelPart rightArm, ModelPart leftSleeve, ModelPart rightSleeve) {}
    private static final Arms NORMAL = create(false);
    private static final Arms SLIM = create(true);
    private BowArmModels() {}
    public static Arms forSkin(String type) { return "slim".equals(type) ? SLIM : NORMAL; }
    private static Arms create(boolean slim) {
        var mesh = new MeshDefinition();
        var root = mesh.getRoot();
        float width = slim ? 3 : 4, rightX = slim ? -2 : -3;
        root.addOrReplaceChild("right_arm", CubeListBuilder.create().texOffs(40, 16)
                .addBox(rightX, -2, -2, width, 12, 4), PartPose.ZERO);
        root.addOrReplaceChild("left_arm", CubeListBuilder.create().texOffs(32, 48).mirror()
                .addBox(-1, -2, -2, width, 12, 4), PartPose.ZERO);
        var sleeve = new CubeDeformation(0.25F);
        root.addOrReplaceChild("right_sleeve", CubeListBuilder.create().texOffs(40, 32)
                .addBox(rightX, -2, -2, width, 12, 4, sleeve), PartPose.ZERO);
        root.addOrReplaceChild("left_sleeve", CubeListBuilder.create().texOffs(48, 48).mirror()
                .addBox(-1, -2, -2, width, 12, 4, sleeve), PartPose.ZERO);
        var baked = LayerDefinition.create(mesh, 64, 64).bakeRoot();
        return new Arms(baked.getChild("left_arm"), baked.getChild("right_arm"),
                baked.getChild("left_sleeve"), baked.getChild("right_sleeve"));
    }
}
