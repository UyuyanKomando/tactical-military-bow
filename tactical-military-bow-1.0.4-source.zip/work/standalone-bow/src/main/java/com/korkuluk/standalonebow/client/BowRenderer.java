package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.cache.object.GeoCube;
import software.bernie.geckolib.cache.object.GeoQuad;
import software.bernie.geckolib.renderer.GeoItemRenderer;
import software.bernie.geckolib.util.RenderUtils;

public final class BowRenderer<T extends Item & GeoItem> extends GeoItemRenderer<T> {
    private static final ResourceLocation STATIC_MODEL = new ResourceLocation("tacticalmilitarybow", "special/gun/compound_bow");
    private static final ResourceLocation GUI_MODEL = new ResourceLocation("tacticalmilitarybow", "special/gun/compound_bow_gui");
    private BowArmBuffers armBuffers;
    private final org.joml.Vector3f cubeNormal = new org.joml.Vector3f();
    private final BowVertexWriter vertexWriter = new BowVertexWriter();
    public BowRenderer() { super(new BowModel<>()); }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext context, PoseStack pose,
                             MultiBufferSource buffers, int light, int overlay) {
        pose.pushPose();
        try {
            BowModel.arrowKind = com.korkuluk.standalonebow.TacticalArrowItem.loadedKind(stack);
            if (context == ItemDisplayContext.GUI) {
                var mc = Minecraft.getInstance();
                var transform = mc.getItemRenderer().getModel(stack, null, null, 0).getTransforms().gui;
                var rotation = new org.joml.Quaternionf().rotationXYZ(
                        transform.rotation.x() * Mth.DEG_TO_RAD,
                        transform.rotation.y() * Mth.DEG_TO_RAD,
                        transform.rotation.z() * Mth.DEG_TO_RAD);
                // Rotate around the GUI slot center, before its existing display transform.
                pose.translate(0.5, 0.5, 0.5);
                pose.scale(1 / transform.scale.x(), 1 / transform.scale.y(), 1 / transform.scale.z());
                pose.mulPose(new org.joml.Quaternionf(rotation).conjugate());
                pose.translate(-transform.translation.x(), -transform.translation.y(), -transform.translation.z());
                pose.mulPose(Axis.ZP.rotationDegrees(-90));
                pose.translate(transform.translation.x(), transform.translation.y(), transform.translation.z());
                pose.mulPose(rotation);
                pose.scale(transform.scale.x(), transform.scale.y(), transform.scale.z());
                pose.translate(-0.5, -0.5, -0.5);
            }
            if (!context.firstPerson() && context != ItemDisplayContext.GROUND && context != ItemDisplayContext.FIXED) {
                var mc = Minecraft.getInstance();
                var model = mc.getModelManager().getModel(context == ItemDisplayContext.GUI ? GUI_MODEL : STATIC_MODEL);
                mc.getItemRenderer().renderModelLists(model, stack, light, overlay, pose,
                        net.minecraft.client.renderer.entity.ItemRenderer.getFoilBufferDirect(buffers,
                                RenderType.entityCutoutNoCull(net.minecraft.world.inventory.InventoryMenu.BLOCK_ATLAS), true, stack.hasFoil()));
                return;
            }
            if (context.firstPerson()) firstPerson(stack, pose, context);
            super.renderByItem(stack, context, pose, buffers, light, overlay);
        } finally {
            try {
                if (context.firstPerson() && armBuffers != null) armBuffers.flush();
            } finally { pose.popPose(); }
        }
    }

    private void firstPerson(ItemStack stack, PoseStack pose, ItemDisplayContext context) {
        var mc = Minecraft.getInstance();
        var player = mc.player;
        if (player == null) return;
        float partial = mc.getPartialTick();
        float ads = BowClient.aim(partial);
        float side = context == ItemDisplayContext.FIRST_PERSON_LEFT_HAND ? -1 : 1;
        var transform = mc.getItemRenderer().getModel(stack, player.level(), player, 0)
                .getTransforms().firstPersonRightHand;
        float x = transform.translation.x(), y = transform.translation.y(), z = transform.translation.z();
        if (mc.options.bobView().get()) {
            float walked = -(player.walkDist + (player.walkDist - player.walkDistO) * partial);
            float bob = Mth.lerp(partial, player.oBob, player.bob);
            float wave = walked * (float)Math.PI;
            pose.mulPose(Axis.XP.rotationDegrees(-Math.abs(Mth.cos(wave - 0.2F) * bob) * 5));
            pose.mulPose(Axis.ZP.rotationDegrees(-Mth.sin(wave) * bob * 3));
            pose.translate(-Mth.sin(wave) * bob * 0.5F, Math.abs(Mth.cos(wave) * bob), 0);
            bob *= player.isSprinting() ? 8 : 4;
            bob *= BowClientConfig.BOBBING_INTENSITY.get().floatValue();
            if (!BowClient.aiming()) {
                float inverseZoom = 1 - ads * BowClient.sprintIntensity();
                pose.mulPose(Axis.XP.rotationDegrees(Math.abs(Mth.cos(wave - 0.2F) * bob) * -2 * inverseZoom));
                pose.mulPose(Axis.ZP.rotationDegrees(Mth.sin(wave) * bob * 3 * inverseZoom));
            }
        }
        BowRecoil.apply(pose, stack, partial, ads);
        pose.translate(x, y, z);
        pose.translate(0, -0.25, 0.35);
        pose.mulPose(Axis.XP.rotationDegrees(BowClient.fallSway(partial)));
        pose.translate(0, 0.25, -0.35);
        float pitch = Mth.rotLerp(partial, player.xRotO, player.getXRot()) - Mth.rotLerp(partial, player.xBobO, player.xBob);
        float yaw = Mth.rotLerp(partial, player.yHeadRotO, player.yHeadRot) - Mth.rotLerp(partial, player.yBobO, player.yBob);
        float sensitivity = BowClientConfig.SWAY_SENSITIVITY.get().floatValue();
        pose.mulPose(Axis.XP.rotationDegrees(pitch * (1 - 0.5F * ads) * sensitivity / 2));
        pose.mulPose(Axis.YP.rotationDegrees(yaw * (1 - 0.5F * ads) * sensitivity / 2));
        pose.translate(-x, -y, -z);
        pose.translate(-0.5 * side, 0.5, -0.1);
        pose.mulPose(Axis.ZP.rotationDegrees(-45 * side));
        float transition = 1 - (1 - ads) * (1 - ads); // EASE_OUT_QUAD sight curve.
        double sx = transform.scale.x(), sy = transform.scale.y(), sz = transform.scale.z();
        // AnimatedGunRenderer: model centering + (8,0,8) origin + legacy zoom camera delta.
        double offsetX = x - 0.5 * sx + 8 * 0.0625 * sx - 1.05 * 0.0625 * sx;
        double offsetY = y - 0.5 * sy + 3.5 * 0.0625 * sy + 0.6059;
        double offsetZ = z - 0.5 * sz + 8 * 0.0625 * sz - 0.16 + 0.72;
        pose.mulPose(Axis.ZP.rotationDegrees(45 * transition * side));
        pose.translate(0.508 * transition * side, -0.6 * transition, 0);
        pose.translate(-0.56 * transition * side, 0.52 * transition, 0.72 * transition);
        pose.translate(-offsetX * transition * side, -offsetY * transition, -offsetZ * transition);
    }

    @Override
    public void renderRecursively(PoseStack pose, T item, GeoBone bone, RenderType type,
            MultiBufferSource buffers, VertexConsumer consumer, boolean rerender, float partial,
            int light, int overlay, float red, float green, float blue, float alpha) {
        String name = bone.getName();
        if (name.equals("reload_arrow")) {
            boolean hidden = !BowArrowVisibility.reloadVisible(renderPerspective.firstPerson(), BowClient.action(),
                    bone.getScaleX(), bone.getScaleY(), bone.getScaleZ());
            bone.setHidden(hidden);
            bone.setChildrenHidden(hidden);
            if (hidden) return;
        }
        if (name.equals("sight_dot") || name.equals("sight_reticle")) {
            red = 1; green = 1; blue = 1;
            light = 0xF000F0;
        }
        var mc = Minecraft.getInstance();
        boolean arm = name.equals("left_arm") || name.equals("right_arm")
                || name.equals("fake_left_arm") || name.equals("fake_right_arm");
        if (arm) { bone.setHidden(true); bone.setChildrenHidden(false); }
        if (name.equals("arrow")) {
            boolean hasArrow = mc.player != null && BowClient.bridge() != null
                    && BowClient.bridge().hasArrow(mc.player, currentItemStack);
            boolean hidden = !BowArrowVisibility.visible(renderPerspective.firstPerson(), hasArrow,
                    BowClient.action(), bone.getScaleX(), bone.getScaleY(), bone.getScaleZ());
            bone.setHidden(hidden);
            bone.setChildrenHidden(hidden);
            if (hidden) return;
        }
        if (name.equals("custom_nocked_arrow_head") && renderPerspective.firstPerson()
                && (BowClient.action().equals("hold_fire") || BowClient.action().equals("hold"))) {
            pose.pushPose();
            try {
                RenderUtils.prepMatrixForBone(pose, bone);
                BowLaunchVisual.capture(pose.last().pose());
            } finally { pose.popPose(); }
        }
        if (arm && renderPerspective.firstPerson() && mc.player != null && !mc.player.isInvisible()) {
            pose.pushPose();
            try {
                RenderUtils.translateMatrixToBone(pose, bone);
                RenderUtils.translateToPivotPoint(pose, bone);
                RenderUtils.rotateMatrixAroundBone(pose, bone);
                RenderUtils.scaleMatrixForBone(pose, bone);
                RenderUtils.translateAwayFromPivotPoint(pose, bone);
                boolean left = name.contains("left");
                pose.scale(0.67F, 0.8F, 0.67F);
                pose.translate(left ? -0.25 : 0.25, -0.1, 0.1625);
                var model = BowArmModels.forSkin(mc.player.getModelName());
                var skin = mc.player.getSkinTextureLocation();
                if (armBuffers == null || !armBuffers.matches(skin)) armBuffers = new BowArmBuffers(skin);
                // Separate fixed layers avoid interrupting the bow's active builder.
                renderArm(left ? model.leftArm() : model.rightArm(), pose, armBuffers.skin(), bone, light, overlay);
                renderArm(left ? model.leftSleeve() : model.rightSleeve(), pose, armBuffers.sleeve(), bone, light, overlay);
            } finally { pose.popPose(); }
        }
        // Other bone textures can flush the shared builder; reacquire this bone's buffer.
        consumer = buffers.getBuffer(type);
        super.renderRecursively(pose, item, bone, type, buffers, consumer, rerender, partial,
                light, overlay, red, green, blue, alpha);
    }

    @Override public void renderCube(PoseStack pose, GeoCube cube, VertexConsumer consumer, int light, int overlay,
                                     float red, float green, float blue, float alpha) {
        RenderUtils.translateToPivotPoint(pose, cube);
        RenderUtils.rotateMatrixAroundCube(pose, cube);
        RenderUtils.translateAwayFromPivotPoint(pose, cube);
        var normalMatrix = pose.last().normal();
        var matrix = pose.last().pose();
        for (var quad : cube.quads()) {
            if (quad == null) continue;
            normalMatrix.transform(cubeNormal.set(quad.normal()));
            RenderUtils.fixInvertedFlatCube(cube, cubeNormal);
            createVerticesOfQuad(quad, matrix, cubeNormal, consumer, light, overlay, red, green, blue, alpha);
        }
    }
    @Override public void createVerticesOfQuad(GeoQuad quad, org.joml.Matrix4f matrix, org.joml.Vector3f normal,
                                               VertexConsumer consumer, int light, int overlay,
                                               float red, float green, float blue, float alpha) {
        vertexWriter.emit(quad, matrix, normal, consumer, light, overlay, red, green, blue, alpha);
    }

    private static void renderArm(ModelPart arm, PoseStack pose, VertexConsumer buffer, GeoBone bone, int light, int overlay) {
        // These cached parts belong only to this renderer, not the player model.
        arm.visible = true;
        arm.setPos(bone.getPivotX(), bone.getPivotY(), bone.getPivotZ());
        arm.setRotation(0, 0, 0);
        arm.render(pose, buffer, light, overlay);
    }
}
