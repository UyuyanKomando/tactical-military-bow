package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import software.bernie.geckolib.cache.object.GeoQuad;

/** Same vertex transform as GeoLib, without allocating a vector for every vertex. */
public final class BowVertexWriter {
    private final Vector4f position = new Vector4f();
    public void emit(GeoQuad quad, Matrix4f matrix, Vector3f normal, VertexConsumer consumer,
                     int light, int overlay, float red, float green, float blue, float alpha) {
        for (var vertex : quad.vertices()) {
            var source = vertex.position();
            matrix.transform(position.set(source.x(), source.y(), source.z(), 1));
            consumer.vertex(position.x(), position.y(), position.z(), red, green, blue, alpha,
                    vertex.texU(), vertex.texV(), overlay, light, normal.x(), normal.y(), normal.z());
        }
    }
}
