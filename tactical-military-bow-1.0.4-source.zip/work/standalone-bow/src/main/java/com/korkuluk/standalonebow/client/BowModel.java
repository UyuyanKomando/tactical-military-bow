package com.korkuluk.standalonebow.client;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.model.GeoModel;

public final class BowModel<T extends Item & GeoItem> extends GeoModel<T> {
    static String arrowKind = "normal";
    private static final java.util.Map<String, ResourceLocation> MODELS = new java.util.HashMap<>();
    private static final java.util.Map<String, ResourceLocation> TEXTURES = new java.util.HashMap<>();
    private static final ResourceLocation ANIMATION = new ResourceLocation("tacticalmilitarybow", "animations/item/compound_bow.animation.json");
    static {
        for (String kind : com.korkuluk.standalonebow.ArrowSelection.KINDS) {
            MODELS.put(kind, new ResourceLocation("tacticalmilitarybow", "geo/item/gun/compound_bow_" + kind + ".geo.json"));
            TEXTURES.put(kind, new ResourceLocation("tacticalmilitarybow", "textures/animated/gun/compound_bow_nocked_" + kind + ".png"));
        }
    }
    @Override public ResourceLocation getModelResource(T item) {
        return MODELS.getOrDefault(arrowKind, MODELS.get("normal"));
    }
    @Override public ResourceLocation getTextureResource(T item) {
        return TEXTURES.getOrDefault(arrowKind, TEXTURES.get("normal"));
    }
    @Override public ResourceLocation getAnimationResource(T item) {
        return ANIMATION;
    }
}
