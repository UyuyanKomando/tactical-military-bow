package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.ArrowSelection;
import com.korkuluk.standalonebow.QuiverStorage;
import com.korkuluk.standalonebow.TacticalArrowItem;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Read-only display snapshot; authoritative selection and consumption stay on the server. */
public final class BowAmmoCounts {
    private static WeakReference<Player> owner = new WeakReference<>(null);
    private static long tick = Long.MIN_VALUE;
    private static final int[] counts = new int[ArrowSelection.KINDS.size()];
    private static final ItemStack[] icons = new ItemStack[ArrowSelection.KINDS.size()];
    private BowAmmoCounts() {}
    public static int reserve(Player player, String kind) {
        long now = player.level().getGameTime();
        if (owner.get() != player || tick != now) {
            owner = new WeakReference<>(player);
            tick = now;
            Arrays.fill(counts, 0);
            var quiver = QuiverStorage.contents(QuiverStorage.equipped(player));
            for (int i = 0; i < QuiverStorage.SLOTS; i++) add(quiver.getStackInSlot(i));
            var inventory = player.getInventory();
            for (int i = 0; i < inventory.getContainerSize(); i++) add(inventory.getItem(i));
        }
        int index = ArrowSelection.KINDS.indexOf(kind);
        return index < 0 ? 0 : counts[index];
    }
    private static void add(ItemStack stack) {
        if (!TacticalArrowItem.accepts(stack)) return;
        int index = ArrowSelection.KINDS.indexOf(TacticalArrowItem.kind(stack));
        if (index >= 0) counts[index] += stack.getCount();
    }
    public static ItemStack icon(String kind) {
        int index = ArrowSelection.KINDS.indexOf(kind);
        if (index < 0) index = 0;
        if (icons[index] == null) icons[index] = ArrowSelection.item(ArrowSelection.KINDS.get(index));
        return icons[index];
    }
}
