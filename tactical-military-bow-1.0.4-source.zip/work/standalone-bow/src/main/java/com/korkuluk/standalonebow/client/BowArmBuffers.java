package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.LinkedHashMap;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

/** Isolated fixed buffers let both hands share one draw per skin layer. */
public final class BowArmBuffers {
    private final ResourceLocation texture;
    private final RenderType skin, sleeve;
    private final MultiBufferSource.BufferSource buffers;
    public BowArmBuffers(ResourceLocation texture) {
        this.texture = texture;
        skin = RenderType.entitySolid(texture);
        sleeve = RenderType.entityTranslucent(texture);
        var fixed = new LinkedHashMap<RenderType, BufferBuilder>();
        fixed.put(skin, new BufferBuilder(4096));
        fixed.put(sleeve, new BufferBuilder(4096));
        buffers = MultiBufferSource.immediateWithBuffers(fixed, new BufferBuilder(256));
    }
    public boolean matches(ResourceLocation texture) { return this.texture.equals(texture); }
    public VertexConsumer skin() { return buffers.getBuffer(skin); }
    public VertexConsumer sleeve() { return buffers.getBuffer(sleeve); }
    public void flush() { buffers.endBatch(); }
}
