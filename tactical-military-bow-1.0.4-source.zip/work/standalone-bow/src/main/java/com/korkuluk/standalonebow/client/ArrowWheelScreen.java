package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.ArrowSelection;
import com.korkuluk.standalonebow.BowNetwork;
import com.korkuluk.standalonebow.CompoundBowItem;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class ArrowWheelScreen extends Screen {
    private final int slot;
    private int selected = -1;
    private boolean finished;
    public ArrowWheelScreen(int slot) {
        super(Component.translatable("gui.tacticalmilitarybow.arrow_wheel"));
        this.slot = slot;
    }
    private boolean valid() {
        return minecraft.player != null && minecraft.player.isAlive() && !minecraft.player.isSpectator()
                && minecraft.player.getInventory().selected == slot
                && minecraft.player.getMainHandItem().getItem() instanceof CompoundBowItem;
    }
    private double outer() { return Math.min(110, Math.min(width, height) * 0.43); }
    private int hovered(double x, double y) {
        return ArrowWheelLayout.selected(x - width / 2.0, y - height / 2.0, outer() * 0.42, outer(), ArrowSelection.KINDS.size());
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void tick() {
        if (!valid() || !minecraft.isWindowActive()) onClose();
    }
    @Override public void render(GuiGraphics gui, int mouseX, int mouseY, float partial) {
        if (!valid()) return;
        selected = hovered(mouseX, mouseY);
        double radius = outer(), inner = radius * 0.42;
        int cx = width / 2, cy = height / 2;
        String current = ArrowSelection.displayedKind(minecraft.player.getMainHandItem());
        gui.fill(0, 0, width, height, 0x45000000);
        gui.flush();
        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder buffer = Tesselator.getInstance().getBuilder();
        buffer.begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i < ArrowSelection.KINDS.size(); i++) {
            String kind = ArrowSelection.KINDS.get(i);
            boolean available = minecraft.player.isCreative() || BowAmmoCounts.reserve(minecraft.player, kind) > 0 || kind.equals(current);
            int color = i == selected ? (available ? 0xE0486870 : 0xD0663333) : 0xD0181D20;
            double step = Math.PI * 2 / ArrowSelection.KINDS.size();
            double start = -Math.PI / 2 + step * (i - 0.5) + 0.018;
            double end = start + step - 0.036;
            for (int n = 0; n < 32; n++) {
                double a = start + (end - start) * n / 32, b = start + (end - start) * (n + 1) / 32;
                vertex(buffer, cx, cy, inner, a, color); vertex(buffer, cx, cy, radius, a, color); vertex(buffer, cx, cy, radius, b, color);
                vertex(buffer, cx, cy, inner, a, color); vertex(buffer, cx, cy, radius, b, color); vertex(buffer, cx, cy, inner, b, color);
            }
        }
        BufferUploader.drawWithShader(buffer.end());
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        for (int i = 0; i < ArrowSelection.KINDS.size(); i++) {
            String kind = ArrowSelection.KINDS.get(i);
            double a = -Math.PI / 2 + i * Math.PI * 2 / ArrowSelection.KINDS.size();
            int x = cx + (int)(Math.cos(a) * radius * 0.72), y = cy + (int)(Math.sin(a) * radius * 0.72);
            int count = BowAmmoCounts.reserve(minecraft.player, kind);
            if (kind.equals(current)) count += BowClient.bridge().ammo(minecraft.player, minecraft.player.getMainHandItem());
            gui.renderItem(BowAmmoCounts.icon(kind), x - 8, y - 13);
            gui.drawCenteredString(font, minecraft.player.isCreative() ? "\u221e" : Integer.toString(count), x, y + 7,
                    kind.equals(current) ? 0xFFCF72 : count > 0 ? 0xFFFFFF : 0x888888);
        }
        if (selected >= 0) {
            String kind = ArrowSelection.KINDS.get(selected);
            var text = BowAmmoCounts.icon(kind).getHoverName();
            gui.pose().pushPose();
            float scale = Math.min(1F, (float)(inner * 1.8) / Math.max(1, font.width(text)));
            gui.pose().translate(cx, cy - 4, 0);
            gui.pose().scale(scale, scale, 1);
            gui.drawCenteredString(font, text, 0, 0, 0xFFFFFF);
            gui.pose().popPose();
        }
    }
    private static void vertex(BufferBuilder buffer, int x, int y, double r, double a, int color) {
        buffer.vertex(x + r * Math.cos(a), y + r * Math.sin(a), 0)
                .color((color >> 16) & 255, (color >> 8) & 255, color & 255, (color >>> 24) & 255).endVertex();
    }
    private void confirm() {
        if (finished) return;
        finished = true;
        if (valid() && selected >= 0)
            BowNetwork.CHANNEL.sendToServer(new BowNetwork.SelectArrow(ArrowSelection.KINDS.get(selected)));
        onClose();
    }
    @Override public boolean keyReleased(int key, int scan, int modifiers) {
        if (TaczArrowSelect.matches(key, scan)) { confirm(); return true; }
        return super.keyReleased(key, scan, modifiers);
    }
    @Override public boolean mouseReleased(double x, double y, int button) {
        if (TaczArrowSelect.matchesMouse(button) || button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            selected = hovered(x, y); confirm(); return true;
        }
        return super.mouseReleased(x, y, button);
    }
}
