package com.korkuluk.standalonebow.client;

public final class BowCounterTextTest {
    public static void main(String[] args) {
        int checks = 0;
        for (int width : new int[]{3, 4}) {
            var cache = new BowCounterText(width);
            for (int value : new int[]{0, 1, 9, 10, 99, 100, 576, 9999, 12345, -1, Integer.MIN_VALUE, Integer.MAX_VALUE, 0}) {
                String actual = cache.get(value);
                if (!actual.equals(String.format(java.util.Locale.ROOT, "%0" + width + "d", value)))
                    throw new AssertionError("HUD padding changed: " + value);
                if (cache.get(value) != actual) throw new AssertionError("Unchanged value allocated a new string");
                checks += 2;
            }
        }
        System.out.println("BowCounterTextTest: " + checks + " checks passed");
    }
}
