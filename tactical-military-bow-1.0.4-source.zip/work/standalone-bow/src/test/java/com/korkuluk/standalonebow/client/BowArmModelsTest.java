package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelPart;

public final class BowArmModelsTest {
    private static int checks;
    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }
    private static void part(ModelPart part, float width, boolean sleeve) {
        int[] cubes = {0};
        part.visit(new PoseStack(), (pose, path, index, cube) -> {
            cubes[0]++;
            check(Math.abs(cube.maxX - cube.minX - width) < 0.0001F, "arm width");
            check(Math.abs(cube.maxY - cube.minY - 12) < 0.0001F, "arm height");
            check(Math.abs(cube.maxZ - cube.minZ - 4) < 0.0001F, "arm depth");
        });
        check(cubes[0] == 1, "one cached cube per arm or sleeve");
    }
    public static void main(String[] args) {
        var normal = BowArmModels.forSkin("default");
        var slim = BowArmModels.forSkin("slim");
        check(normal == BowArmModels.forSkin("default"), "normal model cached");
        check(slim == BowArmModels.forSkin("slim"), "slim model cached");
        check(normal != slim, "distinct skin widths");
        check(normal == BowArmModels.forSkin(null), "unknown skin uses normal geometry");
        for (var arms : new BowArmModels.Arms[]{normal, slim}) {
            float width = arms == normal ? 4 : 3;
            part(arms.leftArm(), width, false); part(arms.rightArm(), width, false);
            part(arms.leftSleeve(), width, true); part(arms.rightSleeve(), width, true);
            check(arms.leftArm() != arms.rightArm(), "independent hands");
            check(arms.leftArm() != arms.leftSleeve(), "separate skin overlay");
        }
        System.out.println("BowArmModelsTest: " + checks + " checks passed");
    }
}
