package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import software.bernie.geckolib.cache.object.GeoQuad;
import software.bernie.geckolib.cache.object.GeoVertex;

public final class BowVertexWriterTest {
    private static final class Capture implements VertexConsumer {
        final float[][] values = new float[4][];
        final int[][] packed = new int[4][];
        int count;
        @Override public void vertex(float x, float y, float z, float r, float g, float b, float a,
                                     float u, float v, int overlay, int light, float nx, float ny, float nz) {
            values[count] = new float[]{x,y,z,r,g,b,a,u,v,nx,ny,nz};
            packed[count++] = new int[]{overlay,light};
        }
        public VertexConsumer vertex(double x,double y,double z) { throw new AssertionError(); }
        public VertexConsumer color(int r,int g,int b,int a) { throw new AssertionError(); }
        public VertexConsumer uv(float u,float v) { throw new AssertionError(); }
        public VertexConsumer overlayCoords(int x,int y) { throw new AssertionError(); }
        public VertexConsumer uv2(int x,int y) { throw new AssertionError(); }
        public VertexConsumer normal(float x,float y,float z) { throw new AssertionError(); }
        public void endVertex() { throw new AssertionError(); }
        public void defaultColor(int r,int g,int b,int a) {}
        public void unsetDefaultColor() {}
    }
    public static void main(String[] args) {
        var random = new java.util.Random(19032026);
        var writer = new BowVertexWriter();
        int checks = 0;
        for (int sample = 0; sample < 500; sample++) {
            var vertices = new GeoVertex[4];
            for (int i = 0; i < 4; i++) vertices[i] = new GeoVertex(
                    new Vector3f(random.nextFloat(), random.nextFloat(), random.nextFloat()), random.nextFloat(), random.nextFloat());
            var normal = new Vector3f(random.nextFloat(),random.nextFloat(),random.nextFloat());
            var quad = new GeoQuad(vertices,normal,null);
            var matrix = new Matrix4f().translate(random.nextFloat(),random.nextFloat(),random.nextFloat())
                    .rotateXYZ(random.nextFloat()*6,random.nextFloat()*6,random.nextFloat()*6)
                    .scale(sample % 2 == 0 ? -0.7F : 1.2F, 0.8F, 1.1F);
            var result = new Capture();
            writer.emit(quad,matrix,normal,result,0xF000F0,0x123456,0.3F,0.6F,0.9F,0.5F);
            for (int i = 0; i < 4; i++) {
                var source = vertices[i].position();
                var p = matrix.transform(new Vector4f(source.x(),source.y(),source.z(),1));
                float[] expected = {p.x(),p.y(),p.z(),0.3F,0.6F,0.9F,0.5F,vertices[i].texU(),vertices[i].texV(),normal.x(),normal.y(),normal.z()};
                for (int n = 0; n < expected.length; n++) {
                    if (Float.floatToIntBits(expected[n]) != Float.floatToIntBits(result.values[i][n]))
                        throw new AssertionError("Vertex changed at sample " + sample);
                    checks++;
                }
                if (result.packed[i][0] != 0x123456 || result.packed[i][1] != 0xF000F0)
                    throw new AssertionError("Lighting/overlay changed");
                checks++;
            }
        }
        System.out.println("BowVertexWriterTest: " + checks + " bit-exact transform/UV/color/light checks passed");
    }
}
