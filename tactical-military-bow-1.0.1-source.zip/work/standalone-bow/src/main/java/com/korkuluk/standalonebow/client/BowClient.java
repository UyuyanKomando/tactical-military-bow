package com.korkuluk.standalonebow.client;

import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraft.util.Mth;

@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT)
public final class BowClient {
    private static BowClientBridge bridge;
    private static ItemStack held = ItemStack.EMPTY;
    private static boolean aiming, charging;
    private static float aim, previousAim;
    private static long revision;
    private static String action = "idle";
    private static float actionTicks;
    private static final BowDrawLock DRAW_LOCK = new BowDrawLock();
    public static boolean drawing() { return DRAW_LOCK.drawing(); }
    private static int selectedSlot = -1;
    private static boolean attackHeld;
    private static int holdFire;
    public static int holdFire() { return holdFire; }
    public static boolean charging() { return charging; }
    private static float fallSway, previousFallSway;
    private static float sprintIntensity;
    public static float sprintIntensity() { return sprintIntensity; }
    public static float fallSway(float partial) { return Mth.lerp(partial, previousFallSway, fallSway) / 2; }
    private static final java.util.Map<Player, float[]> remoteAim = new java.util.WeakHashMap<>();
    public static final com.korkuluk.standalonebow.client.pose.TwoHandedPose POSE =
            new com.korkuluk.standalonebow.client.pose.TwoHandedPose();

    private BowClient() {}
    public static void install(BowClientBridge integration) { bridge = Objects.requireNonNull(integration); }
    public static BowClientBridge bridge() { return bridge; }
    public static float aim(float partialTick) { return Mth.lerp(partialTick, previousAim, aim); }
    public static boolean aiming() { return aiming; }
    public static float aim(Player player, float partial) {
        if (player == Minecraft.getInstance().player) return aim(partial);
        float[] tracker = remoteAim.get(player);
        return tracker == null ? 0 : Mth.lerp(partial, tracker[0], tracker[1]);
    }
    public static long revision() { return revision; }
    public static String action() { return action; }
    public static void animate(String clip, int ticks) {
        action = clip;
        actionTicks = ticks;
        revision++;
    }
    /** Call on the client thread after the server accepts a shot. */
    public static void shot(boolean aimed) {
        animate(aimed ? "aim_shoot" : "shoot", 42);
        holdFire = 0;
        BowHud.CROSSHAIR.onGunFired();
        BowRecoil.shot();
    }
    public static void reload() { animate("reload", 20); }
    public static void inspect() { if (!aiming && !charging) animate("inspect", 110); }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        boolean inGame = BowInputGate.inGame(mc.isWindowActive(), mc.mouseHandler.isMouseGrabbed(),
                mc.screen == null, mc.getOverlay() == null);
        if (!inGame) {
            if (charging && bridge != null) { bridge.cancelCharge(); charging = false; holdFire = 0; }
            if (aiming && bridge != null) { bridge.setAiming(false); aiming = false; }
            if (action.equals("hold_fire")) animate("idle", 0);
        }
        if (mc.isPaused()) return;
        BowHud.CROSSHAIR.tick();
        previousAim = aim;
        Player player = mc.player;
        if (mc.level == null) remoteAim.clear();
        else if (bridge != null) {
            for (Player remote : mc.level.players()) {
                if (remote == player) continue;
                float[] tracker = remoteAim.computeIfAbsent(remote, unused -> new float[2]);
                tracker[0] = tracker[1];
                tracker[1] = Mth.approach(tracker[1], bridge.isBow(remote.getMainHandItem())
                        && bridge.isAiming(remote) ? 1 : 0, (float)bridge.aimSpeed(remote.getMainHandItem()) / 5);
            }
            remoteAim.keySet().removeIf(remote -> remote.level() != mc.level || remote.isRemoved());
        }
        ItemStack stack = player == null ? ItemStack.EMPTY : player.getMainHandItem();
        boolean active = bridge != null && player != null && player.isAlive()
                && !player.isSpectator() && bridge.isBow(stack);
        if (active && (held.getItem() != stack.getItem() || selectedSlot != player.getInventory().selected)) {
            if (charging) { bridge.cancelCharge(); charging = false; }
            held = stack;
            selectedSlot = player.getInventory().selected;
            DRAW_LOCK.equip();
            animate(bridge.drawAnimationEnabled() ? "draw" : "idle", bridge.drawAnimationEnabled() ? 16 : 0);
        }
        if (active) DRAW_LOCK.tick(bridge.drawTimer(stack));
        previousFallSway = fallSway;
        if (player != null) {
            sprintIntensity = Mth.approach(sprintIntensity, player.isSprinting() ? 0.75F : 1, 0.1F);
            float deltaY = (float)Mth.clamp(player.yo - player.getY(), -1, 1);
            deltaY *= (1 - aim) * (1 - Mth.abs(player.getXRot()) / 90);
            fallSway = Mth.approach(fallSway, deltaY * 60 * BowClientConfig.SWAY_SENSITIVITY.get().floatValue(), 10);
        }
        boolean pressed = active && inGame && !drawing() && mc.options.keyAttack.isDown();
        if (pressed && !attackHeld && !bridge.hasArrow(player, stack)) bridge.reload();
        attackHeld = pressed;
        while (BowKeys.RELOAD.consumeClick()) if (active && inGame) bridge.reload();
        while (BowKeys.INSPECT.consumeClick()) if (active && inGame) inspect();
        while (BowKeys.INTERACT.consumeClick()) if (active && inGame) BowInteraction.interact();
        boolean nextAim = active && inGame && mc.options.keyUse.isDown()
                && !drawing() && !bridge.isReloading(player, stack);
        boolean nextCharge = active && inGame && !drawing() && mc.options.keyAttack.isDown()
                && bridge.hasArrow(player, stack) && !bridge.isReloading(player, stack);
        if (nextAim != aiming) { aiming = nextAim; if (bridge != null) bridge.setAiming(aiming); }
        if (aiming && !mc.options.keySprint.isDown()) player.setSprinting(false);
        if (nextCharge != charging) {
            charging = nextCharge;
            if (bridge != null) {
                if (BowInputGate.cancelRelease(active, inGame, !charging && drawing())) bridge.cancelCharge();
                else bridge.setCharging(charging);
            }
        }
        if (charging && !player.getCooldowns().isOnCooldown(stack.getItem())) holdFire = Math.min(20, holdFire + 1);
        else if (!charging) holdFire = Math.max(0, holdFire - 1);
        aim = Mth.approach(aim, aiming ? 1 : 0, active ? (float)bridge.aimSpeed(stack) / 5 : 0.2F);
        if (!active) {
            held = ItemStack.EMPTY;
            holdFire = 0;
            selectedSlot = -1;
            actionTicks = 0;
            action = "idle";
            DRAW_LOCK.equip();
            aim = previousAim = 0;
            return;
        }
        held = stack;
        if (aiming && (action.equals("draw") || action.equals("inspect"))) animate("idle", 0);
        if (charging) {
            if (!action.equals("hold_fire")) animate("hold_fire", 0);
        } else if (action.equals("hold_fire")) {
            animate("idle", 0);
        } else if (actionTicks > 0) {
            float speed = action.equals("inspect") ? 1 : bridge.animationSpeed(stack);
            actionTicks = Math.max(0, actionTicks - speed);
            if (actionTicks == 0) animate("idle", 0);
        }
        if (actionTicks == 0 && !charging) {
            String resting = BowClientConfig.SPRINT_ANIMATION.get() && player.isSprinting() && !aiming ? "sprint" : "idle";
            if (!action.equals(resting)) animate(resting, 0);
        }
    }

    @SubscribeEvent
    public static void interaction(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (bridge != null && mc.player != null && mc.screen == null
                && bridge.isBow(mc.player.getMainHandItem())) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    private static boolean lookingAtInteractable() {
        var mc = Minecraft.getInstance();
        if (mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit && mc.level != null) {
            var state = mc.level.getBlockState(hit.getBlockPos());
            if (state.is(net.minecraft.world.level.block.Blocks.IRON_DOOR)
                    || state.is(net.minecraft.world.level.block.Blocks.IRON_TRAPDOOR)) return false;
            return state.getBlock() instanceof net.minecraft.world.level.block.EntityBlock
                    || state.is(net.minecraft.world.level.block.Blocks.CRAFTING_TABLE)
                    || state.is(net.minecraft.tags.BlockTags.DOORS) || state.is(net.minecraft.tags.BlockTags.TRAPDOORS)
                    || state.is(net.minecraftforge.common.Tags.Blocks.CHESTS)
                    || state.is(net.minecraftforge.common.Tags.Blocks.FENCE_GATES);
        }
        return mc.hitResult instanceof net.minecraft.world.phys.EntityHitResult hit
                && hit.getEntity() instanceof net.minecraft.world.entity.decoration.ItemFrame;
    }

    @SubscribeEvent
    public static void fov(ComputeFovModifierEvent event) {
        if (bridge != null && bridge.isBow(event.getPlayer().getMainHandItem()))
            event.setNewFovModifier(event.getNewFovModifier() * (1 - 0.4F * aim(Minecraft.getInstance().getPartialTick())));
    }

}
