package com.korkuluk.standalonebow.client;

import net.minecraft.world.item.Item;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;

public final class BowAnimations {
    private BowAnimations() {}
    public static <T extends Item & GeoItem> AnimationController<T> controller(T item) {
        final long[] seen = { Long.MIN_VALUE };
        return new AnimationController<T>(item, "Controller", 0, state -> {
            var perspective = state.getData(DataTickets.ITEM_RENDER_PERSPECTIVE);
            if (perspective == null || !perspective.firstPerson())
                return state.setAndContinue(RawAnimation.begin().thenLoop("idle"));
            var player = net.minecraft.client.Minecraft.getInstance().player;
            if (player == null || player.getMainHandItem().getItem() != item)
                return state.setAndContinue(RawAnimation.begin().thenLoop("idle"));
            if (seen[0] != BowClient.revision()) {
                seen[0] = BowClient.revision();
                state.resetCurrentAnimation();
            }
            var rendered = state.getData(DataTickets.ITEMSTACK);
            String clip = BowClient.action();
            boolean accelerated = clip.equals("shoot") || clip.equals("aim_shoot")
                    || clip.equals("reload") || clip.equals("draw");
            state.setControllerSpeed(!accelerated || BowClient.bridge() == null || rendered == null ? 1
                    : BowClient.bridge().animationSpeed(rendered));
            RawAnimation animation = switch (clip) {
                case "hold_fire" -> RawAnimation.begin().then("hold_fire", Animation.LoopType.PLAY_ONCE).thenLoop("hold");
                case "shoot", "aim_shoot", "sprint" -> RawAnimation.begin().then(clip, Animation.LoopType.HOLD_ON_LAST_FRAME);
                case "draw", "reload", "inspect" -> RawAnimation.begin().thenPlay(clip).thenLoop("idle");
                default -> RawAnimation.begin().thenLoop("idle");
            };
            return state.setAndContinue(animation);
        }).setSoundKeyframeHandler(event -> {
            var mc = net.minecraft.client.Minecraft.getInstance();
            if (mc.player == null || mc.player.getMainHandItem().getItem() != item
                    || !mc.options.getCameraType().isFirstPerson()) return;
            String sound = switch (event.getKeyframeData().getSound()) {
                case "ejector_pull" -> "item.compound_bow.pull";
                case "ejector_release" -> "item.compound_bow.charge";
                case "reload_mag_in" -> "item.compound_bow.place_arrow";
                case "rustle" -> "item.gun_rustle";
                default -> null;
            };
            if (sound != null) {
                var location = new net.minecraft.resources.ResourceLocation("tacticalmilitarybow", sound);
                mc.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forLocalAmbience(
                        net.minecraft.sounds.SoundEvent.createVariableRangeEvent(location), 1, 1));
            }
        });
    }
}
