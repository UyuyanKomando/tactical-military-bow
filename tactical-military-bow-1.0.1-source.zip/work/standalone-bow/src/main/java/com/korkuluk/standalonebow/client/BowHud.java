package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Bow ammo, charge and impact HUD. */
@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT)
public final class BowHud {
    public static final BowDynamicCrosshair CROSSHAIR = new BowDynamicCrosshair();
    private BowHud() {}
    @SubscribeEvent public static void crosshair(RenderGuiOverlayEvent.Pre event) {
        if (event.getOverlay() != VanillaGuiOverlay.CROSSHAIR.type()) return;
        var mc = Minecraft.getInstance();
        if (mc.player == null || BowClient.bridge() == null || !BowClient.bridge().isBow(mc.player.getMainHandItem())) return;
        event.setCanceled(true);
        if (!mc.options.getCameraType().isFirstPerson() || BowClient.aim(event.getPartialTick()) > 0.5) return;
        int x = mc.getWindow().getGuiScaledWidth() / 2;
        int y = mc.getWindow().getGuiScaledHeight() / 2;
        event.getGuiGraphics().fill(x - 1, y - 1, x + 1, y + 1, 0xFFFFFFFF);
    }
    @SubscribeEvent public static void ammo(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        var mc = Minecraft.getInstance();
        var player = mc.player;
        var bridge = BowClient.bridge();
        if (player == null || bridge == null || mc.options.hideGui || !bridge.isBow(player.getMainHandItem())) return;
        var stack = player.getMainHandItem();
        var gui = event.getGuiGraphics();
        int width = mc.getWindow().getGuiScaledWidth(), height = mc.getWindow().getGuiScaledHeight();
        if (mc.screen == null && BowInteraction.canInteract()) {
            var hint = net.minecraft.network.chat.Component.translatable("gui.tacticalmilitarybow.interact",
                    BowKeys.INTERACT.getTranslatedKeyMessage());
            gui.drawString(mc.font, hint, (width - mc.font.width(hint)) / 2, height / 2 - 25, 0xFFFF55, false);
        }
        long markerNow = System.currentTimeMillis();
        long markerElapsed = BowImpactEffects.markerElapsed(markerNow);
        if (markerElapsed >= 0 && markerElapsed <= 300) {
            gui.flush();
            float xMarker = width / 2F - 8, yMarker = height / 2F - 8;
            float spread = BowImpactEffects.markerSpread(markerNow);
            boolean headshot = BowImpactEffects.markerHeadshot(markerNow);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderColor(1, headshot ? 0 : 1, headshot ? 0 : 1, 1F - markerElapsed / 300F);
            var texture = new ResourceLocation("tacz", "textures/crosshair/hit/hit_marker.png");
            gui.blit(texture, (int)(xMarker - spread), (int)(yMarker - spread), 0F, 0F, 8, 8, 16, 16);
            gui.blit(texture, (int)(xMarker + 8 + spread), (int)(yMarker - spread), 8F, 0F, 8, 8, 16, 16);
            gui.blit(texture, (int)(xMarker - spread), (int)(yMarker + 8 + spread), 0F, 8F, 8, 8, 16, 16);
            gui.blit(texture, (int)(xMarker + 8 + spread), (int)(yMarker + 8 + spread), 8F, 8F, 8, 8, 16, 16);
            gui.flush();
            RenderSystem.setShaderColor(1, 1, 1, 1);
            RenderSystem.disableBlend();
        }
        boolean timers = !BowClientConfig.AIM_HIDES_TIMERS.get() || !BowClient.aiming()
                || (BowClient.aim(event.getPartialTick()) > 0.5 && !mc.options.getCameraType().isFirstPerson());
        if (BowClientConfig.SHOW_TIMERS.get() && timers) {
            float progress = Math.min(1, BowClient.holdFire() / 20F);
            int alpha = progress == 1 ? (int)(80 + 80 * Math.sin(
                    (player.tickCount + event.getPartialTick()) / 2F)) : 128;
            int x = width / 2 - 16;
            int y = height / 2 + 16;
            gui.fill(x, y, x + (int)(32 * progress), y + 4, (alpha << 24) | 0xFFFFFF);
        }
        if (!BowClientConfig.SHOW_AMMO.get()) return;
        int x = (int)(width * 0.95 - 120) + BowClientConfig.AMMO_X_OFFSET.get();
        int y = height - 65 + BowClientConfig.AMMO_Y_OFFSET.get();
        String arrowKind = com.korkuluk.standalonebow.ArrowSelection.displayedKind(stack);
        var arrowItem = com.korkuluk.standalonebow.ArrowSelection.item(arrowKind);
        gui.pose().pushPose();
        gui.pose().translate(x, y - 3, 0);
        gui.pose().scale(1.5F, 1.5F, 1);
        gui.renderItem(stack, 0, 0);
        gui.pose().popPose();
        gui.fill(x + 29, y - 2, x + 30, y + 23, 0xFFDADADA);
        gui.pose().pushPose();
        gui.pose().translate(x + 35, y + 18, 0);
        gui.pose().scale(0.65F, 0.65F, 1);
        gui.drawString(mc.font, stack.getHoverName().getString(), 0, 0, 0xB8B8B8, true);
        gui.pose().popPose();
        gui.pose().pushPose();
        gui.pose().translate(x + 35, y + 28, 0);
        gui.pose().scale(0.75F, 0.75F, 1);
        gui.renderItem(arrowItem, 0, 0);
        gui.pose().popPose();
        gui.pose().pushPose();
        gui.pose().translate(x + 49, y + 30, 0);
        gui.pose().scale(0.65F, 0.65F, 1);
        gui.drawString(mc.font, arrowItem.getHoverName().getString(), 0, 0, 0xDADADA, true);
        gui.pose().popPose();
        boolean reloading = bridge.isReloading(player, stack);
        gui.pose().pushPose();
        gui.pose().translate(x + 35, y - 2, 0);
        gui.pose().scale(2, 2, 1);
        gui.drawString(mc.font, reloading && !player.isCrouching() ? net.minecraft.network.chat.Component.translatable("gui.tacticalmilitarybow.reloading").getString()
                : String.format(java.util.Locale.ROOT, "%03d", bridge.ammo(player, stack)), 0, 0, 0xFFFFFF, true);
        gui.pose().popPose();
        if (!reloading || player.isCrouching()) {
            int reserve = com.korkuluk.standalonebow.ArrowSelection.reserve(player, arrowKind);
            boolean infinite = player.isCreative() || (stack.getTag() != null && stack.getTag().getBoolean("IgnoreAmmo"))
                    || (arrowKind.equals("normal") && com.korkuluk.standalonebow.GunEnchantmentHelper.level(stack,
                    com.korkuluk.standalonebow.ModEnchantments.INFINITY) > 0);
            gui.drawString(mc.font, infinite ? "9999" : String.format(java.util.Locale.ROOT, "%04d", reserve), x + 73, y - 2, 0xB8B8B8, true);
        }
    }
}
