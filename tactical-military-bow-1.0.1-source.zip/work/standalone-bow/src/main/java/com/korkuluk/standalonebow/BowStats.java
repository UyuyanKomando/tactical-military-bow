package com.korkuluk.standalonebow;

/** Compound bow balance and timing values. */
public final class BowStats {
    public static final int MAX_CHARGE = 20;
    public static final int MIN_RELEASE_CHARGE = 7;
    public static final int SHOT_INTERVAL = 10;
    public static final int RELOAD_INTERVAL = 16;
    public static final int DRAW_INTERVAL = 10;
    public static final int PROJECTILE_LIFE = 1000;
    public static final double SPEED = 8;
    public static final double GRAVITY = -0.04;
    public static final float DAMAGE = 20;
    public static final float HEADSHOT_MULTIPLIER = 1.5F;
    public static final double ARROW_TIP_DISTANCE = (13.2675 - (8.812393751137217 + 8.780751085233032) * 0.4) / 16;
    private BowStats() {}
    public static float progress(int ticks) { return Math.min(1F, Math.max(0, ticks) / 20F); }
}
