package com.korkuluk.standalonebow.client;

public final class BowArrowVisibilityTest {
    public static void main(String[] args) {
        for (int slot = 0; slot < 9; slot++) for (int selected = 0; selected < 9; selected++)
            check(BowHandVisibility.showHotbarOnBack(slot, selected, true, false, false) == (slot == 0 && selected != 0),
                    "TaCZ slot-specific back display " + slot + ":" + selected);
        check(!BowHandVisibility.showHotbarOnBack(0, 1, false, false, false), "other hotbar item excluded");
        check(!BowHandVisibility.showHotbarOnBack(0, 1, true, true, false), "invisible hotbar excluded");
        check(!BowHandVisibility.showHotbarOnBack(0, 1, true, false, true), "spectator hotbar excluded");
        check(BowHandVisibility.showOnBack(true, false, false), "offhand bow shown on back");
        check(!BowHandVisibility.showOnBack(false, false, false), "no back bow without offhand bow");
        check(!BowHandVisibility.showOnBack(true, true, false), "invisible player has no back bow");
        check(!BowHandVisibility.showOnBack(true, false, true), "spectator has no back bow");
        check(BowHandVisibility.hide(true, true), "offhand bow hidden regardless of dominant arm");
        check(!BowHandVisibility.hide(false, true), "main-hand bow remains visible");
        check(!BowHandVisibility.hide(true, false), "other offhand items remain visible");
        check(!BowHandVisibility.hide(false, false), "other main-hand items remain visible");
        for (String action : new String[]{"idle", "hold_fire", "hold", "sprint", "inspect", "draw"})
            check(BowArrowVisibility.visible(true, true, action, 1, 1, 1), action);
        for (String action : new String[]{"shoot", "aim_shoot"}) {
            check(BowArrowVisibility.visible(true, true, action, 1, 1, 1), "automatic reload hand " + action);
            check(!BowArrowVisibility.visible(true, true, action, 0, 0, 0), "released arrow hidden " + action);
        }
        check(!BowArrowVisibility.visible(true, true, "reload", 1, 1, 1), "no duplicate during manual reload");
        check(!BowArrowVisibility.visible(false, true, "idle", 1, 1, 1), "third person");
        check(!BowArrowVisibility.visible(true, false, "idle", 1, 1, 1), "empty");
        check(!BowArrowVisibility.visible(true, true, "idle", 0, 1, 1), "collapsed");
        check(!BowArrowVisibility.visible(true, true, "idle", Float.NaN, 1, 1), "NaN");
        check(!BowArrowVisibility.visible(true, true, "idle", 1, Float.POSITIVE_INFINITY, 1), "infinity");
        check(!BowArrowVisibility.visible(true, true, "idle", 1, 1, -1), "negative");
        check(BowArrowVisibility.reloadVisible(true, "reload", 1, 1, 1), "reload arrow restored");
        check(!BowArrowVisibility.reloadVisible(true, "idle", 1, 1, 1), "reload hidden at idle");
        check(!BowArrowVisibility.reloadVisible(true, "reload", 0, 0, 0), "reload collapsed");
        check(!BowArrowVisibility.reloadVisible(false, "reload", 1, 1, 1), "reload third person");
        for (int heading = -180; heading <= 180; heading += 15) {
            double angle = Math.toRadians(heading);
            double modelRotation = Math.toRadians(180 + heading);
            check(Math.abs(-Math.sin(modelRotation) - Math.sin(angle)) < 1e-8, "flight X " + heading);
            check(Math.abs(-Math.cos(modelRotation) - Math.cos(angle)) < 1e-8, "flight Z " + heading);
            var view = new org.joml.Quaternionf().rotationY((float)angle);
            var forward = BowLaunchProjection.toWorld(new org.joml.Vector3f(0, 0, -1), view);
            check(Math.abs(forward.x - Math.sin(angle)) < 0.00001, "camera-to-world X " + heading);
            check(Math.abs(forward.z - Math.cos(angle)) < 0.00001, "camera-to-world Z " + heading);
            var camera = new org.joml.Quaternionf().rotationYXZ((float)angle, 0.23F, 0);
            var local = new org.joml.Vector3f(0.2F, -0.3F, -1.2F);
            var world = BowLaunchProjection.toWorld(local, camera);
            var viewMatrix = new org.joml.Matrix4f().rotationX(0.23F).rotateY((float)(Math.PI - angle));
            check(viewMatrix.transformPosition(world).distance(local) < 0.00001F,
                    "actual camera view round-trip " + heading);
        }
        System.out.println("BowArrowVisibilityTest: 238 checks passed, including TaCZ hotbar/back/offhand policy and launch projection");
    }
    private static void check(boolean condition, String name) { if (!condition) throw new AssertionError(name); }
}
