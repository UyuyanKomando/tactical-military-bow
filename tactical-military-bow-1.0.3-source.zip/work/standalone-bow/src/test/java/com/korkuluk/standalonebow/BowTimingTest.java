package com.korkuluk.standalonebow;

/** Run with plain javac/java; no Minecraft launch or external test dependency required. */
public final class BowTimingTest {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        check(BowStats.DAMAGE == 20, "base damage is twenty");
        check(BowStats.DAMAGE * BowStats.HEADSHOT_MULTIPLIER == 30, "headshot deals 150 percent damage");
        check(BowStats.MAX_CHARGE == 14, "full draw takes 0.7 seconds at twenty ticks per second");
        check(BowStats.progress(13) < 1 && BowStats.progress(14) == 1, "charge reaches full exactly at fourteen ticks");
        check(Math.abs(BowStats.CHARGE_ANIMATION_SPEED * 0.7 - 1) < 0.00001,
                "original one-second draw keyframe reaches full pose in 0.7 seconds");
        BowTiming timing = new BowTiming();
        check(timing.release(0) == 0, "release without press");
        check(timing.press(100), "begin draw");
        check(!timing.press(103), "duplicate press must not reset start");
        check(timing.release(106) == 0, "six ticks must not fire");
        check(timing.phase() == BowTiming.Phase.IDLE, "short release clears draw");
        check(timing.press(200), "begin minimum draw");
        check(Math.abs(timing.release(207) - 7F / 14) < 0.00001F, "minimum draw uses fourteen-tick charge curve");
        check(timing.release(208) == 0, "duplicate release must not fire");
        check(timing.press(216), "drawing may begin during the previous shot cooldown");
        check(!timing.press(217), "cooldown ending must not restart an accepted draw");
        check(timing.charge(217) == 1F / 14, "draw progresses through the cooldown boundary");
        timing.cancel();
        check(timing.press(217), "new draw at the cooldown boundary");
        check(timing.charge(230) < 1, "thirteen ticks below full draw");
        check(timing.charge(231) == 1, "fourteen ticks full draw");
        check(timing.charge(10000) == 1, "long draw stays capped");
        check(timing.release(10000) == 1, "full release retains capped charge");
        check(timing.reload(10001), "reload may begin during cooldown");
        check(!timing.press(10002), "drawing cannot interrupt active reload");
        check(!timing.tick(10017), "reload incomplete at sixteen elapsed ticks");
        check(timing.tick(10018), "reload completes at seventeen elapsed ticks");
        check(!timing.tick(10019), "reload completes only once");
        check(timing.reload(10100), "begin cancellable reload");
        timing.cancel();
        check(!timing.tick(10117), "cancelled reload must not load");
        check(timing.press(10200), "begin cancellable draw");
        timing.cancel();
        check(timing.release(10220) == 0, "cancelled draw must not shoot");
        check(timing.reload(10300), "second reload");
        check(!timing.reload(10310), "duplicate reload cannot reset timer");
        check(timing.tick(10317), "duplicate packet does not delay reload");
        for (int gap = 0; gap <= BowStats.SHOT_INTERVAL; gap++) {
            BowTiming rapid = new BowTiming();
            check(rapid.press(0), "rapid sequence initial press");
            check(rapid.release(14) == 1, "rapid sequence initial shot");
            check(rapid.press(14 + gap), "early next press must not be swallowed: " + gap);
            check(rapid.release(28 + gap) == 1, "full next draw must fire: " + gap);
            check(rapid.release(29 + gap) == 0, "duplicate release cannot fire: " + gap);
        }
        BowTiming limited = new BowTiming();
        check(limited.press(0) && limited.release(20) == 1, "cooldown test setup");
        check(limited.press(20), "can immediately start preparing next arrow");
        check(limited.release(27) == 0, "minimum draw cannot bypass ten-tick shot cooldown");
        check(limited.phase() == BowTiming.Phase.IDLE, "blocked release clears draw");
        check(limited.press(27), "can retry after an early release");
        check(limited.release(47) == 1, "retry fires normally");
        System.out.println("BowTimingTest: " + checks + " checks passed");
    }
}
