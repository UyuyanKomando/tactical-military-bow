package com.korkuluk.standalonebow;

public final class ArrowProfileTest {
    private static int checks;
    private static void equal(float actual, float expected) {
        if (Math.abs(actual - expected) > 0.0001F) throw new AssertionError(actual + " != " + expected);
        checks++;
    }
    public static void main(String[] args) {
        for (String kind : new String[]{"normal", "piercing", "poison", "flame", "explosive"}) {
            if (ArrowProfile.explodesInLava(kind) != kind.equals("explosive"))
                throw new AssertionError("Wrong lava behavior: " + kind);
            checks++;
        }
        equal(ArrowProfile.directDamage("normal", 20), 20);
        equal(ArrowProfile.directDamage("piercing", 20), 35);
        equal(ArrowProfile.directDamage("explosive", 20), 20);
        equal(ArrowProfile.directDamage("piercing", 10), 17.5F);
        equal(ArrowProfile.directDamage("piercing", 20) * 1.5F, 52.5F);
        equal(ArrowProfile.directDamage("normal", 0), 0);
        equal(ArrowProfile.EXPLOSION_DAMAGE, 50);
        equal(ArrowProfile.EXPLOSION_RADIUS, 6);
        equal(ArrowProfile.EXPLOSION_TIMEOUT, 600);
        equal(ArrowProfile.directDamage("poison", 20), 10);
        equal(ArrowProfile.directDamage("poison", 10), 5);
        equal(ArrowProfile.directDamage("poison", 0), 0);
        equal(ArrowProfile.directDamage("poison", 20) * 1.5F, 15);
        equal(ArrowProfile.POISON_DURATION, 200);
        equal(ArrowProfile.directDamage("flame", 20), 10);
        equal(ArrowProfile.directDamage("flame", 10), 5);
        equal(ArrowProfile.directDamage("flame", 0), 0);
        equal(ArrowProfile.FLAME_SECONDS, 10);
        for (String kind : new String[]{"normal", "piercing", "poison"}) {
            equal(ArrowProfile.recoverable(kind, true, false, false, false) ? 1 : 0, 1);
            equal(ArrowProfile.recoverable(kind, false, false, false, false) ? 1 : 0, 0);
            equal(ArrowProfile.recoverable(kind, true, true, false, false) ? 1 : 0, 0);
            equal(ArrowProfile.recoverable(kind, true, false, true, false) ? 1 : 0, 0);
        }
        equal(ArrowProfile.recoverable("normal", true, false, false, true) ? 1 : 0, 0);
        equal(ArrowProfile.recoverable("piercing", true, false, false, true) ? 1 : 0, 1);
        equal(ArrowProfile.recoverable("poison", true, false, false, true) ? 1 : 0, 1);
        equal(ArrowProfile.recoverable("explosive", true, false, false, false) ? 1 : 0, 0);
        equal(ArrowProfile.recoverable("flame", true, false, false, false) ? 1 : 0, 0);
        System.out.println("ArrowProfileTest: " + checks + " checks passed");
    }
}
