package com.korkuluk.standalonebow;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageScaling;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/** JEG bullet behavior: notably not tagged minecraft:is_projectile like vanilla arrows. */
public final class ModDamageTypes {
    public static final ResourceKey<DamageType> BULLET = ResourceKey.create(Registries.DAMAGE_TYPE,
            new ResourceLocation(StandaloneBow.ID, "bullet"));
    private static final DamageType TYPE = new DamageType("tacticalmilitarybow.bullet", DamageScaling.WHEN_CAUSED_BY_LIVING_NON_PLAYER, 0.05F);
    public static DamageSource projectile(Entity projectile, Entity shooter) {
        // The resource owner may supply the named data definition. The direct holder has identical
        // damage flags/exhaustion even before that definition is integrated; never use ARROW flags.
        Holder<DamageType> holder = projectile.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(BULLET).<Holder<DamageType>>map(reference -> reference).orElseGet(() -> Holder.direct(TYPE));
        return new BulletDamageSource(holder, projectile, shooter);
    }
    public static class BulletDamageSource extends DamageSource {
        private static final String[] SUFFIX = {"killed", "eliminated", "executed", "annihilated", "decimated"};
        public BulletDamageSource(Holder<DamageType> type, Entity direct, Entity causing) { super(type, direct, causing); }
        @Override public String getMsgId() { return "tacticalmilitarybow.bullet." + SUFFIX[ThreadLocalRandom.current().nextInt(SUFFIX.length)]; }
        @Override public Component getLocalizedDeathMessage(LivingEntity victim) {
            String key = "death.attack." + getMsgId();
            if (getEntity() == null && getDirectEntity() == null) {
                LivingEntity credit = victim.getKillCredit();
                return credit == null ? Component.translatable(key, victim.getDisplayName())
                        : Component.translatable(key + ".player", victim.getDisplayName(), credit.getDisplayName());
            }
            Component name = getEntity() == null ? getDirectEntity().getDisplayName() : getEntity().getDisplayName();
            ItemStack stack = getEntity() instanceof LivingEntity living ? living.getMainHandItem() : ItemStack.EMPTY;
            return !stack.isEmpty() && stack.hasCustomHoverName()
                    ? Component.translatable(key + ".item", victim.getDisplayName(), name, stack.getDisplayName())
                    : Component.translatable(key, victim.getDisplayName(), name);
        }
    }
    private ModDamageTypes() {}
}
