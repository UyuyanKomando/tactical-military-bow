package com.korkuluk.standalonebow.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class BowLaunchVisual {
    private static Vec3 tip;
    private static long capturedAt;
    private BowLaunchVisual() {}
    public static void capture(Matrix4f pose) {
        var mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        var camera = mc.gameRenderer.getMainCamera();
        Vector3f point = pose.transformPosition(new Vector3f(0.06855F / 16, 3.0898F / 16,
                -(float)com.korkuluk.standalonebow.BowStats.ARROW_TIP_DISTANCE));
        if (!Float.isFinite(point.x) || !Float.isFinite(point.y) || !Float.isFinite(point.z) || point.lengthSquared() > 16) return;
        point = BowLaunchProjection.toWorld(point, camera.rotation());
        tip = camera.getPosition().add(point.x, point.y, point.z);
        capturedAt = mc.level.getGameTime();
    }
    public static Vec3 recentTip() {
        var mc = Minecraft.getInstance();
        return mc.level != null && tip != null && mc.level.getGameTime() - capturedAt <= 4
                && mc.options.getCameraType().isFirstPerson() ? tip : null;
    }
}
