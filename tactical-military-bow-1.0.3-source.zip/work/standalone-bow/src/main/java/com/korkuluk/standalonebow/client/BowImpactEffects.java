package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.BowNetwork;
import com.korkuluk.standalonebow.StandaloneBow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Bow-only ClientPlayHandler feedback; packet callbacks execute on the client thread. */
@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT)
public final class BowImpactEffects {
    private static long lastSoundTime;
    private static long hitTimestamp = -1, headTimestamp = -1, killTimestamp = -1;
    private static TagKey<Block> tag(String name) { return TagKey.create(Registries.BLOCK, new ResourceLocation("tacticalmilitarybow", name)); }
    public static void entity(BowNetwork.EntityImpact impact) {
        var mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (impact.bloodOnly()) {
            if (BowClientConfig.ENABLE_BLOOD.get())
                for (int i = 0; i < 10; i++) mc.particleEngine.add(new BloodParticle(mc.level, impact.x(), impact.y(), impact.z()));
            return;
        }
        long now = System.currentTimeMillis();
        hitTimestamp = now;
        if ((impact.hitType() & 1) != 0) headTimestamp = now;
        if ((impact.hitType() & 4) != 0) killTimestamp = now;
        SoundEvent sound = (impact.hitType() & 2) != 0 ? SoundEvents.PLAYER_ATTACK_CRIT
                : (impact.hitType() & 1) != 0 ? SoundEvents.PLAYER_ATTACK_KNOCKBACK
                : impact.player() ? SoundEvents.PLAYER_HURT : StandaloneBow.HIT_MARKER.get();
        if (now - lastSoundTime > 50) {
            lastSoundTime = now;
            mc.getSoundManager().play(SimpleSoundInstance.forUI(sound, 1F, 1F + mc.level.random.nextFloat() * 0.2F));
        }
    }
    static long markerElapsed(long now) {
        return now - (now - killTimestamp <= 300 ? killTimestamp : hitTimestamp);
    }
    static boolean markerHeadshot(long now) { return now - headTimestamp <= 300; }
    static float markerSpread(long now) {
        return 4F + (now - killTimestamp <= 300 ? (now - killTimestamp) * 4F / 300F : 0);
    }
    public static void block(BowNetwork.BlockImpact impact) {
        var mc = Minecraft.getInstance();
        var level = mc.level;
        if (level == null || mc.player == null) return;
        var state = level.getBlockState(impact.pos());
        var face = impact.face();
        mc.particleEngine.add(new BulletHoleParticle(level, impact.x() + face.getStepX() * .005,
                impact.y() + face.getStepY() * .005, impact.z() + face.getStepZ() * .005, face, impact.pos()));
        // Upstream Vec3.add returns a new vector that is discarded: normals stay unperturbed.
        double x = face.getStepX(), y = face.getStepY(), z = face.getStepZ();
        var type = state.getSoundType();
        boolean metal = state.is(tag("metal")) || type == SoundType.METAL;
        boolean stone = state.is(tag("stone")) || type == SoundType.STONE;
        boolean wood = state.is(BlockTags.MINEABLE_WITH_AXE) || state.is(tag("wood")) || type == SoundType.WOOD;
        if (metal) sound(impact, "block.hit.metal", .5F);
        if (stone) sound(impact, "block.hit.stone", .4F);
        if (wood) sound(impact, "block.hit.wood", .4F);
        if (state.is(tag("squishy"))) sound(impact, "block.hit.squishy", 1F);
        if (stone || wood) level.addParticle(ParticleTypes.CLOUD, stone, impact.x(), impact.y(), impact.z(),
                x * level.random.nextFloat() / 10, y * level.random.nextFloat() / 10, z * level.random.nextFloat() / 10);
        for (int pass = 0; pass < (metal ? 1 : 0) + (stone ? 1 : 0); pass++)
            for (int i = 0; i < 2; i++) mc.particleEngine.add(new SparkParticle(level, impact.x(), impact.y(), impact.z()));
        double distance = Math.sqrt(mc.player.distanceToSqr(impact.x(), impact.y(), impact.z()));
        if (distance < 32) for (int i = 0; i < 4; i++) level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, state),
                impact.x(), impact.y(), impact.z(), x, y, z);
        if (distance <= 32) level.playLocalSound(impact.x(), impact.y(), impact.z(), type.getBreakSound(), SoundSource.BLOCKS, 1F, 2F, false);
    }
    private static void sound(BowNetwork.BlockImpact impact, String path, float volume) {
        Minecraft.getInstance().level.playLocalSound(impact.x(), impact.y(), impact.z(),
                SoundEvent.createVariableRangeEvent(new ResourceLocation("tacticalmilitarybow", path)), SoundSource.BLOCKS, volume, 1F, false);
    }
    private BowImpactEffects() {}
}
