package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.CompoundBowItem;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.api.distmarker.Dist;

@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT)
public final class TaczArrowSelect {
    private static final KeyMapping KEY = key();
    private static KeyMapping key() {
        try {
            return (KeyMapping)Class.forName("com.tacz.guns.client.input.FireSelectKey").getField("FIRE_SELECT_KEY").get(null);
        } catch (ReflectiveOperationException ex) { throw new IllegalStateException("TaCZ fire-select key unavailable", ex); }
    }
    private static void select() {
        var mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || !mc.isWindowActive() || mc.isPaused()
                || !(mc.player.getMainHandItem().getItem() instanceof CompoundBowItem)) return;
        var bridge = BowClient.bridge();
        var stack = mc.player.getMainHandItem();
        if (bridge == null || BowClient.drawing() || BowClient.charging()
                || bridge.isCharging(mc.player, stack) || bridge.isReloading(mc.player, stack)) return;
        mc.setScreen(new ArrowWheelScreen(mc.player.getInventory().selected));
    }
    public static boolean matches(int key, int scan) { return KEY.matches(key, scan); }
    public static boolean matchesMouse(int button) { return KEY.matchesMouse(button); }
    @SubscribeEvent public static void keyboard(InputEvent.Key event) {
        if (event.getAction() == 1 && KEY.matches(event.getKey(), event.getScanCode())) select();
    }
    @SubscribeEvent public static void mouse(InputEvent.MouseButton.Post event) {
        if (event.getAction() == 1 && KEY.matchesMouse(event.getButton())) select();
    }
}
