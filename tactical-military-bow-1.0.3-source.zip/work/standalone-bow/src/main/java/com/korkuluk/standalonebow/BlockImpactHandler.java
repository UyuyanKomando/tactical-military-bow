package com.korkuluk.standalonebow;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import net.minecraftforge.network.PacketDistributor;

/** Bow-compatible original projectile block interactions; tags may extend the vanilla baseline. */
public final class BlockImpactHandler {
    private static final Method TARGET = ObfuscationReflectionHelper.findMethod(TargetBlock.class, "m_57391_",
            LevelAccessor.class, BlockState.class, BlockHitResult.class, Entity.class);
    private static final TagKey<Block> FRAGILE = TagKey.create(Registries.BLOCK, new ResourceLocation(StandaloneBow.ID, "fragile"));
    private static final TagKey<Block> WOOD = TagKey.create(Registries.BLOCK, new ResourceLocation(StandaloneBow.ID, "wood"));
    private static final TagKey<Block> GLASS = TagKey.create(Registries.BLOCK, new ResourceLocation("forge", "glass"));
    private static final TagKey<Block> PANES = TagKey.create(Registries.BLOCK, new ResourceLocation("forge", "glass_panes"));
    private static final Set<String> FRAGILE_VANILLA = Set.of("lily_pad", "cocoa", "end_rod", "scaffolding", "sea_pickle",
            "turtle_egg", "glowstone", "sea_lantern", "ice", "blue_ice", "frosted_ice", "packed_ice", "bamboo",
            "small_amethyst_bud", "medium_amethyst_bud", "large_amethyst_bud", "amethyst_cluster", "lantern",
            "soul_lantern", "pointed_dripstone", "melon", "pumpkin", "carved_pumpkin", "jack_o_lantern", "bee_nest",
            "beehive", "sculk_sensor", "calibrated_sculk_sensor");
    private BlockImpactHandler() {}
    public static void onHit(BowArrowEntity arrow, BlockHitResult hit) {
        ServerLevel level = (ServerLevel)arrow.level();
        BlockPos pos = hit.getBlockPos();
        BlockState state = level.getBlockState(pos);
        Block block = state.getBlock();
        level.gameEvent(arrow, GameEvent.BLOCK_DESTROY, arrow.position());
        if (arrow.getOwner() instanceof net.minecraft.world.entity.player.Player) {
            float hardness = state.getDestroySpeed(level, pos);
            var id = BuiltInRegistries.BLOCK.getKey(block);
            boolean fragile = state.is(FRAGILE) || state.is(GLASS) || state.is(PANES) || state.is(BlockTags.CANDLES)
                    || (id.getNamespace().equals("minecraft") && FRAGILE_VANILLA.contains(id.getPath()));
            if (Config.COMMON.enableGlassBreaking.get() && fragile && hardness >= 0
                    && level.random.nextFloat() < Config.COMMON.fragileBlockBreakChance.get() / (hardness + 1)) {
                if (level.getGameRules().getBoolean(GameRules.RULE_DOBLOCKDROPS)) specialDrops(level, state, pos);
                boolean pumpkin = state.is(Blocks.PUMPKIN) || state.is(Blocks.CARVED_PUMPKIN) || state.is(Blocks.JACK_O_LANTERN);
                level.destroyBlock(pos, !pumpkin && Config.COMMON.fragileBlockDrops.get());
                if (state.is(Blocks.ICE)) {
                    boolean water = level.getBlockState(pos.below()).is(Blocks.WATER);
                    int neighbors = 0;
                    for (var direction : net.minecraft.core.Direction.values())
                        if (level.getBlockState(pos.relative(direction)).is(Blocks.ICE)) neighbors++;
                    if (water || neighbors > 2) level.setBlock(pos, Blocks.WATER.defaultBlockState(), 0);
                }
            }
            boolean wood = state.is(WOOD) || state.is(BlockTags.MINEABLE_WITH_AXE);
            if (Config.COMMON.enableWoodBreaking.get() && wood && hardness >= 0
                    && level.random.nextFloat() < Config.COMMON.woodBlockBreakChance.get() / (hardness + 1))
                level.destroyBlock(pos, false);
        }
        if (!state.canBeReplaced()) arrow.finishBlockImpact(hit);
        BowNetwork.CHANNEL.send(PacketDistributor.TRACKING_CHUNK.with(() -> level.getChunkAt(pos)),
                new BowNetwork.BlockImpact(hit.getLocation().x, hit.getLocation().y, hit.getLocation().z, pos, hit.getDirection()));
        level.updateNeighborsAt(pos, level.getBlockState(pos).getBlock());
        level.scheduleTick(pos, level.getBlockState(pos).getBlock(), 1);
        if (block instanceof TargetBlock && arrow.getOwner() instanceof ServerPlayer player) {
            int power = 0;
            try { power = (int)TARGET.invoke(block, level, state, hit, arrow); }
            catch (IllegalAccessException | InvocationTargetException exception) {
                throw new IllegalStateException("Original target-block interaction failed", exception);
            }
            player.awardStat(Stats.TARGET_HIT);
            CriteriaTriggers.TARGET_BLOCK_HIT.trigger(player, arrow, hit.getLocation(), power);
        }
        if (block instanceof BellBlock bell) bell.attemptToRing(level, pos, hit.getDirection());
    }
    public static void ignite(BowArrowEntity arrow, BlockHitResult hit) {
        BlockPos pos = hit.getBlockPos().relative(hit.getDirection());
        if (BaseFireBlock.canBePlacedAt(arrow.level(), pos, hit.getDirection())) {
            arrow.level().setBlock(pos, BaseFireBlock.getState(arrow.level(), pos), 11);
            ((ServerLevel)arrow.level()).sendParticles(ParticleTypes.LAVA,
                    hit.getLocation().x - 1 + arrow.level().random.nextDouble() * 2, hit.getLocation().y,
                    hit.getLocation().z - 1 + arrow.level().random.nextDouble() * 2, 4, 0, 0, 0, 0);
        }
    }
    public static void igniteFlameArrow(BowArrowEntity arrow, BlockHitResult hit) {
        if (!(arrow.level() instanceof ServerLevel level)) return;
        BlockPos pos = hit.getBlockPos().relative(hit.getDirection());
        if (!level.isEmptyBlock(pos)) return;
        if (arrow.getOwner() instanceof ServerPlayer player
                && (!level.mayInteract(player, hit.getBlockPos())
                || !player.mayUseItemAt(hit.getBlockPos(), hit.getDirection(), new ItemStack(Items.FLINT_AND_STEEL)))) return;
        // Vanilla fire handles survival, spread and fuel, including nonflammable Nether wood.
        if (BaseFireBlock.canBePlacedAt(level, pos, hit.getDirection())) {
            level.setBlock(pos, BaseFireBlock.getState(level, pos), 11);
            level.gameEvent(arrow.getOwner(), GameEvent.BLOCK_PLACE, pos);
        }
    }
    private static void specialDrops(ServerLevel level, BlockState state, BlockPos pos) {
        if (state.is(Blocks.MELON)) { drop(level, pos, Items.MELON_SLICE, level.random.nextInt(6) + 1); drop(level, pos, Items.MELON_SEEDS, level.random.nextInt(2) + 1); }
        if (state.is(Blocks.CARVED_PUMPKIN) || state.is(Blocks.JACK_O_LANTERN)) drop(level, pos, Items.PUMPKIN_SEEDS, level.random.nextInt(6) + 1);
        if (state.is(Blocks.PUMPKIN)) { drop(level, pos, Items.PUMPKIN_SEEDS, level.random.nextInt(2) + 1); drop(level, pos, Items.CARVED_PUMPKIN, 1); }
        if (state.is(Blocks.COCOA)) drop(level, pos, Items.COCOA_BEANS, level.random.nextInt(3) + 1);
        if (state.is(Blocks.BEEHIVE) || state.is(Blocks.BEE_NEST)) drop(level, pos, Items.HONEYCOMB, level.random.nextInt(3) + 1);
    }
    private static void drop(ServerLevel level, BlockPos pos, Item item, int count) {
        level.addFreshEntity(new ItemEntity(level, pos.getCenter().x, pos.getCenter().y, pos.getCenter().z, new ItemStack(item, count)));
    }
}
