package com.korkuluk.standalonebow;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import java.util.List;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import java.util.function.Consumer;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

public class CompoundBowItem extends Item implements GeoItem {
    private final AnimatableInstanceCache animationCache = GeckoLibUtil.createInstanceCache(this);
    public CompoundBowItem(Properties properties) { super(properties); }
    @Override public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.tacticalmilitarybow.bow.description_1").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.tacticalmilitarybow.bow.description_2").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.empty());
        tooltip.add(Component.translatable("tooltip.tacticalmilitarybow.bow.ammo").withStyle(ChatFormatting.GREEN));
        int loaded = stack.hasTag() ? Math.min(1, Math.max(0, stack.getTag().getInt("AmmoCount"))) : 0;
        tooltip.add(Component.literal(loaded + " / 1").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.tacticalmilitarybow.bow.type").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.tacticalmilitarybow.bow.damage",
                java.math.BigDecimal.valueOf(ArrowProfile.directDamage(TacticalArrowItem.loadedKind(stack), fullChargeDamage(stack))).stripTrailingZeros().toPlainString())
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.empty());
        tooltip.add(Component.translatable("tooltip.tacticalmilitarybow.bow.armor", 0).withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.tacticalmilitarybow.bow.headshot",
                Math.round(BowStats.HEADSHOT_MULTIPLIER * 100)).withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.tacticalmilitarybow.bow.quiver").withStyle(ChatFormatting.DARK_GREEN));
    }
    public static float fullChargeDamage(ItemStack stack) {
        float additional = stack.hasTag() ? stack.getTag().getFloat("AdditionalDamage") : 0;
        return Math.max(0, GunEnchantmentHelper.getWitheredDamage(stack,
                GunEnchantmentHelper.getAcceleratorDamage(stack, BowStats.DAMAGE + additional)));
    }
    @Override public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return animationCache; }
    @Override public boolean isPerspectiveAware() { return true; }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(com.korkuluk.standalonebow.client.BowAnimations.controller(this));
    }
    @Override public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new com.korkuluk.standalonebow.client.BowItemExtensions());
    }
    public static boolean hasAmmo(ItemStack stack) {
        return stack.getOrCreateTag().getBoolean("IgnoreAmmo") || stack.getOrCreateTag().getInt("AmmoCount") > 0;
    }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.BOW; }
    @Override public int getUseDuration(ItemStack stack) { return 72000; }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        // Aiming and firing are handled independently; vanilla use must not draw or fire.
        return InteractionResultHolder.pass(stack);
    }
    @Override public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int remaining) {
        if (entity instanceof ServerPlayer player) BowMechanics.release(player);
    }
    @Override public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        return false;
    }
    @Override public boolean isEnchantable(ItemStack stack) { return false; }
    @Override public boolean isBookEnchantable(ItemStack stack, ItemStack book) { return false; }
    @Override public int getEnchantmentValue() { return 0; }
    @Override public boolean isFoil(ItemStack stack) { return false; }
    @Override public boolean isValidRepairItem(ItemStack bow, ItemStack material) {
        return false;
    }
}
