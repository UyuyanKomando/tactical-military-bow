package com.korkuluk.standalonebow.client;

import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT)
public final class BowPlayerEvents {
    private BowPlayerEvents() {}
    @SubscribeEvent public static void before(RenderPlayerEvent.Pre event) {
        var bridge = BowClient.bridge();
        var player = event.getEntity();
        if (bridge != null && bridge.isBow(player.getMainHandItem())
                && BowClient.aim(player, event.getPartialTick()) > 0.001F)
            BowClient.POSE.applyPlayerPreRender(player, InteractionHand.MAIN_HAND,
                    BowClient.aim(player, event.getPartialTick()), event.getPoseStack(), event.getMultiBufferSource());
    }
    @SubscribeEvent public static void after(RenderPlayerEvent.Post event) {
        var model = event.getRenderer().getModel();
        boolean slim = event.getEntity() instanceof net.minecraft.client.player.AbstractClientPlayer client
                && client.getModelName().equals("slim");
        model.rightArm.setPos(-5, slim ? 2.5F : 2, 0);
        model.leftArm.setPos(5, slim ? 2.5F : 2, 0);
    }
}
