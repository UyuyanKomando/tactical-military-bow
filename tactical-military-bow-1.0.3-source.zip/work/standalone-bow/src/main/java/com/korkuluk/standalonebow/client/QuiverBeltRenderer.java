package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.registries.ForgeRegistries;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.client.CuriosRendererRegistry;
import top.theillusivec4.curios.api.client.ICurioRenderer;

@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class QuiverBeltRenderer implements ICurioRenderer {
    @SubscribeEvent
    public static void setup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            var item = ForgeRegistries.ITEMS.getValue(new ResourceLocation("tacticalmilitarybow", "quiver"));
            if (item != null) CuriosRendererRegistry.register(item, QuiverBeltRenderer::new);
        });
    }

    @Override
    public <T extends LivingEntity, M extends EntityModel<T>> void render(ItemStack stack,
            SlotContext slot, PoseStack pose, RenderLayerParent<T, M> parent,
            MultiBufferSource buffers, int light, float limbSwing, float limbSwingAmount,
            float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!slot.identifier().equals("belt") || !slot.visible()) return;
        if (!(parent.getModel() instanceof HumanoidModel<?> model)) return;
        pose.pushPose();
        try {
            model.body.translateAndRotate(pose);
            boolean right = slot.entity().getMainArm() == HumanoidArm.RIGHT;
            var leg = right ? model.rightLeg : model.leftLeg;
            if (slot.entity().isCrouching()) pose.translate(0, -0.125, -0.275);
            float angle = leg.xRot;
            try {
                leg.xRot = angle * 0.3f;
                leg.translateAndRotate(pose);
            } finally {
                leg.xRot = angle;
            }
            pose.translate(0, -0.0625, 0.08);
            double offset = slot.entity().getItemBySlot(EquipmentSlot.LEGS).getItem() instanceof ArmorItem
                    ? 0.21975 : 0.1885;
            // Right-leg X is negative: move outward, not back toward the body's center.
            pose.translate(right ? -offset : offset, 0, 0);
            Minecraft.getInstance().getItemRenderer().renderStatic(stack, ItemDisplayContext.HEAD,
                    light, OverlayTexture.NO_OVERLAY, pose, buffers,
                    slot.entity().level(), slot.entity().getId());
        } finally {
            pose.popPose();
        }
    }
}
