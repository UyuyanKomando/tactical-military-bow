package com.korkuluk.standalonebow.client;

public final class BowHandVisibility {
    private BowHandVisibility() {}
    public static boolean hide(boolean offhand, boolean tacticalBow) {
        return offhand && tacticalBow;
    }
    public static boolean showOnBack(boolean offhandBow, boolean invisible, boolean spectator) {
        return offhandBow && !invisible && !spectator;
    }
    public static boolean showHotbarOnBack(int slot, int selectedSlot, boolean bow, boolean invisible, boolean spectator) {
        return slot == 0 && selectedSlot != slot && showOnBack(bow, invisible, spectator);
    }
}
