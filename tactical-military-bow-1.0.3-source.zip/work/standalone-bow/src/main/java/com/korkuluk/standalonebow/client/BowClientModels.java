package com.korkuluk.standalonebow.client;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class BowClientModels {
    private BowClientModels() {}
    @SubscribeEvent public static void layers(net.minecraftforge.client.event.EntityRenderersEvent.AddLayers event) {
        for (String skin : event.getSkins()) {
            net.minecraft.client.renderer.entity.player.PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) renderer.addLayer(new BowBackLayer(renderer));
        }
    }
    @SubscribeEvent public static void models(ModelEvent.RegisterAdditional event) {
        event.register(new ResourceLocation("tacticalmilitarybow", "special/gun/compound_bow"));
    }
    @SubscribeEvent public static void entities(net.minecraftforge.client.event.EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(com.korkuluk.standalonebow.StandaloneBow.ARROW.get(), BowArrowRenderer::new);
        event.registerEntityRenderer(com.korkuluk.standalonebow.StandaloneBow.DYNAMIC_HELMET.get(), BowHelmetRenderer::new);
    }
}
