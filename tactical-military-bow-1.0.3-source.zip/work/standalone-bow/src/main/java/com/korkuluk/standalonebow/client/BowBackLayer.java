package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.CompoundBowItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;

public final class BowBackLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation MODEL = new ResourceLocation("tacticalmilitarybow", "special/gun/compound_bow");
    public BowBackLayer(PlayerRenderer renderer) { super(renderer); }
    @Override public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                                 float walk, float speed, float partial, float age, float yaw, float pitch) {
        var stack = player.getOffhandItem();
        if (BowHandVisibility.showOnBack(stack.getItem() instanceof CompoundBowItem, player.isInvisible(), player.isSpectator()))
            renderBow(pose, buffers, light, stack, -0.08, -25);
        var hotbar = player.getInventory().getItem(0);
        if (BowHandVisibility.showHotbarOnBack(0, player.getInventory().selected,
                hotbar.getItem() instanceof CompoundBowItem, player.isInvisible(), player.isSpectator()))
            renderBow(pose, buffers, light, hotbar, -0.08, -25);
    }
    private void renderBow(PoseStack pose, MultiBufferSource buffers, int light,
                           net.minecraft.world.item.ItemStack stack, double side, float angle) {
        pose.pushPose();
        try {
            getParentModel().body.translateAndRotate(pose);
            pose.translate(side, 0.35, 0.25);
            pose.mulPose(Axis.ZP.rotationDegrees(angle));
            pose.mulPose(Axis.YP.rotationDegrees(90));
            pose.scale(0.8F, -0.8F, 0.8F);
            // Center the static bow mesh, without the item-frame or first-person transforms.
            pose.translate(-7.63724 / 16, -2.464945 / 16, -15.7795 / 16);
            var mc = Minecraft.getInstance();
            mc.getItemRenderer().renderModelLists(mc.getModelManager().getModel(MODEL), stack, light,
                    OverlayTexture.NO_OVERLAY, pose, buffers.getBuffer(RenderType.entityCutoutNoCull(InventoryMenu.BLOCK_ATLAS)));
        } finally { pose.popPose(); }
    }
}
