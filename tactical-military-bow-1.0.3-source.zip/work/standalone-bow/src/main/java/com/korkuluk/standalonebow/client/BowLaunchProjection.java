package com.korkuluk.standalonebow.client;

import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;

public final class BowLaunchProjection {
    private BowLaunchProjection() {}
    public static Vector3f toWorld(Vector3f cameraPoint, Quaternionfc viewRotation) {
        // Camera rotation uses +Z forward; rendered hand coordinates use -Z forward.
        return new Vector3f(cameraPoint).rotate(new Quaternionf(viewRotation).rotateY((float)Math.PI));
    }
}
