package com.korkuluk.standalonebow.client.mixin;

import com.korkuluk.standalonebow.client.BowClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerModel.class)
public abstract class BowPlayerModelMixin<T extends LivingEntity> {
    @SuppressWarnings("unchecked")
    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void tacticalmilitarybow$pose(T entity, float pos, float speed, float bob, float yaw, float pitch, CallbackInfo ci) {
        if (!(entity instanceof Player player) || BowClient.bridge() == null
                || !BowClient.bridge().isBow(player.getMainHandItem())) return;
        PlayerModel<T> model = (PlayerModel<T>)(Object)this;
        if (BowClient.aim(player, Minecraft.getInstance().getPartialTick()) <= 0.001F) return;
        BowClient.POSE.applyPlayerModelRotation(player, model.rightArm, model.leftArm, model.head,
                InteractionHand.MAIN_HAND, BowClient.aim(player, Minecraft.getInstance().getPartialTick()));
        model.rightSleeve.copyFrom(model.rightArm);
        model.leftSleeve.copyFrom(model.leftArm);
        model.hat.copyFrom(model.head);
    }
}
