package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class BowKeys {
    public static final KeyMapping RELOAD = new KeyMapping("key.tacticalmilitarybow.reload", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.tacticalmilitarybow");
    public static final KeyMapping INSPECT = new KeyMapping("key.tacticalmilitarybow.inspect", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.tacticalmilitarybow");
    private BowKeys() {}
    public static final KeyMapping INTERACT = new KeyMapping("key.tacticalmilitarybow.interact", KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O, "key.categories.tacticalmilitarybow");
    @SubscribeEvent public static void register(RegisterKeyMappingsEvent event) {
        event.register(RELOAD);
        event.register(INSPECT);
        event.register(INTERACT);
    }
}
