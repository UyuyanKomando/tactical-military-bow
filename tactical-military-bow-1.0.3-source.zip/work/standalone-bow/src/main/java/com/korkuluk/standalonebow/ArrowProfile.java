package com.korkuluk.standalonebow;

public final class ArrowProfile {
    public static final int POISON_DURATION = 200;
    public static final int FLAME_SECONDS = 10;
    public static final float EXPLOSION_DAMAGE = 50;
    public static final float EXPLOSION_RADIUS = 6;
    public static final int EXPLOSION_TIMEOUT = 600;
    private ArrowProfile() {}
    public static boolean explodesInLava(String kind) { return "explosive".equals(kind); }
    public static boolean recoverable(String kind, boolean consumed, boolean creative, boolean ignoreAmmo, boolean infinity) {
        return consumed && !creative && !ignoreAmmo && !("normal".equals(kind) && infinity)
                && ("normal".equals(kind) || "piercing".equals(kind) || "poison".equals(kind));
    }
    public static float directDamage(String kind, float baseDamage) {
        return baseDamage * ("piercing".equals(kind) ? 1.75F : "poison".equals(kind) || "flame".equals(kind) ? 0.5F : 1F);
    }
}
