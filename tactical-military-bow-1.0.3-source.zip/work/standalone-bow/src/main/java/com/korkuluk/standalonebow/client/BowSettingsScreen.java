package com.korkuluk.standalonebow.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.ForgeConfigSpec;

public final class BowSettingsScreen extends Screen {
    private final Screen parent;
    public BowSettingsScreen(Screen parent) { super(Component.translatable("settings.tacticalmilitarybow.title")); this.parent = parent; }
    @Override protected void init() {
        int w = Math.min(310, width - 20), x = (width - w) / 2, half = (w - 6) / 2;
        toggle(x, 32, half, "settings.tacticalmilitarybow.ammo", BowClientConfig.SHOW_AMMO);
        toggle(x + half + 6, 32, half, "settings.tacticalmilitarybow.charge", BowClientConfig.SHOW_TIMERS);
        toggle(x, 56, half, "settings.tacticalmilitarybow.hide_charge", BowClientConfig.AIM_HIDES_TIMERS);
        toggle(x + half + 6, 56, half, "settings.tacticalmilitarybow.crosshair", BowClientConfig.DYNAMIC_CROSSHAIR);
        toggle(x, 80, half, "settings.tacticalmilitarybow.recoil", BowClientConfig.CAMERA_RECOIL);
        toggle(x + half + 6, 80, half, "settings.tacticalmilitarybow.sprint", BowClientConfig.SPRINT_ANIMATION);
        addRenderableWidget(new SettingSlider(x, 104, w, "settings.tacticalmilitarybow.ads", BowClientConfig.ADS_SENSITIVITY, 1));
        addRenderableWidget(new SettingSlider(x, 128, w, "settings.tacticalmilitarybow.sway", BowClientConfig.SWAY_SENSITIVITY, 1));
        addRenderableWidget(new SettingSlider(x, 152, w, "settings.tacticalmilitarybow.bob", BowClientConfig.BOBBING_INTENSITY, 2));
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), button -> onClose()).bounds(x, height - 28, w, 20).build());
    }
    private void toggle(int x, int y, int width, String title, ForgeConfigSpec.BooleanValue config) {
        addRenderableWidget(CycleButton.onOffBuilder(config.get()).create(x, y, width, 20,
                Component.translatable(title), (button, value) -> config.set(value)));
    }
    @Override public void onClose() { BowClientConfig.SPEC.save(); minecraft.setScreen(parent); }
    @Override public void render(GuiGraphics gui, int mouseX, int mouseY, float partial) {
        renderBackground(gui);
        gui.drawCenteredString(font, title, width / 2, 12, 0xFFFFFF);
        super.render(gui, mouseX, mouseY, partial);
    }
    private static final class SettingSlider extends AbstractSliderButton {
        private final String title;
        private final ForgeConfigSpec.DoubleValue config;
        private final double maximum;
        SettingSlider(int x, int y, int width, String title, ForgeConfigSpec.DoubleValue config, double maximum) {
            super(x, y, width, 20, Component.empty(), config.get() / maximum);
            this.title = title; this.config = config; this.maximum = maximum; updateMessage();
        }
        @Override protected void updateMessage() {
            setMessage(Component.translatable(title).append(": " + String.format(java.util.Locale.ROOT, "%.2f", value * maximum)));
        }
        @Override protected void applyValue() { config.set(value * maximum); }
    }
}
