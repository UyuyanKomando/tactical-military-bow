package com.korkuluk.standalonebow;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.core.Holder;
import net.minecraft.util.Mth;
import net.minecraft.stats.Stats;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ShieldItem;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class BowMechanics {
    private static final Map<UUID, State> STATES = new HashMap<>();
    private static final Map<UUID, BowTiming> TIMINGS = new HashMap<>();
    private static final Map<UUID, Boolean> AIMING = new HashMap<>();
    private static final Map<UUID, Integer> SHOTS = new HashMap<>();
    private static final Map<UUID, BowNetwork.State> LAST_SYNC = new HashMap<>();
    public static BowNetwork.State snapshot(ServerPlayer player) {
        State state = STATES.get(player.getUUID());
        boolean valid = state != null && state.matches(player);
        return new BowNetwork.State(player.getId(), AIMING.getOrDefault(player.getUUID(), false),
                valid && !state.reloading, valid && state.reloading,
                valid && !state.reloading ? timing(player).charge(player.level().getGameTime()) : 0,
                player.getMainHandItem().getItem() instanceof CompoundBowItem
                        ? Math.max(0, player.getMainHandItem().getOrCreateTag().getInt("AmmoCount")) : 0,
                SHOTS.getOrDefault(player.getUUID(), 0));
    }
    private static void sync(ServerPlayer player) {
        BowNetwork.State state = snapshot(player);
        if (!state.equals(LAST_SYNC.put(player.getUUID(), state))) BowNetwork.sync(player, state);
    }
    private static BowTiming timing(ServerPlayer player) {
        return TIMINGS.computeIfAbsent(player.getUUID(), id -> new BowTiming());
    }
    public static void aim(ServerPlayer player, boolean aiming) {
        if (aiming && !eligible(player)) return;
        if (AIMING.getOrDefault(player.getUUID(), false) == aiming) return;
        AIMING.put(player.getUUID(), aiming); sync(player);
    }
    private static final class State {
        final ItemStack stack;
        final int slot;
        final long started;
        final boolean reloading;
        State(ServerPlayer player, boolean reload) {
            stack = player.getMainHandItem(); slot = player.getInventory().selected;
            started = player.level().getGameTime(); reloading = reload;
        }
        boolean matches(ServerPlayer player) {
            return player.isAlive() && !player.isSpectator() && player.getMainHandItem() == stack
                    && player.getInventory().selected == slot && stack.getItem() instanceof CompoundBowItem;
        }
    }
    private static boolean eligible(ServerPlayer player) {
        return player.isAlive() && !player.isSpectator() && player.getMainHandItem().getItem() instanceof CompoundBowItem
                && !(player.getUseItem().getItem() instanceof ShieldItem);
    }
    public static void press(ServerPlayer player) {
        if (!eligible(player)) return;
        if (STATES.containsKey(player.getUUID())) return;
        if (!CompoundBowItem.hasAmmo(player.getMainHandItem()) && !player.isCreative()) {
            reload(player, true); return;
        }
        if (!timing(player).press(player.level().getGameTime())) return;
        STATES.put(player.getUUID(), new State(player, false));
        sync(player);
    }
    public static void reload(ServerPlayer player, boolean begin) {
        if (!begin) { cancel(player); return; }
        if (!eligible(player) || player.getMainHandItem().getOrCreateTag().getInt("AmmoCount") >= 1
                || ammo(player).isEmpty() || STATES.containsKey(player.getUUID())) return;
        if (!timing(player).reload(player.level().getGameTime(), GunEnchantmentHelper.getReloadInterval(player.getMainHandItem(), BowStats.RELOAD_INTERVAL))) return;
        STATES.put(player.getUUID(), new State(player, true));
        sync(player);
    }
    public static void cancel(ServerPlayer player) {
        timing(player).cancel();
        if (STATES.remove(player.getUUID()) != null) sync(player);
    }
    private static ItemStack ammo(ServerPlayer player) {
        String selected = player.getMainHandItem().getOrCreateTag().getString("SelectedArrowType");
        ItemStack quiverAmmo = QuiverStorage.bowAmmo(player, false, selected);
        if (!quiverAmmo.isEmpty()) return quiverAmmo;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (TacticalArrowItem.accepts(stack) && (selected.isEmpty() || TacticalArrowItem.kind(stack).equals(selected))) return stack;
        }
        if (player.isCreative()) return ArrowSelection.item(selected);
        if ((selected.isEmpty() || selected.equals("normal")) && GunEnchantmentHelper.level(player.getMainHandItem(), ModEnchantments.INFINITY) > 0)
            return ArrowSelection.item("normal");
        return ItemStack.EMPTY;
    }
    private static void consumeAmmo(ServerPlayer player) {
        if (player.isCreative() || (GunEnchantmentHelper.level(player.getMainHandItem(), ModEnchantments.INFINITY) > 0
                && TacticalArrowItem.kind(ammo(player)).equals("normal"))) return;
        String selected = player.getMainHandItem().getOrCreateTag().getString("SelectedArrowType");
        if (!QuiverStorage.bowAmmo(player, true, selected).isEmpty()) return;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (TacticalArrowItem.accepts(stack) && (selected.isEmpty() || TacticalArrowItem.kind(stack).equals(selected))) { stack.shrink(1); return; }
        }
    }
    public static void release(ServerPlayer player) {
        State state = STATES.get(player.getUUID());
        if (state == null || state.reloading) return;
        long elapsed = player.level().getGameTime() - state.started;
        if (eligible(player) && player.isUnderWater() && !Config.COMMON.underwaterFiring.get()
                && GunEnchantmentHelper.level(state.stack, ModEnchantments.ATLANTIC_SHOOTER) == 0) { cancel(player); return; }
        if (!state.matches(player) || !eligible(player) || elapsed < BowStats.MIN_RELEASE_CHARGE
                || player.getCooldowns().isOnCooldown(state.stack.getItem())
                || (!CompoundBowItem.hasAmmo(state.stack) && !player.isCreative())) { cancel(player); return; }
        if (state.stack.getOrCreateTag().getBoolean("IsDrawing")) { cancel(player); return; }
        float charge = timing(player).release(player.level().getGameTime());
        STATES.remove(player.getUUID());
        if (charge <= 0) { sync(player); return; }
        BowArrowEntity arrow = new BowArrowEntity(StandaloneBow.ARROW.get(), player.level());
        if (player.isCreative() && !CompoundBowItem.hasAmmo(state.stack))
            state.stack.getOrCreateTag().putString("ArrowType", TacticalArrowItem.kind(ammo(player)));
        arrow.prepare(player, state.stack, charge);
        int reclaimed = GunEnchantmentHelper.level(state.stack, ModEnchantments.RECLAIMED);
        boolean consumed = !player.isCreative() && !state.stack.getOrCreateTag().getBoolean("IgnoreAmmo")
                && BowEnchantmentRules.consumeLoadedArrow(reclaimed,
                reclaimed == 0 ? 0 : player.getRandom().nextInt(4 - Mth.clamp(reclaimed, 1, 2)));
        arrow.setRecoverable(ArrowProfile.recoverable(TacticalArrowItem.loadedKind(state.stack), consumed,
                player.isCreative(), state.stack.getTag().getBoolean("IgnoreAmmo"),
                GunEnchantmentHelper.level(state.stack, ModEnchantments.INFINITY) > 0));
        // Resolve the first flight/impact before publishing spawn position and embedded state.
        arrow.tick();
        if (!arrow.isRemoved() && !player.level().addFreshEntity(arrow)) { sync(player); return; }
        player.getCooldowns().addCooldown(state.stack.getItem(), BowStats.SHOT_INTERVAL);
        if (!player.isCreative() && !state.stack.getOrCreateTag().getBoolean("IgnoreAmmo")) {
            if (consumed) {
            state.stack.getOrCreateTag().putInt("AmmoCount", Math.max(0, state.stack.getOrCreateTag().getInt("AmmoCount") - 1));
            ItemStack next = ammo(player);
            if (!next.isEmpty()) {
                state.stack.getOrCreateTag().putString("ArrowType", TacticalArrowItem.kind(next));
                consumeAmmo(player);
                state.stack.getOrCreateTag().putInt("AmmoCount", state.stack.getOrCreateTag().getInt("AmmoCount") + 1);
                player.getInventory().setChanged();
            }
            }
        }
        player.awardStat(Stats.ITEM_USED.get(state.stack.getItem()));
        float volume = Config.COMMON.playerGunfireVolume.get();
        float pitch = (player.isUnderWater() ? 0.7F : 0.9F) + player.getRandom().nextFloat() * 0.2F;
        if (player.isUnderWater()) {
            volume /= 2;
            player.level().playSound(null, player.blockPosition(), SoundEvents.BUBBLE_COLUMN_WHIRLPOOL_INSIDE, SoundSource.PLAYERS, 10, 1.7F);
        }
        player.level().playSound(player, player.getX(), player.getEyeY(), player.getZ(), StandaloneBow.FIRE.get(), SoundSource.PLAYERS,
                volume - 0.5F, pitch);
        player.connection.send(new ClientboundSoundPacket(Holder.direct(StandaloneBow.FIRE.get()), SoundSource.PLAYERS,
                player.getX(), player.getEyeY(), player.getZ(), 0.5F, pitch, player.getRandom().nextLong()));
        SHOTS.merge(player.getUUID(), 1, Integer::sum);
        sync(player);
        player.containerMenu.broadcastChanges();
    }
    @SubscribeEvent public void tick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START || !(event.player instanceof ServerPlayer player)) return;
        State state = STATES.get(player.getUUID());
        updateAnimatedTags(player);
        if (!eligible(player) && AIMING.remove(player.getUUID()) != null) sync(player);
        if (state == null) { sync(player); return; }
        if (!state.matches(player) || !eligible(player)) { cancel(player); return; }
        if (!state.reloading) {
            sync(player);
            return;
        }
        if (player.level().getGameTime() - state.started == 4)
            reloadSound(player, StandaloneBow.RELOAD_START.get());
        ItemStack ammo = ammo(player);
        if (ammo.isEmpty() || state.stack.getOrCreateTag().getInt("AmmoCount") >= 1) { cancel(player); return; }
        // INVENTORY_FED completes strictly after the interval, not on tick 16.
        if (timing(player).tick(player.level().getGameTime())) {
            state.stack.getOrCreateTag().putInt("AmmoCount", 1);
            state.stack.getOrCreateTag().putString("ArrowType", TacticalArrowItem.kind(ammo));
            consumeAmmo(player);
            player.getInventory().setChanged();
            player.containerMenu.broadcastChanges();
            // Upstream increaseAmmo plays reloadLoad twice.
            reloadSound(player, StandaloneBow.PLACE_ARROW.get());
            reloadSound(player, StandaloneBow.PLACE_ARROW.get());
            cancel(player);
        }
    }
    private static void updateAnimatedTags(ServerPlayer player) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (!(stack.getItem() instanceof CompoundBowItem)) continue;
            var tag = stack.getOrCreateTag();
            if (tag.getBoolean("IsJammed") && !player.getCooldowns().isOnCooldown(stack.getItem())) tag.remove("IsJammed");
            if (stack != player.getMainHandItem()) {
                for (String key : new String[]{"IsDrawing", "DrawnTick", "IsShooting", "IsReloading", "IsInspecting", "IsRunning", "IsMeleeing", "IsFirstPersonReload"}) tag.remove(key);
                continue;
            }
            int drawTicks = GunEnchantmentHelper.getModifiedDrawTick(stack, BowStats.DRAW_INTERVAL);
            boolean drawing = tag.getInt("DrawnTick") < drawTicks;
            tag.putBoolean("IsDrawing", drawing);
            if (drawing) tag.putInt("DrawnTick", tag.getInt("DrawnTick") + 1);
            tag.putBoolean("IsAiming", AIMING.getOrDefault(player.getUUID(), false));
            tag.putBoolean("IsRunning", player.isSprinting());
        }
    }
    private static void reloadSound(ServerPlayer player, net.minecraft.sounds.SoundEvent sound) {
        boolean firstPerson = player.getMainHandItem().getOrCreateTag().getBoolean("IsFirstPersonReload");
        player.level().playSound(firstPerson ? player : null, player.getOnPos(), sound, SoundSource.PLAYERS, 1, 1);
    }
    @SubscribeEvent public void logout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID(); STATES.remove(id); AIMING.remove(id); SHOTS.remove(id); TIMINGS.remove(id); LAST_SYNC.remove(id);
    }
    @SubscribeEvent public void tracking(PlayerEvent.StartTracking event) {
        if (event.getEntity() instanceof ServerPlayer viewer && event.getTarget() instanceof ServerPlayer target)
            BowNetwork.CHANNEL.send(net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> viewer), snapshot(target));
    }
    @SubscribeEvent public void changedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) { cancel(player); aim(player, false); }
    }
    @SubscribeEvent public void stopped(ServerStoppedEvent event) { STATES.clear(); AIMING.clear(); SHOTS.clear(); TIMINGS.clear(); LAST_SYNC.clear(); }
}
