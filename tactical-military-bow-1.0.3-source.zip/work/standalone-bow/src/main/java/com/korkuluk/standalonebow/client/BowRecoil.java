package com.korkuluk.standalonebow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** GunRecoilHandler and AnimatedGunRenderer recoil, with original unmodified bow defaults. */
@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT)
public final class BowRecoil {
    private static final Random RANDOM = new Random();
    private static float recoilRandom, cameraRecoil, cameraProgress;
    private static boolean yawNegative;
    private BowRecoil() {}

    public static void shot() {
        var mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (!BowClientConfig.CAMERA_RECOIL.get()) { cameraRecoil = cameraProgress = 0; return; }
        yawNegative = RANDOM.nextInt(2) == 1;
        recoilRandom = RANDOM.nextFloat();
        cameraRecoil = (float)(2 * adsReduction(BowClient.aim(mc.getPartialTick())));
        cameraProgress = 0;
        // JEG starts this cooldown locally on firing; retain a received server cooldown if present.
        ItemStack stack = mc.player.getMainHandItem();
        if (!mc.player.getCooldowns().isOnCooldown(stack.getItem()))
            mc.player.getCooldowns().addCooldown(stack.getItem(), 10);
    }

    public static void reset() { cameraRecoil = cameraProgress = recoilRandom = 0; }
    public static double adsReduction(float ads) { return BowRecoilMath.adsReduction(ads); }
    public static double normal(float cooldown) {
        // recoilDurationOffset defaults to zero; the first 20% is quartic, the return quadratic.
        return BowRecoilMath.normal(cooldown);
    }

    public static void apply(PoseStack pose, ItemStack stack, float partial, float ads) {
        var player = Minecraft.getInstance().player;
        if (player == null) return;
        double normal = normal(player.getCooldowns().getCooldownPercent(stack.getItem(), partial));
        double reduction = adsReduction(ads);
        double kick = 0.1 * 0.0625 * normal * reduction;
        float lift = (float)(2 * normal) * (float)reduction;
        float swayAmount = (float)(2 + (1.0 - ads));
        float sway = (float)((recoilRandom * swayAmount - swayAmount / 2) * normal);
        pose.translate(0, 0, kick);
        pose.translate(0, 0, 0.15);
        pose.mulPose(Axis.YP.rotationDegrees(sway / 5));
        pose.mulPose(Axis.ZP.rotationDegrees(sway / 5));
        pose.mulPose(Axis.XP.rotationDegrees(lift / 5));
        pose.translate(0, 0, -0.15);
    }

    @SubscribeEvent public static void renderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END || cameraRecoil <= 0) return;
        if (!BowClientConfig.CAMERA_RECOIL.get()) { cameraRecoil = cameraProgress = 0; return; }
        var mc = Minecraft.getInstance();
        if (mc.player == null) { reset(); return; }
        if (mc.isPaused()) return;
        float amount = cameraRecoil * mc.getDeltaFrameTime() * 0.15F;
        float start = cameraProgress / cameraRecoil;
        float end = (cameraProgress + amount) / cameraRecoil;
        float delta = ((end - start) / (start < 0.2F ? 0.2F : 0.8F)) * cameraRecoil;
        float direction = start < 0.2F ? -1 : 1;
        mc.player.setXRot(mc.player.getXRot() + direction * delta);
        mc.player.setYRot(mc.player.getYRot() + direction * (yawNegative ? 1 : -1) * delta / 2);
        cameraProgress += amount;
        if (cameraProgress >= cameraRecoil) cameraRecoil = cameraProgress = 0;
    }
}
