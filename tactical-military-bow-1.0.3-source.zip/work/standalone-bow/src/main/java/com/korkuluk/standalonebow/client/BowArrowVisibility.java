package com.korkuluk.standalonebow.client;

public final class BowArrowVisibility {
    private BowArrowVisibility() {}
    public static boolean reloadVisible(boolean firstPerson, String action, float x, float y, float z) {
        return firstPerson && action.equals("reload") && Float.isFinite(x) && Float.isFinite(y) && Float.isFinite(z)
                && x > 0.0001F && y > 0.0001F && z > 0.0001F;
    }
    public static boolean visible(boolean firstPerson, boolean loaded, String action, float x, float y, float z) {
        // Shoot clips include the hand bringing the next arrow; their scale keyframes control visibility.
        return firstPerson && loaded && !action.equals("reload") && Float.isFinite(x) && Float.isFinite(y) && Float.isFinite(z)
                && x > 0.0001F && y > 0.0001F && z > 0.0001F;
    }
}
