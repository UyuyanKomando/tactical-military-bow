package com.korkuluk.standalonebow.enchantment;

import com.korkuluk.standalonebow.CompoundBowItem;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

public final class EnchantmentTypes {
    public static final EnchantmentCategory GUN = EnchantmentCategory.create("tacticalmilitarybow:gun", item -> item instanceof CompoundBowItem);
    private EnchantmentTypes() {}
}
