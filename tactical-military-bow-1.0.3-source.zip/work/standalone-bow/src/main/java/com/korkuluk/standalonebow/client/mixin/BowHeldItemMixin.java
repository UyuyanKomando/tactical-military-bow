package com.korkuluk.standalonebow.client.mixin;

import com.korkuluk.standalonebow.client.BowClient;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.entity.layers.PlayerItemInHandLayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandLayer.class)
public abstract class BowHeldItemMixin {
    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void tacticalmilitarybow$held(LivingEntity entity, ItemStack stack, ItemDisplayContext context,
                                   HumanoidArm arm, PoseStack pose, MultiBufferSource buffers, int light, CallbackInfo ci) {
        if (entity instanceof Player && arm != entity.getMainArm()
                && stack.getItem() instanceof com.korkuluk.standalonebow.CompoundBowItem) {
            ci.cancel();
            return;
        }
        if (!(entity instanceof Player player) || BowClient.bridge() == null
                || !BowClient.bridge().isBow(player.getMainHandItem())) return;
        float aim = BowClient.aim(player, Minecraft.getInstance().getPartialTick());
        if (aim <= 0.001F && (arm != player.getMainArm() || !BowClient.bridge().isBow(stack))) return;
        ci.cancel();
        if (arm != player.getMainArm() || !BowClient.bridge().isBow(stack)) return;
        var layer = (PlayerItemInHandLayer<?, ?>)(Object)this;
        pose.pushPose();
        try {
            layer.getParentModel().translateToHand(arm, pose);
            pose.mulPose(Axis.XP.rotationDegrees(-90));
            pose.mulPose(Axis.YP.rotationDegrees(180));
            pose.translate((arm == HumanoidArm.LEFT ? -1 : 1) / 16F, 0.125, -0.625);
            if (aim > 0.001F) {
                BowClient.POSE.applyHeldItemTransforms(player, InteractionHand.MAIN_HAND, aim, pose, buffers);
            } else {
                // Recenter the baked bow's grip for the normal lowered hand, not its old two-handed pose.
                pose.translate((arm == HumanoidArm.LEFT ? 1 : -1) * 0.15 / 16, -1.625 / 16, 5.3 / 16);
            }
            Minecraft.getInstance().getItemRenderer().renderStatic(player, stack, context,
                    arm == HumanoidArm.LEFT, pose, buffers, player.level(), light,
                    net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY, player.getId());
        } finally { pose.popPose(); }
    }
}
