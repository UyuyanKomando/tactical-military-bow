package com.korkuluk.standalonebow.client;

/** Screen-space sectors start at the top and advance clockwise. */
public final class ArrowWheelLayout {
    private ArrowWheelLayout() {}
    public static int selected(double x, double y, double inner, double outer, int count) {
        double radius = Math.hypot(x, y);
        if (!Double.isFinite(radius) || count <= 0 || radius < inner || radius > outer) return -1;
        double angle = Math.atan2(y, x) + Math.PI / 2 + Math.PI / count;
        angle = (angle % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
        return Math.min(count - 1, (int)(angle / (Math.PI * 2 / count)));
    }
}
