package com.korkuluk.standalonebow.client;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.model.GeoModel;

public final class BowModel<T extends Item & GeoItem> extends GeoModel<T> {
    static String arrowKind = "normal";
    @Override public ResourceLocation getModelResource(T item) {
        return new ResourceLocation("tacticalmilitarybow", "geo/item/gun/compound_bow_" + arrowKind + ".geo.json");
    }
    @Override public ResourceLocation getTextureResource(T item) {
        return new ResourceLocation("tacticalmilitarybow", "textures/animated/gun/compound_bow_nocked_" + arrowKind + ".png");
    }
    @Override public ResourceLocation getAnimationResource(T item) {
        return new ResourceLocation("tacticalmilitarybow", "animations/item/compound_bow.animation.json");
    }
}
