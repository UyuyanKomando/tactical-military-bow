package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.BowNetwork;
import com.korkuluk.standalonebow.CompoundBowItem;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;

public final class BowCoreIntegration implements BowClientBridge {
    private static final Map<Integer, BowNetwork.State> STATES = new HashMap<>();
    private BowCoreIntegration() {}
    @Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Setup {
        @SubscribeEvent public static void setup(FMLClientSetupEvent event) {
            net.minecraftforge.fml.ModLoadingContext.get().registerExtensionPoint(
                    net.minecraftforge.client.ConfigScreenHandler.ConfigScreenFactory.class,
                    () -> new net.minecraftforge.client.ConfigScreenHandler.ConfigScreenFactory((mc, parent) -> new BowSettingsScreen(parent)));
            event.enqueueWork(() -> {
                BowClient.install(new BowCoreIntegration());
                BowNetwork.clientStateReceiver = BowCoreIntegration::receive;
                BowNetwork.clientEntityImpactReceiver = BowImpactEffects::entity;
                BowNetwork.clientBlockImpactReceiver = BowImpactEffects::block;
            });
        }
    }
    @Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT)
    public static final class Connection {
        @SubscribeEvent public static void logout(ClientPlayerNetworkEvent.LoggingOut event) { STATES.clear(); BowRecoil.reset(); }
        @SubscribeEvent public static void login(ClientPlayerNetworkEvent.LoggingIn event) { STATES.clear(); BowRecoil.reset(); }
    }
    private static void receive(BowNetwork.State state) {
        var mc = Minecraft.getInstance();
        var previous = STATES.put(state.entityId(), state);
        if (mc.player == null || state.entityId() != mc.player.getId()) return;
        if (previous != null && state.shotSequence() != previous.shotSequence()) BowClient.shot(state.aiming());
        if (state.reloading() && (previous == null || !previous.reloading())) {
            sendReloadPerspective();
            BowClient.reload();
        }
    }
    private static void send(BowNetwork.Action action) {
        if (Minecraft.getInstance().getConnection() != null)
            BowNetwork.CHANNEL.sendToServer(new BowNetwork.Input(action));
    }
    @Override public boolean isBow(ItemStack stack) { return stack.getItem() instanceof CompoundBowItem; }
    @Override public float animationSpeed(ItemStack stack) {
        return com.korkuluk.standalonebow.GunEnchantmentHelper.getReloadAnimationSpeed(stack);
    }
    @Override public int drawTimer(ItemStack stack) {
        return com.korkuluk.standalonebow.GunEnchantmentHelper.getModifiedDrawTick(stack, 10);
    }
    @Override public double aimSpeed(ItemStack stack) {
        return com.korkuluk.standalonebow.GunEnchantmentHelper.getAimDownSightSpeed(stack);
    }
    @Override public boolean drawAnimationEnabled() { return com.korkuluk.standalonebow.Config.COMMON.drawAnimation.get(); }
    @Override public boolean hasArrow(Player player, ItemStack stack) {
        var state = STATES.get(player.getId());
        return player.isCreative() || (stack.hasTag() && stack.getTag().getBoolean("IgnoreAmmo"))
                || (state == null ? CompoundBowItem.hasAmmo(stack) : state.ammo() > 0);
    }
    @Override public int ammo(Player player, ItemStack stack) {
        var state = STATES.get(player.getId());
        return state == null ? BowClientBridge.super.ammo(player, stack) : state.ammo();
    }
    @Override public boolean isCharging(Player player, ItemStack stack) {
        var state = STATES.get(player.getId());
        return state != null && state.charging();
    }
    @Override public boolean isReloading(Player player, ItemStack stack) {
        var state = STATES.get(player.getId());
        return state != null && state.reloading();
    }
    @Override public boolean isAiming(Player player) {
        var state = STATES.get(player.getId());
        return state != null && state.aiming();
    }
    @Override public void setAiming(boolean aim) { send(aim ? BowNetwork.Action.AIM_START : BowNetwork.Action.AIM_STOP); }
    @Override public void setCharging(boolean charge) { send(charge ? BowNetwork.Action.PRESS : BowNetwork.Action.RELEASE); }
    @Override public void cancelCharge() { send(BowNetwork.Action.CANCEL); }
    @Override public void reload() {
        sendReloadPerspective();
        send(BowNetwork.Action.RELOAD);
    }
    private static void sendReloadPerspective() {
        send(Minecraft.getInstance().options.getCameraType().isFirstPerson()
                ? BowNetwork.Action.RELOAD_FIRST_PERSON : BowNetwork.Action.RELOAD_THIRD_PERSON);
    }
}
