package com.korkuluk.standalonebow.client.mixin;

import com.korkuluk.standalonebow.client.BowClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.util.Mth;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Original MouseHandlerMixin ordinal and bow zoom sensitivity formula. */
@Mixin(MouseHandler.class)
public abstract class BowMouseHandlerMixin {
    @ModifyVariable(method = "turnPlayer()V", at = @At(value = "STORE", opcode = Opcodes.DSTORE), ordinal = 2)
    private double tacticalmilitarybow$sensitivity(double original) {
        var mc = Minecraft.getInstance();
        if (mc.player == null || BowClient.bridge() == null || !BowClient.bridge().isBow(mc.player.getMainHandItem())) return original;
        float additional = 1;
        if (mc.options.getCameraType().isFirstPerson() && BowClient.aiming()
                && !BowClient.bridge().isReloading(mc.player, mc.player.getMainHandItem()))
            additional = Mth.clamp(1 - (1 / 0.6F) / 10, 0, 1);
        double sensitivity = com.korkuluk.standalonebow.client.BowClientConfig.ADS_SENSITIVITY.get();
        return original * (1 - (1 - sensitivity) * BowClient.aim(mc.getPartialTick())) * additional;
    }
}
