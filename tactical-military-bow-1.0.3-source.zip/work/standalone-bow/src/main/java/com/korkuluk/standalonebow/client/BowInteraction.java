package com.korkuluk.standalonebow.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

final class BowInteraction {
    private static final TagKey<Block> BLOCKS = TagKey.create(Registries.BLOCK,
            new ResourceLocation("tacticalmilitarybow", "interact_key/whitelist"));
    private static final TagKey<EntityType<?>> ENTITIES = TagKey.create(Registries.ENTITY_TYPE,
            new ResourceLocation("tacticalmilitarybow", "interact_key/whitelist"));
    private BowInteraction() {}
    static boolean canInteract() {
        var mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.player.isSpectator()) return false;
        if (mc.hitResult instanceof BlockHitResult hit
                && hit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK)
            return mc.level.getBlockState(hit.getBlockPos()).is(BLOCKS);
        return mc.hitResult instanceof EntityHitResult hit && hit.getEntity().getType().is(ENTITIES);
    }
    static void interact() {
        var mc = Minecraft.getInstance();
        if (!canInteract()) return;
        for (InteractionHand hand : InteractionHand.values()) {
            InteractionResult result;
            if (mc.hitResult instanceof BlockHitResult hit && mc.level.getBlockState(hit.getBlockPos()).is(BLOCKS)) {
                result = mc.gameMode.useItemOn(mc.player, hand, hit);
            } else if (mc.hitResult instanceof EntityHitResult hit && hit.getEntity().getType().is(ENTITIES)) {
                result = mc.gameMode.interactAt(mc.player, hit.getEntity(), hit, hand);
                if (!result.consumesAction()) result = mc.gameMode.interact(mc.player, hit.getEntity(), hand);
            } else return;
            if (result.consumesAction()) {
                return;
            }
        }
    }
}
