package com.korkuluk.standalonebow.client;

import com.korkuluk.standalonebow.CompoundBowItem;
import com.korkuluk.standalonebow.TacticalArrowItem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.joml.Quaternionf;
import org.joml.Vector3f;

@Mod.EventBusSubscriber(modid = "tacticalmilitarybow", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ItemPhysicGunsCompat {
    private ItemPhysicGunsCompat() {}
    @SubscribeEvent public static void setup(FMLClientSetupEvent event) {
        if (ModList.get().isLoaded("itemphysicguns")) event.enqueueWork(ItemPhysicGunsCompat::register);
    }
    private static void register() {
        // Keep the optional provider API out of common/server class loading and build dependencies.
        String api = "ru.lavafrai.svogame.itemphysicguns.";
        try {
            Class<?> mod = Class.forName(api + "ItemPhysicGuns");
            Class<?> provider = Class.forName(api + "ItemTransformationProvider");
            var constructor = Class.forName(api + "ItemTransform").getConstructor(Vector3f.class, Quaternionf.class, Vector3f.class);
            Object adapter = java.lang.reflect.Proxy.newProxyInstance(provider.getClassLoader(), new Class<?>[]{provider},
                    (proxy, method, args) -> switch (method.getName()) {
                        case "canApplyTransform" -> accepts((ItemEntity)args[0]);
                        case "getTransform" -> constructor.newInstance(new Vector3f(0, 0, -0.03F),
                                new Quaternionf().rotationY((float)Math.PI / 2), new Vector3f(1));
                        case "toString" -> "TacticalMilitaryBowItemPhysicProvider";
                        case "hashCode" -> System.identityHashCode(proxy);
                        case "equals" -> proxy == args[0];
                        default -> throw new UnsupportedOperationException(method.getName());
                    });
            Object instance = mod.getMethod("getInstance").invoke(null);
            @SuppressWarnings("unchecked")
            var providers = (java.util.List<Object>)mod.getMethod("getProviders").invoke(instance);
            providers.add(adapter);
            com.mojang.logging.LogUtils.getLogger().info("Tactical Military Bow: ItemPhysic Guns provider registered");
        } catch (ReflectiveOperationException | RuntimeException | LinkageError exception) {
            com.mojang.logging.LogUtils.getLogger().warn("Tactical Military Bow: optional ItemPhysic Guns API is unavailable", exception);
        }
    }
    private static boolean accepts(ItemEntity entity) {
        var item = entity.getItem().getItem();
        return item instanceof CompoundBowItem || item instanceof TacticalArrowItem;
    }
}
