package com.korkuluk.standalonebow;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public final class ArrowSelection {
    public static final java.util.List<String> KINDS = java.util.List.of("normal", "piercing", "explosive", "poison", "flame");
    private ArrowSelection() {}
    public static ItemStack item(String kind) {
        return new ItemStack(switch (kind) {
            case "piercing" -> StandaloneBow.PIERCING_ARROW.get();
            case "explosive" -> StandaloneBow.EXPLOSIVE_ARROW.get();
            case "poison" -> StandaloneBow.POISON_ARROW.get();
            case "flame" -> StandaloneBow.FLAME_ARROW.get();
            default -> StandaloneBow.NORMAL_ARROW.get();
        });
    }
    public static String displayedKind(ItemStack bow) {
        return bow.getOrCreateTag().getInt("AmmoCount") > 0 ? TacticalArrowItem.loadedKind(bow)
                : bow.getOrCreateTag().contains("SelectedArrowType") ? bow.getTag().getString("SelectedArrowType") : TacticalArrowItem.loadedKind(bow);
    }
    public static int reserve(Player player, String kind) {
        int count = 0;
        var contents = QuiverStorage.contents(QuiverStorage.equipped(player));
        for (int i = 0; i < QuiverStorage.SLOTS; i++) {
            var stack = contents.getStackInSlot(i);
            if (TacticalArrowItem.accepts(stack) && TacticalArrowItem.kind(stack).equals(kind)) count += stack.getCount();
        }
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            var stack = player.getInventory().getItem(i);
            if (TacticalArrowItem.accepts(stack) && TacticalArrowItem.kind(stack).equals(kind)) count += stack.getCount();
        }
        return count;
    }
    public static void cycle(ServerPlayer player) {
        ItemStack bow = player.getMainHandItem();
        if (!(bow.getItem() instanceof CompoundBowItem) || !player.isAlive() || player.isSpectator()) return;
        if (BowMechanics.snapshot(player).charging() || BowMechanics.snapshot(player).reloading()
                || bow.getOrCreateTag().getBoolean("IsDrawing")) return;
        String current = displayedKind(bow);
        int index = KINDS.indexOf(current);
        for (int step = 1; step < KINDS.size(); step++) {
            String next = KINDS.get(Math.floorMod(index + step, KINDS.size()));
            if (reserve(player, next) == 0 && !player.isCreative()) continue;
            select(player, next);
            return;
        }
    }
    public static void select(ServerPlayer player, String next) {
        ItemStack bow = player.getMainHandItem();
        if (!(bow.getItem() instanceof CompoundBowItem) || !player.isAlive() || player.isSpectator()
                || !KINDS.contains(next)) return;
        if (BowMechanics.snapshot(player).charging() || BowMechanics.snapshot(player).reloading()
                || bow.getOrCreateTag().getBoolean("IsDrawing")) return;
        String current = displayedKind(bow);
        if (current.equals(next) || (reserve(player, next) == 0 && !player.isCreative())) return;
        if (bow.getTag().getInt("AmmoCount") > 0 && !player.isCreative()
                && !bow.getTag().getBoolean("IgnoreAmmo")
                && !(current.equals("normal") && GunEnchantmentHelper.level(bow, ModEnchantments.INFINITY) > 0)) {
            ItemStack old = item(current);
            var quiver = QuiverStorage.equipped(player);
            if (!quiver.isEmpty()) old = QuiverStorage.insert(quiver, old);
            if (!old.isEmpty() && !player.getInventory().add(old)) player.drop(old, false);
        }
        bow.getTag().putInt("AmmoCount", 0);
        bow.getTag().putString("SelectedArrowType", next);
        bow.getTag().putString("ArrowType", next);
        player.getInventory().setChanged();
        player.containerMenu.broadcastChanges();
        BowMechanics.reload(player, true);
    }
}
