package com.korkuluk.standalonebow;

import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;

public final class TacticalArrowItem extends ArrowItem implements software.bernie.geckolib.animatable.GeoItem {
    private final software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache cache =
            software.bernie.geckolib.util.GeckoLibUtil.createInstanceCache(this);
    private final String kind;
    public TacticalArrowItem(String kind) { super(new Properties()); this.kind = kind; }
    public String kind() { return kind; }
    @Override public software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
    @Override public void registerControllers(software.bernie.geckolib.core.animation.AnimatableManager.ControllerRegistrar controllers) {}
    @Override public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer) {
        consumer.accept(new net.minecraftforge.client.extensions.common.IClientItemExtensions() {
            private net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer renderer;
            @Override public net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) renderer = new com.korkuluk.standalonebow.client.TacticalArrowRenderer();
                return renderer;
            }
        });
    }
    public static boolean accepts(ItemStack stack) { return stack.getItem() instanceof TacticalArrowItem; }
    public static String kind(ItemStack stack) {
        return stack.getItem() instanceof TacticalArrowItem arrow ? arrow.kind : "normal";
    }
    public static String loadedKind(ItemStack bow) {
        String kind = bow.hasTag() ? bow.getTag().getString("ArrowType") : "normal";
        return kind.equals("piercing") || kind.equals("explosive") || kind.equals("poison") || kind.equals("flame") ? kind : "normal";
    }
}
