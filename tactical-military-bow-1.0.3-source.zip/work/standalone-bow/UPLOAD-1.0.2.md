# 1.0.2 Publication Checklist

Prepared locally only. No files have been uploaded or published by the assistant.

## CurseForge

- Upload: `tactical-military-bow-forge-1.20.1-1.0.2.jar`
- Display name: `[TaCZ] Tactical Military Bow 1.0.2 - Forge 1.20.1`
- Release type: Release
- Minecraft: 1.20.1
- Mod loader: Forge
- Java: 17
- Environment: Client and Server
- Keep required dependencies: TaCZ, LesRaisins Tactical Equipements, Curios API, GeckoLib.
- ItemPhysic Guns is NOT a required dependency. Arcana compatibility and creative ammo box support are not added by this update.
- Select automatic publication after approval if desired; the owner submits the file.

### Changelog (English)

- Fixed incorrect offhand first-person rendering.
- Added TaCZ-style back carry for the offhand and the unselected first hotbar slot, with matching position and angle.
- Fixed a missing quiver body texture.
- Redesigned the sight with a black circular housing, side screws and bright neon red range markings; removed the V-shaped marker.
- Arrow damage, recipes and firing behavior remain unchanged.

## GitHub

Upload the new source ZIP and the updated README, CHANGELOG, BUILD and license/notice files from this release folder. The previous version's source ZIP may remain available as history.

- Source archive: `tactical-military-bow-1.0.2-source.zip`
- Commit summary: `Update Tactical Military Bow to 1.0.2`
- Optional release tag: `v1.0.2`

Do not upload the `source-staging-*` folder or any Tester backups. `MANIFEST.json` contains SHA-256 hashes for local verification.

## Installation / Testing

Back up worlds and remove the old bow JAR before installing 1.0.2. Do not keep two versions of the mod together. Multiplayer and a separate clean installation have not been independently verified.
