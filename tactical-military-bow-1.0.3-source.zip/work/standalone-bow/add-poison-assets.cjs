const fs = require('fs'), path = require('path'), assert = require('assert');
const root = path.join(__dirname, 'src/main/resources');
const assets = path.join(root, 'assets/tacticalmilitarybow');
function write(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n'); }
for (const relative of ['geo/item/normal_arrow.geo.json', 'geo/item/gun/compound_bow_normal.geo.json',
    'models/item/normal_arrow.json', 'models/item/normal_arrow_gui.json', 'models/item/normal_arrow_in_hand.json']) {
    const value = JSON.parse(fs.readFileSync(path.join(assets, relative)));
    const replaced = JSON.parse(JSON.stringify(value).replaceAll('normal_arrow', 'poison_arrow'));
    const target = relative.replace('normal', 'poison');
    write(path.join(assets, target), replaced);
}
write(path.join(root, 'data/tacticalmilitarybow/recipes/poison_arrow.json'), {
    type: 'tacz:gun_smith_table_crafting',
    materials: [['stick', 10], ['iron_ingot', 2], ['gold_ingot', 2], ['spider_eye', 1], ['redstone', 1], ['string', 10]]
        .map(([item, count]) => ({item: {item: 'minecraft:' + item}, count})),
    result: {type: 'custom', group: 'tacz:explosives', item: {item: 'tacticalmilitarybow:poison_arrow', count: 45}}
});
for (const [lang, label] of [['en_us', 'Poison Arrow'], ['tr_tr', 'Zehirli Ok']]) {
    const file = path.join(assets, 'lang/' + lang + '.json');
    const value = JSON.parse(fs.readFileSync(file));
    value['item.tacticalmilitarybow.poison_arrow'] = label;
    write(file, value);
}
const en = JSON.parse(fs.readFileSync(path.join(assets, 'lang/en_us.json')));
const tr = JSON.parse(fs.readFileSync(path.join(assets, 'lang/tr_tr.json')));
assert.deepStrictEqual(Object.keys(en).sort(), Object.keys(tr).sort());
console.log('Poison models, 45-arrow recipe and EN/TR labels exported.');
for (const relative of ['geo/item/normal_arrow.geo.json', 'geo/item/gun/compound_bow_normal.geo.json',
    'models/item/normal_arrow.json', 'models/item/normal_arrow_gui.json', 'models/item/normal_arrow_in_hand.json']) {
    const value = JSON.parse(fs.readFileSync(path.join(assets, relative)));
    write(path.join(assets, relative.replace('normal', 'flame')),
        JSON.parse(JSON.stringify(value).replaceAll('normal_arrow', 'flame_arrow')));
}
write(path.join(root, 'data/tacticalmilitarybow/recipes/flame_arrow.json'), {
    type: 'tacz:gun_smith_table_crafting',
    materials: [['stick', 10], ['iron_ingot', 2], ['gold_ingot', 2], ['flint', 1], ['redstone', 1], ['string', 10]]
        .map(([item, count]) => ({item: {item: 'minecraft:' + item}, count})),
    result: {type: 'custom', group: 'tacz:explosives', item: {item: 'tacticalmilitarybow:flame_arrow', count: 45}}
});
for (const [lang, label] of [['en_us', 'Flame Arrow'], ['tr_tr', 'Alevli Ok']]) {
    const file = path.join(assets, 'lang/' + lang + '.json');
    const value = JSON.parse(fs.readFileSync(file));
    value['item.tacticalmilitarybow.flame_arrow'] = label;
    write(file, value);
}
console.log('Flame models, 45-arrow recipe and EN/TR labels exported.');
require('./color-special-arrows.cjs');
