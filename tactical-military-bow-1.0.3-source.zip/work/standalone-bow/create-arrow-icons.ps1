Add-Type -AssemblyName System.Drawing
$assets = Join-Path $PSScriptRoot 'src/main/resources/assets/tacticalmilitarybow'
foreach ($kind in @('normal', 'piercing', 'explosive', 'poison', 'flame')) {
    $bitmap = [System.Drawing.Bitmap]::new(64, 64)
    $g = [System.Drawing.Graphics]::FromImage($bitmap)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.Clear([System.Drawing.Color]::Transparent)
    $g.TranslateTransform(32, 32)
    $g.RotateTransform(135)
    $outline = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(255, 22, 25, 28), 6)
    $shaft = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(255, 169, 181, 187), 4)
    $highlight = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(255, 230, 236, 239), 1)
    $shade = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 83, 101, 114))
    $metal = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 224, 232, 235))
    $vane = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 134, 153, 160))
    if ($kind -eq 'poison') {
        $vane.Dispose()
        $vane = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 35, 91, 42))
    }
    if ($kind -eq 'flame') {
        $vane.Dispose()
        $vane = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 157, 65, 18))
    }
    $g.DrawLine($outline, -20, 0, 25, 0)
    $g.DrawLine($shaft, -20, 0, 25, 0)
    $g.DrawLine($highlight, -19, -1, 25, -1)
    $g.FillPolygon($vane, [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(15, -2), [System.Drawing.PointF]::new(22, -8), [System.Drawing.PointF]::new(27, -8), [System.Drawing.PointF]::new(25, -2)))
    $g.FillPolygon($vane, [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(15, 2), [System.Drawing.PointF]::new(22, 8), [System.Drawing.PointF]::new(27, 8), [System.Drawing.PointF]::new(25, 2)))
    $g.FillPolygon($shade, [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(15, 2), [System.Drawing.PointF]::new(22, 8), [System.Drawing.PointF]::new(27, 8), [System.Drawing.PointF]::new(25, 4)))
    $g.DrawLine($highlight, 18, -4, 26, -8)
    $g.DrawLine($outline, 27, -2, 27, 2)
    if ($kind -eq 'explosive') {
        $payload = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 188, 48, 45))
        $g.FillRectangle($shade, -23, -7, 13, 14)
        $g.FillRectangle($payload, -22, -6, 11, 12)
        $g.DrawLine($highlight, -20, -4, -12, -4)
        $g.FillRectangle($metal, -13, -6, 3, 12)
        $payload.Dispose()
    }
    if ($kind -eq 'piercing') {
        $band = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(255, 232, 189, 70), 5)
        $g.DrawLine($band, -15, -4, -15, 4)
        $band.Dispose()
    }
    if ($kind -eq 'poison' -or $kind -eq 'flame') {
        $color = if ($kind -eq 'flame') { [System.Drawing.Color]::FromArgb(255, 157, 65, 18) } else { [System.Drawing.Color]::FromArgb(255, 35, 91, 42) }
        $band = [System.Drawing.Pen]::new($color, 5)
        $g.DrawLine($band, -15, -4, -15, 4)
        $band.Dispose()
    }
    $headWidth = if ($kind -eq 'piercing') { 4 } else { 8 }
    if ($kind -eq 'poison' -or $kind -eq 'flame') {
        $metal.Dispose(); $shade.Dispose()
        $tipColor = if ($kind -eq 'poison') { [System.Drawing.Color]::FromArgb(255, 35, 91, 42) } else { [System.Drawing.Color]::FromArgb(255, 157, 65, 18) }
        $metal = [System.Drawing.SolidBrush]::new($tipColor)
        $shade = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, [int]($tipColor.R * 0.6), [int]($tipColor.G * 0.6), [int]($tipColor.B * 0.6)))
    }
    $head = [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(-29, 0), [System.Drawing.PointF]::new(-18, -$headWidth), [System.Drawing.PointF]::new(-20, 0), [System.Drawing.PointF]::new(-18, $headWidth))
    $g.FillPolygon($metal, $head)
    $g.FillPolygon($shade, [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(-29, 0), [System.Drawing.PointF]::new(-20, 0), [System.Drawing.PointF]::new(-18, $headWidth)))
    $bitmap.Save((Join-Path $assets ('textures/item/' + $kind + '_arrow_icon.png')), [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bitmap.Dispose(); $outline.Dispose(); $shaft.Dispose(); $metal.Dispose(); $vane.Dispose(); $highlight.Dispose(); $shade.Dispose()
}
