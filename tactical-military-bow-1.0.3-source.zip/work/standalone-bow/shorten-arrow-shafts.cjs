const fs = require('fs'), path = require('path'), assert = require('assert');
const assets = path.join(__dirname, 'src/main/resources/assets/tacticalmilitarybow');
const front = -8.780751085233032, rear = 8.812393751137217;
const removed = (rear - front) * 0.4;
const shorten = z => z <= front ? z + removed : z >= rear ? z : rear + (z - rear) * 0.6;
for (const kind of ['normal', 'piercing', 'explosive', 'poison', 'flame']) {
    const file = path.join(assets, 'geo/item/' + kind + '_arrow.geo.json');
    const value = JSON.parse(fs.readFileSync(file));
    const geometry = value['minecraft:geometry'][0];
    // Always restore model inputs before running this one-time geometry transform.
    for (const bone of geometry.bones) {
        // Keep the animation hierarchy and its attachment transforms unchanged.
        const pivot = JSON.stringify(bone.pivot);
        for (const cube of bone.cubes || []) {
            const original = cube.size[2];
            const z = cube.origin[2];
            cube.origin[2] = shorten(z);
            cube.size[2] = shorten(z + original) - shorten(z);
            if (cube.pivot) cube.pivot[2] = shorten(cube.pivot[2]);
            if (bone.name.includes('yu') || z + original <= front)
                assert(Math.abs(cube.size[2] - original) < 1e-8, 'Tip/tail size changed: ' + bone.name);
            if (bone.name.includes('yu')) assert.equal(cube.origin[2], z, 'Tail must stay on the string');
        }
        assert.equal(JSON.stringify(bone.pivot), pivot, 'Animation attachment pivot changed');
    }
    fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n');
}
console.log('Five shafts shortened by 40% from the front; tail position and tip/vane dimensions preserved.');
require('./unify-nocked-textures.cjs')();
