$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$assets = Join-Path $PSScriptRoot 'src/main/resources/assets/tacticalmilitarybow'
foreach ($kind in @('normal','piercing','explosive','poison','flame')) {
    $suffix = if ($kind -in @('poison','flame')) { '_' + $kind } else { '' }
    $bow = [Drawing.Bitmap]::new((Join-Path $assets 'textures/animated/gun/compound_bow.png'))
    $arrow = [Drawing.Bitmap]::new((Join-Path $assets ('textures/item/arrow_palette' + $suffix + '.png')))
    $bitmap = [Drawing.Bitmap]::new(($bow.Width + $arrow.Width), $bow.Height)
    for ($x=0; $x -lt $bow.Width; $x++) { for ($y=0; $y -lt $bow.Height; $y++) { $bitmap.SetPixel($x,$y,$bow.GetPixel($x,$y)) } }
    for ($x=0; $x -lt $arrow.Width; $x++) { for ($y=0; $y -lt $arrow.Height; $y++) { $bitmap.SetPixel(($bow.Width+$x),$y,$arrow.GetPixel($x,$y)) } }
    $bitmap.Save((Join-Path $assets ('textures/animated/gun/compound_bow_nocked_' + $kind + '.png')), [Drawing.Imaging.ImageFormat]::Png)
    $bow.Dispose(); $arrow.Dispose(); $bitmap.Dispose()
}
