$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$path = Join-Path $PSScriptRoot 'src/main/resources/assets/tacticalmilitarybow/textures/animated/gun/compound_bow.png'
$source = [Drawing.Bitmap]::new($path)
$bitmap = [Drawing.Bitmap]::new($source)
$source.Dispose()
# Reserve a separate palette texel so the housing and bow accents stay unchanged.
$bitmap.SetPixel(127,127,[Drawing.Color]::FromArgb(255,255,18,30))
$bitmap.Save($path,[Drawing.Imaging.ImageFormat]::Png)
$bitmap.Dispose()
& (Join-Path $PSScriptRoot 'create-nocked-atlases.ps1')
