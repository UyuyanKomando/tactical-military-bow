const fs = require('fs'), path = require('path');
const assets = path.join(__dirname, 'src/main/resources/assets/tacticalmilitarybow');
const read = p => JSON.parse(fs.readFileSync(path.join(assets, p)));
const write = (p, v) => fs.writeFileSync(path.join(assets, p), JSON.stringify(v, null, 2) + '\n');
const copy = v => JSON.parse(JSON.stringify(v));
const faces = ['north', 'east', 'south', 'west', 'up', 'down'];
const colorUV = () => Object.fromEntries(faces.map(f => [f, {uv: [41, 1], uv_size: [4, 4]}]));
for (const kind of ['poison', 'flame']) {
    const arrow = read('geo/item/normal_arrow.geo.json');
    const geo = arrow['minecraft:geometry'][0];
    geo.description.identifier = 'geometry.tacticalmilitarybow_' + kind + '_arrow';
    geo.description.texture_width = 48;
    for (const bone of geo.bones) {
        if (bone.name.includes('head') || bone.name.includes('bone12'))
            for (const cube of bone.cubes || []) cube.uv = colorUV();
    }
    for (const [index, z] of [-7, -3, 1].entries()) {
        geo.bones.push({name: 'colored_band_' + index, parent: 'custom_nocked_arrow_root',
            pivot: [0.06855, 3.0898, z], cubes: [{origin: [-0.08145, 2.9398, z],
                size: [0.30, 0.30, 0.55], uv: colorUV()}]});
    }
    write('geo/item/' + kind + '_arrow.geo.json', arrow);
    const bow = read('geo/item/gun/compound_bow_normal.geo.json');
    const bg = bow['minecraft:geometry'][0];
    bg.description.texture_width = 136;
    bg.bones = bg.bones.filter(b => !b.name.startsWith('custom_nocked_'));
    const name = (n, prefix) => n.startsWith('custom_nocked_arrow')
        ? n.replace('custom_nocked_arrow', 'custom_nocked_' + prefix) : 'custom_nocked_' + prefix + '_' + n;
    for (const prefix of ['arrow', 'reload_arrow']) for (const original of geo.bones) {
        const bone = copy(original);
        bone.name = name(original.name, prefix);
        bone.parent = original.parent ? name(original.parent, prefix) : prefix;
        for (const cube of bone.cubes || []) for (const face of Object.values(cube.uv)) {
            // Nocked bones use the separate 48x8 arrow palette, not the bow atlas.
            face.uv = [face.uv[0] * 136 / 48, face.uv[1] * 16];
            face.uv_size = [face.uv_size[0] * 136 / 48, face.uv_size[1] * 16];
        }
        bg.bones.push(bone);
    }
    write('geo/item/gun/compound_bow_' + kind + '.geo.json', bow);
}
console.log('Green/orange tip and three shaft bands mapped for held, projectile and nocked models.');
require('./unify-nocked-textures.cjs')();
