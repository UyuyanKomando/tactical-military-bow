Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = 'Stop'
$assets = Join-Path $PSScriptRoot 'src/main/resources/assets/tacticalmilitarybow'
foreach ($kind in @('poison', 'flame')) {
    $color = if ($kind -eq 'poison') { [Drawing.Color]::FromArgb(35,91,42) } else { [Drawing.Color]::FromArgb(157,65,18) }
    foreach ($relative in @('textures/item/arrow_palette.png', 'textures/animated/gun/compound_bow.png')) {
        $source = [Drawing.Bitmap]::new((Join-Path $assets $relative))
        $bitmap = [Drawing.Bitmap]::new(($source.Width + 8), $source.Height)
        $g = [Drawing.Graphics]::FromImage($bitmap)
        $g.Clear([Drawing.Color]::Transparent)
        $brush = [Drawing.SolidBrush]::new($color)
        $g.FillRectangle($brush, $source.Width, 0, 8, $source.Height)
        for ($x = 0; $x -lt $source.Width; $x++) {
            for ($y = 0; $y -lt $source.Height; $y++) {
                $bitmap.SetPixel($x, $y, $source.GetPixel($x, $y))
                if ($bitmap.GetPixel($x, $y).ToArgb() -ne $source.GetPixel($x, $y).ToArgb()) { throw 'Original atlas pixels changed.' }
            }
        }
        $target = $relative.Replace('.png', ('_' + $kind + '.png'))
        $bitmap.Save((Join-Path $assets $target), [Drawing.Imaging.ImageFormat]::Png)
        $brush.Dispose(); $g.Dispose(); $bitmap.Dispose(); $source.Dispose()
    }
}
