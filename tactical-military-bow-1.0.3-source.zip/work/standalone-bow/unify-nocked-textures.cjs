const fs = require('fs'), path = require('path'), assert = require('assert');
const root = path.join(__dirname, 'src/main/resources/assets/tacticalmilitarybow');
const read = p => JSON.parse(fs.readFileSync(path.join(root, p)));
function unify() {
for (const kind of ['normal','piercing','explosive','poison','flame']) {
    const bow = read('geo/item/gun/compound_bow_' + kind + '.geo.json');
    const bg = bow['minecraft:geometry'][0];
    const arrow = read('geo/item/' + kind + '_arrow.geo.json')['minecraft:geometry'][0];
    bg.description.texture_width = 128 + arrow.description.texture_width;
    for (const prefix of ['arrow','reload_arrow']) for (const bone of arrow.bones) {
        const name = bone.name.startsWith('custom_nocked_arrow')
            ? bone.name.replace('custom_nocked_arrow', 'custom_nocked_' + prefix)
            : 'custom_nocked_' + prefix + '_' + bone.name;
        const target = bg.bones.find(b => b.name === name);
        assert(target, name);
        target.pivot = bone.pivot;
        if (bone.rotation) target.rotation = bone.rotation;
        else delete target.rotation;
        if (bone.cubes) target.cubes = JSON.parse(JSON.stringify(bone.cubes));
        else delete target.cubes;
        (bone.cubes || []).forEach((cube, i) => {
            target.cubes[i].uv = Object.fromEntries(Object.entries(cube.uv).map(([side, face]) =>
                [side, {uv: [128 + face.uv[0], face.uv[1]], uv_size: face.uv_size}]));
        });
    }
    fs.writeFileSync(path.join(root, 'geo/item/gun/compound_bow_' + kind + '.geo.json'), JSON.stringify(bow,null,2)+'\n');
}
console.log('All five nocked/reload models use one combined bow atlas.');
}
module.exports = unify;
if (require.main === module) unify();
